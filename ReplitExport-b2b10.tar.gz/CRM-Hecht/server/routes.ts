import type { Express } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { storage } from "./storage";
import {
  insertCustomerSchema,
  insertProspectSchema,
  insertTaskSchema,
  insertActivitySchema,
  insertFieldDefinitionSchema,
  insertUserSchema,
  insertSystemSettingSchema,
  changePasswordSchema
} from "@shared/schema";
import { z } from "zod";
import bcrypt from "bcrypt";
// Removed the import as global fetch is available

// Extend Express session type
declare module 'express-session' {
  interface SessionData {
    userId: string;
    user: any;
  }
}

async function getMapsSettings() {
  const modeS = await storage.getSystemSetting('maps_streetview_mode');
  const maxS  = await storage.getSystemSetting('maps_max_photos');
  const mode = modeS?.settingValue === 'static' ? 'static' : 'embed';
  const max = Math.min(10, Math.max(1, parseInt(maxS?.settingValue || '5', 10)));
  return { maps_streetview_mode: mode, maps_max_photos: max };
}

async function setSystemSetting(key: string, value: string) {
  const existing = await storage.getSystemSetting(key);
  if (existing) {
    await storage.updateSystemSetting(key, { settingValue: value });
  } else {
    await storage.createSystemSetting({
      settingKey: key,
      settingValue: value,
      category: 'general',
      description: `Auto-created setting for ${key}`
    });
  }
}

// Authentication middleware
function isAuthenticated(req: any, res: any, next: any) {
  if (req.session?.userId) {
    return next();
  }
  return res.status(401).json({ message: 'Unauthorized' });
}

function requireAdmin(req: any, res: any, next: any) {
  if (req.session?.user?.role === 'administrator') return next();
  return res.status(403).json({ message: 'Admin only' });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure session middleware
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  app.use(session({
    secret: process.env.SESSION_SECRET || 'dev-secret-change-in-production',
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: false, // Set to true in production with HTTPS
      maxAge: sessionTtl,
    },
  }));

  // Authentication routes
  app.post('/api/auth/login', async (req, res) => {
    try {
      const { username, password, rememberMe } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: 'Nazwa użytkownika i hasło są wymagane' });
      }
      
      const user = await storage.getUserByUsername(username);
      if (!user || user.isActive !== 1) {
        return res.status(401).json({ message: 'Nieprawidłowa nazwa użytkownika lub hasło' });
      }
      
      const isPasswordValid = await bcrypt.compare(password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ message: 'Nieprawidłowa nazwa użytkownika lub hasło' });
      }
      
      // Note: lastLogin update will be handled separately as it's not in InsertUser schema
      
      // Set session with custom expiration based on "remember me"
      req.session.userId = user.id;
      req.session.user = user;
      
      // If "remember me" is checked, extend the session to 30 days
      if (rememberMe) {
        const extendedTtl = 30 * 24 * 60 * 60 * 1000; // 30 days
        req.session.cookie.maxAge = extendedTtl;
      }
      
      res.json({ 
        message: 'Zalogowano pomyślnie',
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role
        }
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ message: 'Błąd serwera' });
    }
  });

  app.post('/api/auth/logout', (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: 'Błąd podczas wylogowywania' });
      }
      res.json({ message: 'Wylogowano pomyślnie' });
    });
  });

  app.get('/api/auth/me', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: 'Użytkownik nie został znaleziony' });
      }
      
      res.json({
        id: user.id,
        username: user.username,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role
      });
    } catch (error) {
      res.status(500).json({ message: 'Błąd serwera' });
    }
  });

  app.post('/api/auth/change-password', isAuthenticated, async (req: any, res) => {
    try {
      const validation = changePasswordSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: validation.error.errors[0].message });
      }
      
      const { currentPassword, newPassword } = validation.data;
      const userId = req.session.userId;
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: 'Użytkownik nie został znaleziony' });
      }
      
      // Verify current password
      const isCurrentPasswordValid = await bcrypt.compare(currentPassword, user.password);
      if (!isCurrentPasswordValid) {
        return res.status(400).json({ message: 'Aktualne hasło jest nieprawidłowe' });
      }
      
      // Hash new password
      const newPasswordHash = await bcrypt.hash(newPassword, 10);
      
      // Update password
      const success = await storage.changePassword(userId, newPasswordHash);
      if (!success) {
        return res.status(500).json({ message: 'Nie udało się zmienić hasła' });
      }
      
      res.json({ message: 'Hasło zostało zmienione pomyślnie' });
    } catch (error) {
      console.error('Password change error:', error);
      res.status(500).json({ message: 'Błąd serwera' });
    }
  });

  app.get('/api/settings/maps', isAuthenticated, async (_req, res) => {
    const cfg = await getMapsSettings();
    res.json(cfg);
  });

  app.post('/api/settings/maps', isAuthenticated, requireAdmin, async (req, res) => {
    const { maps_streetview_mode, maps_max_photos } = req.body || {};
    if (maps_streetview_mode && !['embed', 'static'].includes(maps_streetview_mode)) {
      return res.status(400).json({ message: 'maps_streetview_mode must be embed|static' });
    }
    if (maps_max_photos !== undefined) {
      const n = parseInt(String(maps_max_photos), 10);
      if (!Number.isFinite(n) || n < 1 || n > 10) {
        return res.status(400).json({ message: 'maps_max_photos must be 1..10' });
      }
    }
    if (maps_streetview_mode) await setSystemSetting('maps_streetview_mode', maps_streetview_mode);
    if (maps_max_photos !== undefined) await setSystemSetting('maps_max_photos', String(maps_max_photos));
    const cfg = await getMapsSettings();
    res.json(cfg);
  });
  // Dashboard metrics
  app.get("/api/dashboard/metrics", isAuthenticated, async (req, res) => {
    try {
      const metrics = await storage.getDashboardMetrics();
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard metrics" });
    }
  });

  // Customer routes
  app.get("/api/customers", isAuthenticated, async (req, res) => {
    try {
      const customers = await storage.getCustomers();
      res.json(customers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customers" });
    }
  });

  app.get("/api/customers/:id", isAuthenticated, async (req, res) => {
    try {
      const customer = await storage.getCustomerWithProspects(req.params.id);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      res.json(customer);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customer" });
    }
  });

  app.post("/api/customers", isAuthenticated, async (req, res) => {
    try {
      // Parsuj podstawowe pola przez schema, ale zachowaj wszystkie pola z req.body
      const validatedBaseData = insertCustomerSchema.parse(req.body);
      // Połącz zatwierdzone podstawowe dane z wszystkimi polami z req.body (dla dynamicznych pól)
      const customerData = { ...req.body, ...validatedBaseData };
      const customer = await storage.createCustomer(customerData);
      res.status(201).json(customer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid customer data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create customer" });
    }
  });

  // Import customers from Excel
  app.post("/api/customers/import", isAuthenticated, async (req, res) => {
    try {
      const importSchema = z.object({
        customers: z.array(z.object({
          groupName: z.string().optional(),
          contractorName: z.string().optional(),
          nip: z.string().optional(),
          city: z.string().optional(),
          code: z.string().optional(),
          streetAddress: z.string().optional(),
          contract: z.string().optional(),
          classification: z.string().optional(),
          salesperson: z.string().optional(),
          email: z.string().optional(),
          phone: z.string().optional(),
          revenue2020: z.union([z.string(), z.number()]).optional(),
          revenue2021: z.union([z.string(), z.number()]).optional(),
          revenue2022: z.union([z.string(), z.number()]).optional(),
          revenue2023: z.union([z.string(), z.number()]).optional(),
          revenue2024: z.union([z.string(), z.number()]).optional(),
          revenue2025: z.union([z.string(), z.number()]).optional(),
          totalRevenue: z.union([z.string(), z.number()]).optional()
        }))
      });

      const { customers } = importSchema.parse(req.body);

      // Filter out customers without required fields and validate each customer
      const validCustomers = [];
      const errors = [];

      for (let i = 0; i < customers.length; i++) {
        const customer = customers[i];

        // Check if customer has at least contractor name
        if (!customer.contractorName) {
          errors.push(`Rekord ${i + 1}: Brak nazwy kontrahenta`);
          continue;
        }

        try {
          // Helper function to convert revenue strings to numbers
          const parseRevenue = (value: string | number | undefined): string => {
            if (typeof value === 'number') return value.toString();
            if (typeof value === 'string') {
              const cleaned = value.replace(/[^\d.,]/g, '').replace(',', '.');
              return cleaned || '0';
            }
            return '0';
          };

          // Convert to proper customer data format
          const customerData = {
            groupName: customer.groupName || '',
            contractorName: customer.contractorName,
            nip: customer.nip || '',
            city: customer.city || '',
            code: customer.code || '',
            streetAddress: customer.streetAddress || '',
            contract: customer.contract || '',
            classification: customer.classification || '',
            salesperson: customer.salesperson || '',
            email: customer.email || '',
            phone: customer.phone || '',
            revenue2020: parseRevenue(customer.revenue2020),
            revenue2021: parseRevenue(customer.revenue2021),
            revenue2022: parseRevenue(customer.revenue2022),
            revenue2023: parseRevenue(customer.revenue2023),
            revenue2024: parseRevenue(customer.revenue2024),
            revenue2025: parseRevenue(customer.revenue2025),
            totalRevenue: parseRevenue(customer.totalRevenue)
          };

          // Validate with schema
          const validatedCustomer = insertCustomerSchema.parse(customerData);
          validCustomers.push(validatedCustomer);
        } catch (validationError) {
          errors.push(`Rekord ${i + 1}: Nieprawidłowe dane`);
        }
      }

      // Create customers in batch
      const createdCustomers = [];
      for (const customerData of validCustomers) {
        try {
          const customer = await storage.createCustomer(customerData);
          createdCustomers.push(customer);
        } catch (error) {
          console.error('Failed to create customer:', error);
        }
      }

      res.status(201).json({
        imported: createdCustomers.length,
        total: customers.length,
        errors: errors,
        customers: createdCustomers
      });

    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid import data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to import customers" });
    }
  });

  app.put("/api/customers/:id", isAuthenticated, async (req, res) => {
    try {
      const customerData = insertCustomerSchema.partial().parse(req.body);
      const customer = await storage.updateCustomer(req.params.id, customerData);
      res.json(customer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid customer data", errors: error.errors });
      }
      if (error instanceof Error && error.message === "Customer not found") {
        return res.status(404).json({ message: "Customer not found" });
      }
      res.status(500).json({ message: "Failed to update customer" });
    }
  });

  app.delete("/api/customers/:id", isAuthenticated, async (req, res) => {
    try {
      const deleted = await storage.deleteCustomer(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Customer not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete customer" });
    }
  });

  // Enrich customer data with Google Maps and web information
  app.post("/api/customers/:id/enrich", isAuthenticated, async (req, res) => {
    try {
      const customer = await storage.getCustomer(req.params.id);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }

      const enrichedData: any = {};
      const googleMapsApiKeySetting = await storage.getSystemSetting('google_maps_api_key');
      const googleMapsApiKey = googleMapsApiKeySetting?.settingValue || process.env.GOOGLE_MAPS_API_KEY;

      if (!googleMapsApiKey) {
        return res.status(500).json({ message: "Google Maps API key not configured" });
      }

      // 1. Search for the business on Google Places
      const searchQuery = `${customer.contractorName} ${customer.city || ''} ${customer.streetAddress || ''}`.trim();

      try {
        const placesResponse = await fetch(
          `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${encodeURIComponent(searchQuery)}&key=${googleMapsApiKey}`
        );
        const placesData = await placesResponse.json() as any;

        if (placesData.results && placesData.results.length > 0) {
          const place = placesData.results[0];
          enrichedData.googlePlaceId = place.place_id;
          enrichedData.googleRating = place.rating ? String(place.rating) : '';
          enrichedData.businessStatus = place.business_status || '';
          enrichedData.businessTypes = JSON.stringify(place.types || []);

          if (place.photos && place.photos.length > 0) {
            enrichedData.googlePhotoReference = place.photos[0].photo_reference;
          }

          // Get detailed place information including website
          if (place.place_id) {
            const detailsResponse = await fetch(
              `https://maps.googleapis.com/maps/api/place/details/json?place_id=${place.place_id}&fields=website,formatted_phone_number&key=${googleMapsApiKey}`
            );
            const detailsData = await detailsResponse.json() as any;

            if (detailsData.result) {
              enrichedData.website = detailsData.result.website || '';
              if (!customer.phone && detailsData.result.formatted_phone_number) {
                enrichedData.phone = detailsData.result.formatted_phone_number;
              }
            }
          }
        }
      } catch (error) {
        console.error('Google Places API error:', error);
      }

      // 2. Check Street View availability
      try {
        const streetViewUrl = `https://maps.googleapis.com/maps/api/streetview/metadata?location=${encodeURIComponent(customer.city + ' ' + customer.streetAddress)}&key=${googleMapsApiKey}`;
        const streetViewResponse = await fetch(streetViewUrl);
        const streetViewData = await streetViewResponse.json() as any;

        enrichedData.streetViewAvailable = streetViewData.status === 'OK' ? 1 : 0;
      } catch (error) {
        console.error('Street View API error:', error);
      }

      // 3. Check for Allegro presence
      try {
        const allegroSearchUrl = `https://www.google.com/search?q=site:allegro.pl+${encodeURIComponent(customer.contractorName)}`;
        // Note: For real Allegro detection, we'd need to implement web scraping or use Allegro API
        // For now, we'll check if the website contains allegro in subdomain or check manually
        if (enrichedData.website && enrichedData.website.includes('allegro')) {
          enrichedData.allegro = enrichedData.website;
        }
      } catch (error) {
        console.error('Allegro check error:', error);
      }

      // 4. Update customer with enriched data
      enrichedData.enrichedAt = new Date();

      const updatedCustomer = await storage.updateCustomer(req.params.id, enrichedData);

      const enrichedFields = Object.keys(enrichedData).filter(key => {
        const value = enrichedData[key];
        return value !== '' && value !== null && value !== undefined && key !== 'enrichedAt';
      });


      res.json({
        success: true,
        customer: updatedCustomer,
        enrichedFields: enrichedFields
      });

    } catch (error) {
      console.error('Customer enrichment error:', error);
      const errorMessage = error instanceof Error ? error.message : "Failed to enrich customer data";
      res.status(500).json({ 
        message: errorMessage,
        details: error instanceof Error ? error.stack : "Unknown error"
      });
    }
  });

  // AI enrichment endpoint for customers
  app.post("/api/customers/:id/ai-enrich", isAuthenticated, async (req, res) => {
    const { id } = req.params;
    console.log('=== CUSTOMER AI ENRICHMENT START ===', id);
    const googleMapsApiKeySetting = await storage.getSystemSetting('google_maps_api_key');
    if (!googleMapsApiKeySetting?.settingValue) {
      console.error('Google Maps API key is missing or incorrect');
    }
    const apiKeySetting = await storage.getSystemSetting('perplexity_api_key');
    if (!apiKeySetting?.settingValue) {
      console.error('Perplexity API key is missing or incorrect');
    }

    try {
      const customer = await storage.getCustomer(id);
      console.log('Found customer:', customer?.contractorName);

      if (!customer) {
        console.log('Customer not found, returning 404');
        return res.status(404).json({ message: "Customer not found" });
      }

      // Sprawdź czy funkcja AI jest włączona
      const aiEnabledSetting = await storage.getSystemSetting('ai_enrichment_enabled');
      if (aiEnabledSetting?.settingValue !== 'true') {
        return res.status(400).json({ message: "Funkcja wzbogacania AI jest wyłączona" });
      }

      // Sprawdź dostępność klucza API z ustawień lub zmiennych środowiskowych
      const apiKeySetting = await storage.getSystemSetting('perplexity_api_key');
      const perplexityApiKey = apiKeySetting?.settingValue || process.env.PERPLEXITY_API_KEY;
      console.log('API key check:', perplexityApiKey ? 'EXISTS' : 'MISSING');

      if (!perplexityApiKey) {
        console.log('Missing API key, returning error');
        return res.status(400).json({ message: "Brak klucza API Perplexity. Dodaj go w Ustawieniach → Klucze API" });
      }

      // Przygotuj zapytanie do AI z danymi customer
      const companyName = customer.contractorName || 'Nieznana firma';
      const fullAddress = `${customer.streetAddress || ''} ${customer.city || ''}`.trim();

      // Sprawdź czy jest niestandardowy prompt
      const customPrompt = req.body.customPrompt;

      let query;
      if (customPrompt) {
        // Użyj niestandardowego prompta
        query = `Firma: "${companyName}" z adresem "${fullAddress}" w Polsce.

        ${customPrompt}

        Poszukaj informacji specjalnie dla firmy Hecht Polska, koncentrując się na:
        - Zdjęciach lokalu/sklepu
        - Powierzchni sklepu
        - Potencjale sprzedażowym w złotówkach

        Odpowiedz szczegółowo.`;
      } else {
        // Pobierz pełny prompt z ustawień lub użyj domyślnego
        const promptSetting = await storage.getSystemSetting('ai_enrichment_prompt');
        const defaultPrompt = `Jesteś moim asystentem ds. badań rynku. Analizujesz WYŁĄCZNIE jedną firmę wskazaną poniżej. Ignorujesz wszystkie inne o podobnej nazwie. Pisz po polsku.

NAZWA_FIRMY: [NAZWA_FIRMY]
ADRES: [ADRES]
BRANZA: sprzedaż urządzeń ogrodniczych

REGUŁY DOPASOWANIA (globalne):
- Zaakceptuj wynik TYLKO, jeśli zgadza się co najmniej 1 z pól: dokładny adres LUB telefon LUB e-mail. Miasto MUSI być identyczne.
- Jeśli nie masz pewności co do zgodności – zwróć „nie znaleziono" dla danej rubryki.
- Nie podawaj danych firm z innymi miastami/adresami, nawet przy podobnej nazwie.

ZASADY LINKÓW:
- Gdy pole wymaga linku – zwróć WYŁĄCZNIE czysty URL (https://...), bez opisu/tytułu/tekstu kotwicy.
- Wszystkie źródła zbiorczo podaj w polu "sources" jako listę URL.

POWIERZCHNIA SKLEPU – SZACOWANIE:
- Jeśli brak oficjalnych danych, wykonaj OSZACOWANIE na podstawie zdjęć (wnętrze + zewnątrz), Google Maps/Street View.
- Stosuj prosty model (np. szerokość frontu × głębokość, liczba alejek × szerokość, układ regałów).
- Podaj wartość zaokrągloną do najbliższych 5 m².

Zwróć WYŁĄCZNIE poprawny JSON zgodny ze schematem:
{
  "company": {
    "name": "string",
    "address": "string", 
    "phone": "string | nie znaleziono",
    "email": "string | nie znaleziono",
    "industry": "string"
  },
  "brands": [
    { "name": "string", "logo_url": "https://... | nie znaleziono" }
  ],
  "online_shop_url": "https://... | nie znaleziono",
  "allegro_url": "https://... | nie znaleziono", 
  "facebook_url": "https://... | nie znaleziono",
  "founded_year": "YYYY | nie znaleziono",
  "financial_risk": {
    "has_issues": true | false | "nie znaleziono",
    "source_url": "https://... | nie znaleziono"
  },
  "photos": {
    "exterior": ["https://...", "https://...", "https://..."],
    "interior": ["https://...", "https://...", "https://..."]
  },
  "store_area_m2": {
    "value": number | "nie znaleziono",
    "is_estimate": true | false,
    "estimation_method": "string | nie znaleziono"
  },
  "sales_potential_pln": {
    "value": number,
    "estimation_basis": "krótka podstawa oszacowania"
  },
  "street_view_url": "https://... | nie znaleziono",
  "sources": ["https://...", "https://..."]
}`;

        const userPrompt = promptSetting?.settingValue || defaultPrompt;

        // Użyj pełnego prompta z ustawień z podstawieniami zmiennych
        query = userPrompt
          .replace(/\[NAZWA_FIRMY\]/g, companyName)
          .replace(/\[ADRES\]/g, fullAddress);


      }

      // Wywołaj Perplexity AI
      console.log('Calling Perplexity API for customer:', companyName, 'at', fullAddress);
      const perplexityResponse = await fetch('https://api.perplexity.ai/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${perplexityApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'sonar',
          messages: [
            {
              role: 'system',
              content: 'Jesteś asystentem do wyszukiwania informacji o polskich firmach. Wyszukuj zawsze używając NAZWY FIRMY I ADRESU aby uniknąć pomyłek. Odpowiadaj precyzyjnie w formacie JSON.',
            },
            {
              role: 'user',
              content: query,
            },
          ],
          max_tokens: 1000,
          temperature: 0.2,
          search_recency_filter: 'month',
          return_images: false,
          return_related_questions: false,
        }),
      });

      console.log('Perplexity API status:', perplexityResponse.status);
      if (!perplexityResponse.ok) {
        const errorText = await perplexityResponse.text();
        console.error('Perplexity API error:', errorText);
        throw new Error(`Perplexity API error: ${perplexityResponse.status}`);
      }

      const data = await perplexityResponse.json() as any;
      console.log('Perplexity API response received');

      const aiResponse = data.choices?.[0]?.message?.content;
      console.log('AI Response length:', aiResponse?.length || 0);
      console.log('Full AI Response:', aiResponse);

      let enrichedData: any = {};

      if (aiResponse) {
        if (customPrompt) {
          // Dla niestandardowego prompta, zapisz odpowiedź jako tekst
          enrichedData = {
            notes: aiResponse.trim(),
          };
          console.log('Custom prompt enriched data:', enrichedData);
        } else {
          // Dla standardowego prompta, spróbuj sparsować JSON
          try {
            const jsonMatch = aiResponse.match(/\{[\s\S]*\}/);
            console.log('JSON match found:', !!jsonMatch);
            if (jsonMatch) {
              const aiResult = JSON.parse(jsonMatch[0]);
              console.log('Successfully parsed AI result:', aiResult);

              // Zapisz pełne dane JSON jako notes
              enrichedData = {
                notes: JSON.stringify(aiResult, null, 2),
                enrichedAt: new Date(),
              };
              console.log('Standard enriched data:', enrichedData);
            } else {
              console.log('No JSON found, using raw response');
              enrichedData = {
                notes: `Odpowiedź AI: ${aiResponse}`,
                enrichedAt: new Date(),
              };
            }
          } catch (parseError) {
            console.error('Error parsing AI response:', parseError);
            const errorMessage = parseError instanceof Error ? parseError.message : 'Unknown error';
            enrichedData = {
              notes: `Błąd parsowania odpowiedzi AI: ${errorMessage}\nOryginal: ${aiResponse}`,
              enrichedAt: new Date(),
            };
          }
        }
      } else {
        console.log('No AI response received');
        enrichedData = {
          notes: `Brak odpowiedzi AI dla firmy: ${companyName}`,
          enrichedAt: new Date(),
        };
      }

      // Upewnij się że mamy co najmniej jedno pole do aktualizacji
      if (Object.keys(enrichedData).length === 0) {
        enrichedData = { notes: `Wzbogacone: ${new Date().toISOString()}` };
      }

      const updatedCustomer = await storage.updateCustomer(id, enrichedData);

      // Dodaj aktywność o wzbogaceniu danych
      await storage.createActivity({
        customerId: id,
        type: "note",
        description: `Dane wzbogacone automatycznie przez AI dla firmy: ${customer.contractorName}`,
        salesperson: "System AI",
      });

      res.json(updatedCustomer);
    } catch (error) {
      console.error("Error enriching customer:", error);
      res.status(500).json({ message: "Failed to enrich customer data" });
    }
  });

  // Prospect routes
  app.get("/api/prospects", isAuthenticated, async (req, res) => {
    try {
      const prospects = await storage.getProspects();
      res.json(prospects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch prospects" });
    }
  });

  app.get("/api/prospects/:id", isAuthenticated, async (req, res) => {
    try {
      const prospect = await storage.getProspect(req.params.id);
      if (!prospect) {
        return res.status(404).json({ message: "Prospect not found" });
      }
      res.json(prospect);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch prospect" });
    }
  });


  app.post("/api/prospects", isAuthenticated, async (req, res) => {
    try {
      const prospectData = insertProspectSchema.parse(req.body);
      const prospect = await storage.createProspect(prospectData);
      res.status(201).json(prospect);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid prospect data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create prospect" });
    }
  });

  app.post("/api/prospects/:id/enrich", isAuthenticated, async (req, res) => {
    const { id } = req.params;
    console.log('=== ENRICHMENT START ===', id);

    try {
      const prospect = await storage.getProspect(id);
      console.log('Found prospect:', prospect?.contractorName);

      if (!prospect) {
        console.log('Prospect not found, returning 404');
        return res.status(404).json({ message: "Prospect not found" });
      }

      // Sprawdź czy funkcja AI jest włączona
      const aiEnabledSetting = await storage.getSystemSetting('ai_enrichment_enabled');
      if (aiEnabledSetting?.settingValue !== 'true') {
        return res.status(400).json({ message: "Funkcja wzbogacania AI jest wyłączona" });
      }

      // Sprawdź dostępność klucza API z ustawień lub zmiennych środowiskowych
      const apiKeySetting = await storage.getSystemSetting('perplexity_api_key');
      const perplexityApiKey = apiKeySetting?.settingValue || process.env.PERPLEXITY_API_KEY;
      console.log('API key check:', perplexityApiKey ? 'EXISTS' : 'MISSING');

      if (!perplexityApiKey) {
        console.log('Missing API key, returning error');
        return res.status(400).json({ message: "Brak klucza API Perplexity. Dodaj go w Ustawieniach → Klucze API" });
      }

      // Przygotuj zapytanie do AI z danymi prospect
      const companyName = prospect.contractorName || 'Nieznana firma';
      const fullAddress = `${prospect.streetAddress || ''} ${prospect.postalCode || ''} ${prospect.city || ''}`.trim();

      // Sprawdź czy jest niestandardowy prompt
      const customPrompt = req.body.customPrompt;

      let query;
      if (customPrompt) {
        // Użyj niestandardowego prompta
        query = `Firma: "${companyName}" z adresem "${fullAddress}" w Polsce.

        ${customPrompt}

        Poszukaj informacji specjalnie dla firmy Hecht Polska, koncentrując się na:
        - Zdjęciach lokalu/sklepu
        - Powierzchni sklepu
        - Potencjale sprzedażowym w złotówkach

        Odpowiedz szczegółowo.`;
      } else {
        // Pobierz pełny prompt z ustawień lub użyj domyślnego
        const promptSetting = await storage.getSystemSetting('ai_enrichment_prompt');
        const defaultPrompt = `Jesteś moim asystentem ds. badań rynku. Analizujesz WYŁĄCZNIE jedną firmę wskazaną poniżej. Ignorujesz wszystkie inne o podobnej nazwie. Pisz po polsku.

NAZWA_FIRMY: [NAZWA_FIRMY]
ADRES: [ADRES]
BRANZA: sprzedaż urządzeń ogrodniczych

REGUŁY DOPASOWANIA (globalne):
- Zaakceptuj wynik TYLKO, jeśli zgadza się co najmniej 1 z pól: dokładny adres LUB telefon LUB e-mail. Miasto MUSI być identyczne.
- Jeśli nie masz pewności co do zgodności – zwróć „nie znaleziono" dla danej rubryki.
- Nie podawaj danych firm z innymi miastami/adresami, nawet przy podobnej nazwie.

ZASADY LINKÓW:
- Gdy pole wymaga linku – zwróć WYŁĄCZNIE czysty URL (https://...), bez opisu/tytułu/tekstu kotwicy.
- Wszystkie źródła zbiorczo podaj w polu "sources" jako listę URL.

POWIERZCHNIA SKLEPU – SZACOWANIE:
- Jeśli brak oficjalnych danych, wykonaj OSZACOWANIE na podstawie zdjęć (wnętrze + zewnątrz), Google Maps/Street View.
- Stosuj prosty model (np. szerokość frontu × głębokość, liczba alejek × szerokość, układ regałów).
- Podaj wartość zaokrągloną do najbliższych 5 m².

Zwróć WYŁĄCZNIE poprawny JSON zgodny ze schematem:
{
  "company": {
    "name": "string",
    "address": "string", 
    "phone": "string | nie znaleziono",
    "email": "string | nie znaleziono",
    "industry": "string"
  },
  "brands": [
    { "name": "string", "logo_url": "https://... | nie znaleziono" }
  ],
  "online_shop_url": "https://... | nie znaleziono",
  "allegro_url": "https://... | nie znaleziono", 
  "facebook_url": "https://... | nie znaleziono",
  "founded_year": "YYYY | nie znaleziono",
  "financial_risk": {
    "has_issues": true | false | "nie znaleziono",
    "source_url": "https://... | nie znaleziono"
  },
  "photos": {
    "exterior": ["https://...", "https://...", "https://..."],
    "interior": ["https://...", "https://...", "https://..."]
  },
  "store_area_m2": {
    "value": number | "nie znaleziono",
    "is_estimate": true | false,
    "estimation_method": "string | nie znaleziono"
  },
  "sales_potential_pln": {
    "value": number,
    "estimation_basis": "krótka podstawa oszacowania"
  },
  "street_view_url": "https://... | nie znaleziono",
  "sources": ["https://...", "https://..."]
}`;

        const userPrompt = promptSetting?.settingValue || defaultPrompt;

        // Użyj pełnego prompta z ustawień z podstawieniami zmiennych
        query = userPrompt
          .replace(/\[NAZWA_FIRMY\]/g, companyName)
          .replace(/\[ADRES\]/g, fullAddress);


      }

      // Wywołaj Perplexity AI
      console.log('Calling Perplexity API for:', companyName, 'at', fullAddress);
      const perplexityResponse = await fetch('https://api.perplexity.ai/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${perplexityApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'sonar',
          messages: [
            {
              role: 'system',
              content: 'Jesteś asystentem do wyszukiwania informacji o polskich firmach. Wyszukuj zawsze używając NAZWY FIRMY I ADRESU aby uniknąć pomyłek. Odpowiadaj precyzyjnie w formacie JSON.',
            },
            {
              role: 'user',
              content: query,
            },
          ],
          max_tokens: 1000,
          temperature: 0.2,
          search_recency_filter: 'month',
          return_images: false,
          return_related_questions: false,
        }),
      });

      console.log('Perplexity API status:', perplexityResponse.status);
      if (!perplexityResponse.ok) {
        const errorText = await perplexityResponse.text();
        console.error('Perplexity API error:', errorText);
        throw new Error(`Perplexity API error: ${perplexityResponse.status}`);
      }

      const aiData: any = await perplexityResponse.json();
      let enrichedData: any = {
        notes: `Wzbogacone automatycznie dla: ${companyName}`,
      };

      if (aiData.choices && aiData.choices[0]) {
        try {
          const content = aiData.choices[0].message.content;
          console.log('AI Response:', content);

          // Próbuj sparsować JSON lub wyciągnij informacje tekstowo
          if (customPrompt) {
            // Dla niestandardowego prompta użyj pełnej odpowiedzi
            enrichedData = {
              notes: content.substring(0, 1000), // Maksymalnie 1000 znaków
            };
          } else {
            // Dla standardowego prompta parsuj JSON
            try {
              const aiResult = JSON.parse(content);

              // Stwórz czytelne podsumowanie
              const summary = [];
              if (aiResult.hasGardenEquipment) summary.push("🌿 Sprzęt ogrodniczy");
              if (aiResult.hasOnlineStore) summary.push("🛒 Sklep online");
              if (aiResult.allegroStore) summary.push("🏪 Allegro");
              if (aiResult.facebookUrl) summary.push("📘 Facebook");
              if (aiResult.foundedYear) summary.push(`📅 Założona: ${aiResult.foundedYear}`);
              if (aiResult.storeArea) summary.push(`📏 Powierzchnia: ${aiResult.storeArea}`);
              if (aiResult.salesPotential) summary.push(`💰 Potencjał: ${aiResult.salesPotential}`);
              if (aiResult.debtStatus) summary.push(`⚠️ Status: ${aiResult.debtStatus}`);
              if (aiResult.googleMapsPhotos && Array.isArray(aiResult.googleMapsPhotos) && aiResult.googleMapsPhotos.length > 0) {
                summary.push(`📸 Zdjęcia: ${aiResult.googleMapsPhotos.length}`);
              }
              if (aiResult.streetViewUrl) summary.push(`🗺️ Street View`);

              const readableNotes = summary.length > 0
                ? `${aiResult.businessDescription || 'Informacje o firmie'}: ${summary.join(', ')}`
                : `Brak szczegółowych informacji o firmie ${companyName}`;

              enrichedData = {
                notes: readableNotes,
                email: aiResult.allegroStore ? `${companyName.toLowerCase().replace(/\s+/g, '')}@allegro.pl` : '',
              };
            } catch (jsonError) {
              // Wyciągnij kluczowe informacje z tekstu
              const hasGarden = content.toLowerCase().includes('ogrodnicze') || content.toLowerCase().includes('kosiark');
              const hasOnline = content.toLowerCase().includes('sklep') || content.toLowerCase().includes('online') || content.toLowerCase().includes('internetow');
              const hasAllegro = content.toLowerCase().includes('allegro');
              const hasFacebook = content.toLowerCase().includes('facebook');

              const summary = [];
              if (hasGarden) summary.push("🌿 Prawdopodobnie sprzęt ogrodniczy");
              if (hasOnline) summary.push("🛒 Prawdopodobnie sklep online");
              if (hasAllegro) summary.push("🏪 Allegro");
              if (hasFacebook) summary.push("📘 Facebook");

              enrichedData = {
                notes: summary.length > 0
                  ? `Analiza AI: ${summary.join(', ')}`
                  : `Analiza AI: ${content.substring(0, 100)}...`,
              };
            }
          }
        } catch (parseError) {
          console.error('Error parsing AI response:', parseError);
          enrichedData = {
            notes: `Brak danych AI dla firmy: ${companyName}`,
            email: prospect.email || `kontakt@${companyName.toLowerCase().replace(/\s+/g, '')}.pl`,
          };
        }
      } else {
        enrichedData = {
          notes: `Brak odpowiedzi AI dla firmy: ${companyName}`,
        };
      }

      // Upewnij się że mamy co najmniej jedno pole do aktualizacji
      if (Object.keys(enrichedData).length === 0) {
        enrichedData = { notes: `Wzbogacone: ${new Date().toISOString()}` };
      }

      const updatedProspect = await storage.updateProspect(id, enrichedData);

      // Dodaj aktywność o wzbogaceniu danych
      await storage.createActivity({
        prospectId: id,
        type: "note",
        description: `Dane wzbogacone automatycznie przez AI dla firmy: ${prospect.contractorName}`,
        salesperson: "System AI",
      });

      res.json(updatedProspect);
    } catch (error) {
      console.error("Error enriching prospect:", error);
      res.status(500).json({ message: "Failed to enrich prospect data" });
    }
  });

  app.put("/api/prospects/:id", isAuthenticated, async (req, res) => {
    try {
      const prospectData = insertProspectSchema.partial().parse(req.body);
      const prospect = await storage.updateProspect(req.params.id, prospectData);
      res.json(prospect);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid prospect data", errors: error.errors });
      }
      if (error instanceof Error && error.message === "Prospect not found") {
        return res.status(404).json({ message: "Prospect not found" });
      }
      res.status(500).json({ message: "Failed to update prospect" });
    }
  });

  app.delete("/api/prospects/:id", isAuthenticated, async (req, res) => {
    try {
      const deleted = await storage.deleteProspect(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Prospect not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete prospect" });
    }
  });

  // AI enrichment endpoint for prospects
  app.post("/api/prospects/:id/ai-enrich", isAuthenticated, async (req, res) => {
    const { id } = req.params;
    console.log('=== PROSPECT AI ENRICHMENT START ===', id);

    try {
      const prospect = await storage.getProspect(id);
      console.log('Found prospect:', prospect?.contractorName);

      if (!prospect) {
        console.log('Prospect not found, returning 404');
        return res.status(404).json({ message: "Prospect not found" });
      }

      // Sprawdź czy funkcja AI jest włączona
      const aiEnabledSetting = await storage.getSystemSetting('ai_enrichment_enabled');
      if (aiEnabledSetting?.settingValue !== 'true') {
        return res.status(400).json({ message: "Funkcja wzbogacania AI jest wyłączona" });
      }

      // Sprawdź dostępność klucza API z ustawień lub zmiennych środowiskowych
      const apiKeySetting = await storage.getSystemSetting('perplexity_api_key');
      const perplexityApiKey = apiKeySetting?.settingValue || process.env.PERPLEXITY_API_KEY;
      console.log('API key check:', perplexityApiKey ? 'EXISTS' : 'MISSING');

      if (!perplexityApiKey) {
        console.log('Missing API key, returning error');
        return res.status(400).json({ message: "Brak klucza API Perplexity. Dodaj go w Ustawieniach → Klucze API" });
      }

      // Przygotuj zapytanie do AI z danymi prospect
      const companyName = prospect.contractorName || 'Nieznana firma';
      const fullAddress = `${prospect.streetAddress || ''} ${prospect.postalCode || ''} ${prospect.city || ''}`.trim();

      // Sprawdź czy jest niestandardowy prompt
      const customPrompt = req.body.customPrompt;

      let query;
      if (customPrompt) {
        // Użyj niestandardowego prompta
        query = `Firma: "${companyName}" z adresem "${fullAddress}" w Polsce.

        ${customPrompt}

        Poszukaj informacji specjalnie dla firmy Hecht Polska, koncentrując się na:
        - Zdjęciach lokalu/sklepu
        - Powierzchni sklepu
        - Potencjale sprzedażowym w złotówkach

        Odpowiedz szczegółowo.`;
      } else {
        // Pobierz pełny prompt z ustawień lub użyj domyślnego
        const promptSetting = await storage.getSystemSetting('ai_enrichment_prompt');
        const defaultPrompt = `Jesteś moim asystentem ds. badań rynku. Analizujesz WYŁĄCZNIE jedną firmę wskazaną poniżej. Ignorujesz wszystkie inne o podobnej nazwie. Pisz po polsku.

NAZWA_FIRMY: [NAZWA_FIRMY]
ADRES: [ADRES]
BRANZA: sprzedaż urządzeń ogrodniczych

REGUŁY DOPASOWANIA (globalne):
- Zaakceptuj wynik TYLKO, jeśli zgadza się co najmniej 1 z pól: dokładny adres LUB telefon LUB e-mail. Miasto MUSI być identyczne.
- Jeśli nie masz pewności co do zgodności – zwróć „nie znaleziono" dla danej rubryki.
- Nie podawaj danych firm z innymi miastami/adresami, nawet przy podobnej nazwie.

ZASADY LINKÓW:
- Gdy pole wymaga linku – zwróć WYŁĄCZNIE czysty URL (https://...), bez opisu/tytułu/tekstu kotwicy.
- Wszystkie źródła zbiorczo podaj w polu "sources" jako listę URL.

POWIERZCHNIA SKLEPU – SZACOWANIE:
- Jeśli brak oficjalnych danych, wykonaj OSZACOWANIE na podstawie zdjęć (wnętrze + zewnątrz), Google Maps/Street View.
- Stosuj prosty model (np. szerokość frontu × głębokość, liczba alejek × szerokość, układ regałów).
- Podaj wartość zaokrągloną do najbliższych 5 m².

Zwróć WYŁĄCZNIE poprawny JSON zgodny ze schematem:
{
  "company": {
    "name": "string",
    "address": "string", 
    "phone": "string | nie znaleziono",
    "email": "string | nie znaleziono",
    "industry": "string"
  },
  "brands": [
    { "name": "string", "logo_url": "https://... | nie znaleziono" }
  ],
  "online_shop_url": "https://... | nie znaleziono",
  "allegro_url": "https://... | nie znaleziono", 
  "facebook_url": "https://... | nie znaleziono",
  "founded_year": "YYYY | nie znaleziono",
  "financial_risk": {
    "has_issues": true | false | "nie znaleziono",
    "source_url": "https://... | nie znaleziono"
  },
  "photos": {
    "exterior": ["https://...", "https://...", "https://..."],
    "interior": ["https://...", "https://...", "https://..."]
  },
  "store_area_m2": {
    "value": number | "nie znaleziono",
    "is_estimate": true | false,
    "estimation_method": "string | nie znaleziono"
  },
  "sales_potential_pln": {
    "value": number,
    "estimation_basis": "krótka podstawa oszacowania"
  },
  "street_view_url": "https://... | nie znaleziono",
  "sources": ["https://...", "https://..."]
}`;

        const userPrompt = promptSetting?.settingValue || defaultPrompt;

        // Standardowy prompt
        query = `WAŻNE: Wyszukaj dokładne informacje TYLKO o firmie "${companyName}" zlokalizowanej DOKŁADNIE pod adresem "${fullAddress}" w Polsce. NIE szukaj innych firm o podobnej nazwie z innych miast/adresów.

        ${userPrompt}

        UWAGA: Jeśli nie znajdziesz tej konkretnej firmy z tym adresem, napisz że "nie znaleziono". NIE podawaj informacji o innych firmach.

        Odpowiedz w formacie JSON:
        {
          "hasGardenEquipment": true/false,
          "hasOnlineStore": true/false, 
          "allegroStore": "dokładny link lub pusty string",
          "facebookUrl": "dokładny link lub pusty string",
          "foundedYear": "rok lub pusty string",
          "debtStatus": "opis statusu lub pusty string",
          "businessDescription": "krótki opis działalności",
          "storeArea": "powierzchnia sklepu w m² lub pusty string",
          "salesPotential": "potencjał sprzedażowy w zł lub pusty string",
          "googleMapsPhotos": "array 6 linków do zdjęć lub pusty array",
          "streetViewUrl": "link Google Street View lub pusty string",
          "confidence": "high/medium/low - pewność że to właściwa firma"
        }`;
      }

      // Wywołaj Perplexity AI
      console.log('Calling Perplexity API for prospect:', companyName, 'at', fullAddress);
      const perplexityResponse = await fetch('https://api.perplexity.ai/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${perplexityApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'sonar',
          messages: [
            {
              role: 'system',
              content: 'Jesteś asystentem do wyszukiwania informacji o polskich firmach. Wyszukuj zawsze używając NAZWY FIRMY I ADRESU aby uniknąć pomyłek. Odpowiadaj precyzyjnie w formacie JSON.',
            },
            {
              role: 'user',
              content: query,
            },
          ],
          max_tokens: 1000,
          temperature: 0.2,
          search_recency_filter: 'month',
          return_images: false,
          return_related_questions: false,
        }),
      });

      console.log('Perplexity API status:', perplexityResponse.status);
      if (!perplexityResponse.ok) {
        const errorText = await perplexityResponse.text();
        console.error('Perplexity API error:', errorText);
        throw new Error(`Perplexity API error: ${perplexityResponse.status}`);
      }

      const data = await perplexityResponse.json() as any;
      console.log('Perplexity API response received');

      const aiResponse = data.choices?.[0]?.message?.content;
      console.log('AI Response length:', aiResponse?.length || 0);

      let enrichedData: any = {};

      if (aiResponse) {
        if (customPrompt) {
          // Dla niestandardowego prompta, zapisz odpowiedź jako tekst
          enrichedData = {
            notes: aiResponse.trim(),
          };
        } else {
          // Dla standardowego prompta, spróbuj sparsować JSON
          try {
            const jsonMatch = aiResponse.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
              const aiResult = JSON.parse(jsonMatch[0]);
              console.log('Parsed AI result:', aiResult);

              // Obsługuj zarówno stary jak i nowy format JSON
              let convertedData;
              if (aiResult.company) {
                // Nowy format z obiektem "company"
                convertedData = {
                  hasGardenEquipment: true, // Zakładam że jeśli jest w systemie to ma sprzęt
                  hasOnlineStore: aiResult.online_shop_url !== "nie znaleziono",
                  allegroStore: aiResult.allegro_url !== "nie znaleziono" ? aiResult.allegro_url : "",
                  facebookUrl: aiResult.facebook_url !== "nie znaleziono" ? aiResult.facebook_url : "",
                  foundedYear: aiResult.founded_year !== "nie znaleziono" ? aiResult.founded_year : "",
                  debtStatus: aiResult.financial_risk?.has_issues ? "Tak" : "",
                  businessDescription: aiResult.company.industry || "",
                  storeArea: aiResult.store_area_m2?.value ? `${aiResult.store_area_m2.value} m²` : "",
                  salesPotential: aiResult.sales_potential_pln?.value ? `${aiResult.sales_potential_pln.value} PLN` : "",
                  googleMapsPhotos: [...(aiResult.photos?.exterior || []), ...(aiResult.photos?.interior || [])],
                  streetViewUrl: aiResult.street_view_url !== "nie znaleziono" ? aiResult.street_view_url : "",
                  confidence: "high",
                  brands: aiResult.brands || [],
                  sources: aiResult.sources || []
                };
                console.log('Converted new format to old:', convertedData);
              } else {
                // Stary format - bez zmian
                convertedData = aiResult;
              }

              enrichedData = {
                notes: JSON.stringify(convertedData, null, 2), // Zapisz pełne dane JSON
              };
            } else {
              enrichedData = {
                notes: `Odpowiedź AI: ${aiResponse}`,
              };
            }
          } catch (parseError) {
            console.error('Error parsing AI response:', parseError);
            enrichedData = {
              notes: `Brak danych AI dla firmy: ${companyName}`,
            };
          }
        }
      } else {
        enrichedData = {
          notes: `Brak odpowiedzi AI dla firmy: ${companyName}`,
        };
      }

      // Upewnij się że mamy co najmniej jedno pole do aktualizacji
      if (Object.keys(enrichedData).length === 0) {
        enrichedData = { notes: `Wzbogacone: ${new Date().toISOString()}` };
      }

      const updatedProspect = await storage.updateProspect(id, enrichedData);

      // Dodaj aktywność o wzbogaceniu danych
      await storage.createActivity({
        prospectId: id,
        type: "note",
        description: `Dane wzbogacone automatycznie przez AI dla firmy: ${prospect.contractorName}`,
        salesperson: "System AI",
      });

      res.json(updatedProspect);
    } catch (error) {
      console.error("Error enriching prospect:", error);
      res.status(500).json({ message: "Failed to enrich prospect data" });
    }
  });

  // Task routes
  app.get("/api/tasks", isAuthenticated, async (req, res) => {
    try {
      const tasks = await storage.getTasksWithRelations();
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.get("/api/tasks/:id", isAuthenticated, async (req, res) => {
    try {
      const task = await storage.getTask(req.params.id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      res.json(task);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch task" });
    }
  });

  app.post("/api/tasks", isAuthenticated, async (req, res) => {
    try {
      const taskData = insertTaskSchema.parse(req.body);
      const task = await storage.createTask(taskData);
      res.status(201).json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid task data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create task" });
    }
  });

  app.put("/api/tasks/:id", isAuthenticated, async (req, res) => {
    try {
      const taskData = insertTaskSchema.partial().parse(req.body);
      const task = await storage.updateTask(req.params.id, taskData);
      res.json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid task data", errors: error.errors });
      }
      if (error instanceof Error && error.message === "Task not found") {
        return res.status(404).json({ message: "Task not found" });
      }
      res.status(500).json({ message: "Failed to update task" });
    }
  });

  app.delete("/api/tasks/:id", isAuthenticated, async (req, res) => {
    try {
      const deleted = await storage.deleteTask(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Task not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete task" });
    }
  });

  // Activity routes
  app.get("/api/activities", isAuthenticated, async (req, res) => {
    try {
      const activities = await storage.getActivitiesWithRelations();
      res.json(activities);
    } catch (error) {
      console.error("Error fetching activities:", error);
      res.status(500).json({ message: "Failed to fetch activities", error: String(error) });
    }
  });

  app.post("/api/activities", isAuthenticated, async (req, res) => {
    try {
      const activityData = insertActivitySchema.parse(req.body);
      const activity = await storage.createActivity(activityData);
      res.status(201).json(activity);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid activity data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create activity" });
    }
  });

  // Field Definition routes
  app.get("/api/field-definitions", isAuthenticated, async (req, res) => {
    try {
      const entityType = req.query.entityType as string;
      const fieldDefs = await storage.getFieldDefinitions();
      res.json(fieldDefs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch field definitions" });
    }
  });

  app.get("/api/field-definitions/:id", isAuthenticated, async (req, res) => {
    try {
      const fieldDef = await storage.getFieldDefinition(req.params.id);
      if (!fieldDef) {
        return res.status(404).json({ message: "Field definition not found" });
      }
      res.json(fieldDef);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch field definition" });
    }
  });

  app.post("/api/field-definitions", isAuthenticated, async (req, res) => {
    try {
      const fieldDefData = insertFieldDefinitionSchema.parse(req.body);
      const fieldDef = await storage.createFieldDefinition(fieldDefData);
      res.status(201).json(fieldDef);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid field definition data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create field definition" });
    }
  });

  // Batch update field order
  app.put("/api/field-definitions/reorder", isAuthenticated, async (req, res) => {
    try {
      const reorderSchema = z.object({
        fields: z.array(z.object({
          id: z.string(),
          displayOrder: z.number()
        }))
      });

      const { fields } = reorderSchema.parse(req.body);

      // Update each field's display order
      const updatedFields = [];
      for (const field of fields) {
        try {
          const updatedField = await storage.updateFieldDefinition(field.id, {
            displayOrder: field.displayOrder
          });
          updatedFields.push(updatedField);
        } catch (error) {
          console.error(`Failed to update field ${field.id}:`, error);
        }
      }

      res.json({
        success: true,
        updated: updatedFields.length,
        fields: updatedFields
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid reorder data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to reorder fields" });
    }
  });

  app.patch("/api/field-definitions/:id", isAuthenticated, async (req, res) => {
    try {
      const fieldDefData = insertFieldDefinitionSchema.partial().parse(req.body);
      const fieldDef = await storage.updateFieldDefinition(req.params.id, fieldDefData);
      res.json(fieldDef);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid field definition data", errors: error.errors });
      }
      if (error instanceof Error) {
        return res.status(400).json({ message: error.message });
      }
      res.status(500).json({ message: "Failed to update field definition" });
    }
  });

  app.delete("/api/field-definitions/:id", isAuthenticated, async (req, res) => {
    try {
      const success = await storage.deleteFieldDefinition(req.params.id);
      if (!success) {

  // Health Check endpoint
  app.get("/api/__health", async (req, res) => {
    res.status(200).json({ status: "healthy" });
  });

  // Self-Check endpoint
  app.get("/api/self-check", async (req, res) => {
    const googleMapsApiKeySetting = await storage.getSystemSetting('google_maps_api_key');
    const googleMapsApiKeyExists = !!googleMapsApiKeySetting?.settingValue || !!process.env.GOOGLE_MAPS_API_KEY;

    const apiKeySetting = await storage.getSystemSetting('perplexity_api_key');
    const perplexityApiKeyExists = !!apiKeySetting?.settingValue || !!process.env.PERPLEXITY_API_KEY;

    res.status(200).json({
      googleMapsKeyPresent: googleMapsApiKeyExists,
      perplexityApiKeyExists: perplexityApiKeyExists
    });
  });


        return res.status(404).json({ message: "Field definition not found" });
      }
      res.status(204).send();
    } catch (error) {
      if (error instanceof Error) {
        return res.status(400).json({ message: error.message });
      }
      res.status(500).json({ message: "Failed to delete field definition" });
    }
  });

  // User routes
  app.get("/api/users", isAuthenticated, async (req, res) => {
    try {
      const users = await storage.getUsers();
      // Nie zwracamy haseł w odpowiedzi
      const usersWithoutPasswords = users.map(({password, ...user}) => user);
      res.json(usersWithoutPasswords);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      // Nie zwracamy hasła w odpowiedzi
      const {password, ...userWithoutPassword} = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Hash the password before storing
      if (userData.password) {
        userData.password = await bcrypt.hash(userData.password, 10);
      }
      
      const user = await storage.createUser(userData);
      // Nie zwracamy hasła w odpowiedzi
      const {password, ...userWithoutPassword} = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  app.patch("/api/users/:id", async (req, res) => {
    try {
      const userData = insertUserSchema.partial().parse(req.body);
      
      // Hash the password if it's being updated
      if (userData.password) {
        userData.password = await bcrypt.hash(userData.password, 10);
      }
      
      const user = await storage.updateUser(req.params.id, userData);
      // Nie zwracamy hasła w odpowiedzi
      const {password, ...userWithoutPassword} = user;
      res.json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      if (error instanceof Error) {
        return res.status(400).json({ message: error.message });
      }
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  app.delete("/api/users/:id", async (req, res) => {
    try {
      const success = await storage.deleteUser(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "User not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  // System Settings routes
  app.get("/api/settings", isAuthenticated, async (req, res) => {
    try {
      const category = req.query.category as string;
      if (category) {
        const settings = await storage.getSystemSettingsByCategory(category);
        res.json(settings);
      } else {
        const settings = await storage.getSystemSettings();
        res.json(settings);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch system settings" });
    }
  });

  app.get("/api/settings/:key", isAuthenticated, async (req, res) => {
    try {
      const setting = await storage.getSystemSetting(req.params.key);
      if (!setting) {
        return res.status(404).json({ message: "Setting not found" });
      }
      res.json(setting);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch setting" });
    }
  });

  app.post("/api/settings", isAuthenticated, async (req, res) => {
    try {
      const settingData = insertSystemSettingSchema.parse(req.body);
      const setting = await storage.createSystemSetting(settingData);
      res.status(201).json(setting);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid setting data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create setting" });
    }
  });

  app.patch("/api/settings/:key", isAuthenticated, async (req, res) => {
    try {
      const settingData = insertSystemSettingSchema.partial().parse(req.body);

      // Sprawdź czy ustawienie istnieje
      const existingSetting = await storage.getSystemSetting(req.params.key);

      if (!existingSetting) {
        // Utwórz nowe ustawienie
        const newSettingData = {
          settingKey: req.params.key,
          settingValue: settingData.settingValue || '',
          settingType: settingData.settingType || 'text',
          category: settingData.category || 'api',
          description: settingData.description || null,
        };
        const newSetting = await storage.createSystemSetting(newSettingData);
        return res.json(newSetting);
      } else {
        // Zaktualizuj istniejące
        const setting = await storage.updateSystemSetting(req.params.key, settingData);
        res.json(setting);
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid setting data", errors: error.errors });
      }
      if (error instanceof Error) {
        return res.status(400).json({ message: error.message });
      }
      res.status(500).json({ message: "Failed to update setting" });
    }
  });

  app.delete("/api/settings/:key", isAuthenticated, async (req, res) => {
    try {
      const success = await storage.deleteSystemSetting(req.params.key);
      if (!success) {
        return res.status(404).json({ message: "Setting not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete setting" });
    }
  });

  // Role Column Permissions routes
  app.get("/api/role-column-permissions/:role/:entityType", isAuthenticated, async (req, res) => {
    try {
      const { role, entityType } = req.params;
      const permissions = await storage.getRoleColumnPermissions(role, entityType);
      res.json(permissions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch role column permissions" });
    }
  });

  app.put("/api/role-column-permissions/:role/:entityType", isAuthenticated, async (req, res) => {
    try {
      const { role, entityType } = req.params;
      const permissions = req.body;

      if (!Array.isArray(permissions)) {
        return res.status(400).json({ message: "Permissions must be an array" });
      }

      const updatedPermissions = await storage.updateRoleColumnPermissions(role, entityType, permissions);
      res.json(updatedPermissions);
    } catch (error) {
      res.status(500).json({ message: "Failed to update role column permissions" });
    }
  });

  // Serve Google Maps images (proxy to avoid exposing API key)
  app.get("/api/google-maps/photo/:photoReference", isAuthenticated, async (req, res) => {
    try {
      const { photoReference } = req.params;
      const maxWidth = req.query.maxwidth || '400';
      const googleMapsApiKeySetting = await storage.getSystemSetting('google_maps_api_key');
      const googleMapsApiKey = googleMapsApiKeySetting?.settingValue || process.env.GOOGLE_MAPS_API_KEY;

      console.log(`Photo reference received: ${photoReference}`); // Log received photo reference

      if (!googleMapsApiKey) {
        console.warn('Missing Google Maps API key'); // Log missing API key
        return res.status(500).json({ message: "Google Maps API key not configured" });
      }

      const photoUrl = `https://maps.googleapis.com/maps/api/place/photo?maxwidth=${maxWidth}&photo_reference=${photoReference}&key=${googleMapsApiKey}`;

      console.log(`Generated Google Maps photo URL: ${photoUrl}`); // Log generated URL

      const response = await fetch(photoUrl);
      if (!response.ok) {
        console.error(`Failed to fetch photo, status: ${response.status}`); // Log fetch error
        return res.status(404).json({ message: "Image not found" });
      }

      // Forward the image with proper headers
      res.set({
        'Content-Type': response.headers.get('content-type') || 'image/jpeg',
        'Cache-Control': 'public, max-age=86400' // Cache for 24 hours
      });

      const buffer = await response.arrayBuffer();
      res.send(Buffer.from(buffer));
    } catch (error) {
      console.error('Photo proxy error:', error); // Log any errors
      res.status(500).json({ message: "Failed to fetch photo" });
    }
  });

  app.get("/api/google-maps/streetview", isAuthenticated, async (req, res) => {
    try {
      const { location, size = '600x400' } = req.query;
      const googleMapsApiKeySetting = await storage.getSystemSetting('google_maps_api_key');
      const googleMapsApiKey = googleMapsApiKeySetting?.settingValue || process.env.GOOGLE_MAPS_API_KEY;

      if (!googleMapsApiKey) {
        return res.status(500).json({ message: "Google Maps API key not configured" });
      }

      if (!location) {
        return res.status(400).json({ message: "Location parameter required" });
      }

      const streetViewUrl = `https://maps.googleapis.com/maps/api/streetview?size=${size}&location=${encodeURIComponent(location as string)}&key=${googleMapsApiKey}`;

      const response = await fetch(streetViewUrl);
      if (!response.ok) {
        return res.status(404).json({ message: "Street View image not found" });
      }

      // Forward the image with proper headers
      res.set({
        'Content-Type': response.headers.get('content-type') || 'image/jpeg',
        'Cache-Control': 'public, max-age=86400' // Cache for 24 hours
      });

      const buffer = await response.arrayBuffer();
      res.send(Buffer.from(buffer));
    } catch (error) {
      console.error('Street View proxy error:', error);
      res.status(500).json({ message: "Failed to fetch Street View image" });
    }
  });

  // Endpoint do wyszukiwania Place ID na podstawie nazwy firmy i adresu
  app.get("/api/google-places/find-place", isAuthenticated, async (req, res) => {
    try {
      const { input } = req.query;

      if (!input || typeof input !== 'string') {
        return res.status(400).json({ message: "Input parameter required (company name and address)" });
      }

      const googleMapsApiKeySetting = await storage.getSystemSetting('google_maps_api_key');
      const googleMapsApiKey = googleMapsApiKeySetting?.settingValue || process.env.GOOGLE_MAPS_API_KEY;

      if (!googleMapsApiKey) {
        return res.status(500).json({ message: "Google Maps API key not configured" });
      }

      // Wywołanie Google Places API - Find Place From Text
      const findPlaceUrl = `https://maps.googleapis.com/maps/api/place/findplacefromtext/json?input=${encodeURIComponent(input)}&inputtype=textquery&fields=place_id,name,formatted_address&key=${googleMapsApiKey}`;

      console.log(`Finding place for: ${input}`);

      const response = await fetch(findPlaceUrl);
      if (!response.ok) {
        return res.status(404).json({ message: "Place not found" });
      }

      const data = await response.json() as any;
      
      if (!data.candidates || data.candidates.length === 0) {
        return res.status(404).json({ message: "No places found" });
      }

      // Zwróć pierwszy wynik
      const place = data.candidates[0];
      res.json({
        place_id: place.place_id,
        name: place.name,
        formatted_address: place.formatted_address
      });

    } catch (error) {
      console.error('Error finding place:', error);
      res.status(500).json({ message: "Failed to find place" });
    }
  });

  // Endpoint do pobrania prawdziwych zdjęć z Google Places API
  app.get("/api/google-places/:placeId/photos", isAuthenticated, async (req, res) => {
    try {
      const { placeId } = req.params;

      // Pobierz klucz API z ustawień systemowych
      const googleMapsApiKeySetting = await storage.getSystemSetting('google_maps_api_key');
      const googleMapsApiKey = googleMapsApiKeySetting?.settingValue || process.env.GOOGLE_MAPS_API_KEY;

      if (!googleMapsApiKey) {
        return res.status(500).json({ message: "Google Maps API key not configured" });
      }

      // Pobierz szczegóły miejsca z polami photos
      const detailsResponse = await fetch(
        `https://maps.googleapis.com/maps/api/place/details/json?place_id=${placeId}&fields=photos&key=${googleMapsApiKey}`
      );

      if (!detailsResponse.ok) {
        return res.status(404).json({ message: "Place not found" });
      }

      const detailsData = await detailsResponse.json() as any;
      const photos = detailsData.result?.photos || [];

      if (photos.length === 0) {
        return res.json({ photos: [] });
      }

      // Generuj lokalne URL-e dla wszystkich zdjęć
      const photoUrls = photos.map((photo: any) => 
        `/api/google-maps/photo/${photo.photo_reference}`
      );

      res.json({ photos: photoUrls });
    } catch (error) {
      console.error('Error fetching place photos:', error);
      res.status(500).json({ message: "Failed to fetch place photos" });
    }
  });

  // Geocode address to coordinates - with fallback coordinates for Polish companies
  app.get("/api/google-maps/geocode", isAuthenticated, async (req, res) => {
    try {
      const { address } = req.query;

      if (!address || typeof address !== 'string') {
        return res.status(400).json({ message: "Address is required" });
      }

      // Fallback coordinates for major Polish cities/companies
      const fallbackCoordinates: { [key: string]: { lat: number, lng: number } } = {
        'ELEMAX': { lat: 52.2297, lng: 21.0122 }, // Warsaw area
        'Hecht Polska': { lat: 50.0647, lng: 19.9450 }, // Kraków
        'PPHU "AGRO-FIRMA"': { lat: 51.7592, lng: 19.4560 }, // Łódź
        'P.P.H.U. "KORBANEK"': { lat: 50.2649, lng: 19.0238 }, // Katowice
        'PPHU': { lat: 52.4064, lng: 16.9252 }, // Poznań
        'Golub': { lat: 53.1045837, lng: 19.0551237 }, // Golub-Dobrzyń
        'Warszawa': { lat: 52.2297, lng: 21.0122 },
        'Kraków': { lat: 50.0647, lng: 19.9450 },
        'Łódź': { lat: 51.7592, lng: 19.4560 },
        'Gdańsk': { lat: 54.3520, lng: 18.6466 },
        'Wrocław': { lat: 51.1079, lng: 17.0385 },
        'Poznań': { lat: 52.4064, lng: 16.9252 },
        'Szczecin': { lat: 53.4285, lng: 14.5528 }
      };

      // Check if address contains any known company or city
      for (const [key, coords] of Object.entries(fallbackCoordinates)) {
        if (address.toLowerCase().includes(key.toLowerCase())) {
          return res.json(coords);
        }
      }

      // Default coordinates for Poland center if nothing matches
      res.json({ lat: 51.9194, lng: 19.1451 });
    } catch (error) {
      console.error('Error geocoding address:', error);
      res.status(500).json({ message: "Failed to geocode address" });
    }
  });

  // Get place geometry (coordinates) for Street View
  app.get("/api/google-maps/place-details-geometry", isAuthenticated, async (req, res) => {
    try {
      const { placeId } = req.query;

      if (!placeId || typeof placeId !== 'string') {
        return res.status(400).json({ message: "Place ID is required" });
      }

      // Return demo coordinates for the demo place ID
      if (placeId === "ChIJBxiT_NpbFkcRwalwOKUXSzw") {
        return res.json({ lat: 50.0647, lng: 19.9450 }); // Krakow coordinates
      }

      // Return coordinates for K. Bejger COMPLEX
      if (placeId === "ChIJ8SMjYz4Z5kcR-FUAV8L9fXc") {
        return res.json({ lat: 53.1045837, lng: 19.0551237 }); // Golub-Dobrzyń coordinates
      }

      const googleMapsApiKeySetting = await storage.getSystemSetting('google_maps_api_key');
      const googleMapsApiKey = googleMapsApiKeySetting?.settingValue || process.env.GOOGLE_MAPS_API_KEY;

      if (!googleMapsApiKey) {
        return res.status(500).json({ message: "Google Maps API key not configured" });
      }

      // Pobierz szczegóły miejsca z polami geometry
      const detailsResponse = await fetch(
        `https://maps.googleapis.com/maps/api/place/details/json?place_id=${placeId}&fields=geometry&key=${googleMapsApiKey}`
      );

      if (!detailsResponse.ok) {
        return res.status(404).json({ message: "Place not found" });
      }

      const detailsData = await detailsResponse.json() as any;
      const location = detailsData.result?.geometry?.location;

      if (!location) {
        return res.status(404).json({ message: "No geometry data found" });
      }

      res.json({ lat: location.lat, lng: location.lng });
    } catch (error) {
      console.error('Error fetching place geometry:', error);
      res.status(500).json({ message: "Failed to fetch place geometry" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}