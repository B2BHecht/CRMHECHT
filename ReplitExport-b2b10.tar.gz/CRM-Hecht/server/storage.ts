import { 
  type Customer, 
  type InsertCustomer, 
  type Prospect, 
  type InsertProspect,
  type Task,
  type InsertTask,
  type Activity,
  type InsertActivity,
  type FieldDefinition,
  type InsertFieldDefinition,
  type User,
  type InsertUser,
  type SystemSetting,
  type InsertSystemSetting,
  type RoleColumnPermission,
  type InsertRoleColumnPermission,
  type CustomerWithProspects,
  type TaskWithRelations,
  type ActivityWithRelations,
  customers,
  prospects,
  tasks,
  activities,
  fieldDefinitions,
  users,
  systemSettings,
  roleColumnPermissions
} from "@shared/schema";
import { randomUUID } from "crypto";
import { drizzle } from "drizzle-orm/neon-http";
import { neon } from "@neondatabase/serverless";
import { eq, desc, sql } from "drizzle-orm";

export interface IStorage {
  // Customer operations
  getCustomers(): Promise<Customer[]>;
  getCustomer(id: string): Promise<Customer | undefined>;
  getCustomerWithProspects(id: string): Promise<CustomerWithProspects | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: string, customer: Partial<InsertCustomer>): Promise<Customer>;
  deleteCustomer(id: string): Promise<boolean>;

  // Prospect operations
  getProspects(): Promise<Prospect[]>;
  getProspect(id: string): Promise<Prospect | undefined>;
  createProspect(prospect: InsertProspect): Promise<Prospect>;
  updateProspect(id: string, prospect: Partial<InsertProspect>): Promise<Prospect>;
  deleteProspect(id: string): Promise<boolean>;

  // Task operations
  getTasks(): Promise<Task[]>;
  getTask(id: string): Promise<Task | undefined>;
  getTasksWithRelations(): Promise<TaskWithRelations[]>;
  getTasksByCustomer(customerId: string): Promise<Task[]>;
  getTasksByProspect(prospectId: string): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: string, task: Partial<InsertTask>): Promise<Task>;
  deleteTask(id: string): Promise<boolean>;

  // Activity operations
  getActivities(): Promise<Activity[]>;
  getActivity(id: string): Promise<Activity | undefined>;
  getActivitiesWithRelations(): Promise<ActivityWithRelations[]>;
  getActivitiesByCustomer(customerId: string): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;

  // Field Definition operations
  getFieldDefinitions(): Promise<FieldDefinition[]>;
  getFieldDefinition(id: string): Promise<FieldDefinition | undefined>;
  createFieldDefinition(fieldDef: InsertFieldDefinition): Promise<FieldDefinition>;
  updateFieldDefinition(id: string, fieldDef: Partial<InsertFieldDefinition>): Promise<FieldDefinition>;
  deleteFieldDefinition(id: string): Promise<boolean>;

  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  changePassword(userId: string, newPasswordHash: string): Promise<boolean>;
  // Other user operations
  getUsers(): Promise<User[]>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User>;
  deleteUser(id: string): Promise<boolean>;

  // System Settings operations
  getSystemSettings(): Promise<SystemSetting[]>;
  getSystemSetting(key: string): Promise<SystemSetting | undefined>;
  getSystemSettingsByCategory(category: string): Promise<SystemSetting[]>;
  createSystemSetting(setting: InsertSystemSetting): Promise<SystemSetting>;
  updateSystemSetting(key: string, setting: Partial<InsertSystemSetting>): Promise<SystemSetting>;
  deleteSystemSetting(key: string): Promise<boolean>;

  // Role Column Permissions operations
  getRoleColumnPermissions(role: string, entityType: string): Promise<RoleColumnPermission[]>;
  createRoleColumnPermission(permission: InsertRoleColumnPermission): Promise<RoleColumnPermission>;
  updateRoleColumnPermissions(role: string, entityType: string, permissions: InsertRoleColumnPermission[]): Promise<RoleColumnPermission[]>;

  // Analytics
  getDashboardMetrics(): Promise<{
    totalCustomers: number;
    activeProspects: number;
    monthlyRevenue: number;
    pendingTasks: number;
  }>;
}

export class MemStorage implements IStorage {
  private customers: Map<string, Customer>;
  private prospects: Map<string, Prospect>;
  private tasks: Map<string, Task>;
  private activities: Map<string, Activity>;
  private fieldDefinitions: Map<string, FieldDefinition>;
  private users: Map<string, User>;
  private systemSettings: Map<string, SystemSetting>;
  private roleColumnPermissions: Map<string, RoleColumnPermission>;

  constructor() {
    this.customers = new Map();
    this.prospects = new Map();
    this.tasks = new Map();
    this.activities = new Map();
    this.fieldDefinitions = new Map();
    this.users = new Map();
    this.systemSettings = new Map();
    this.roleColumnPermissions = new Map();
    
    // Initialize default field definitions
    this.initializeDefaultFields();
    // Initialize default admin user and system settings
    this.initializeDefaultUsers();
    this.initializeDefaultSettings();
    this.initializeDefaultColumnPermissions();
  }

  private initializeDefaultFields() {
    const defaultFields: FieldDefinition[] = [
      // Pola dla klientów
      { id: '1', fieldKey: 'contractorName', fieldLabel: 'Nazwa kontrahenta', fieldType: 'text', entityType: 'customers', fieldOptions: null, isRequired: 1, isDefault: 1, displayOrder: 1, isActive: 1, createdAt: new Date() },
      { id: '2', fieldKey: 'groupName', fieldLabel: 'Nazwa grupy', fieldType: 'text', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 2, isActive: 1, createdAt: new Date() },
      { id: '3', fieldKey: 'nip', fieldLabel: 'NIP', fieldType: 'text', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 3, isActive: 1, createdAt: new Date() },
      { id: '4', fieldKey: 'city', fieldLabel: 'Miasto', fieldType: 'text', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 4, isActive: 1, createdAt: new Date() },
      { id: '5', fieldKey: 'code', fieldLabel: 'Kod pocztowy', fieldType: 'text', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 5, isActive: 1, createdAt: new Date() },
      { id: '6', fieldKey: 'streetAddress', fieldLabel: 'Ulica, nr lokalu', fieldType: 'text', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 6, isActive: 1, createdAt: new Date() },
      { id: '7', fieldKey: 'contract', fieldLabel: 'Umowa', fieldType: 'text', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 7, isActive: 1, createdAt: new Date() },
      { id: '8', fieldKey: 'classification', fieldLabel: 'Nazwa klasyfikacji', fieldType: 'text', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 8, isActive: 1, createdAt: new Date() },
      { id: '9', fieldKey: 'salesperson', fieldLabel: 'Handlowiec', fieldType: 'text', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 9, isActive: 1, createdAt: new Date() },
      { id: '10', fieldKey: 'email', fieldLabel: 'E-mail kontrahenta', fieldType: 'email', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 10, isActive: 1, createdAt: new Date() },
      { id: '11', fieldKey: 'phone', fieldLabel: 'Nr telefonu', fieldType: 'phone', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 11, isActive: 1, createdAt: new Date() },
      { id: '12', fieldKey: 'revenue2020', fieldLabel: 'Obrót Netto 2020', fieldType: 'number', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 12, isActive: 1, createdAt: new Date() },
      { id: '13', fieldKey: 'revenue2021', fieldLabel: 'Obrót Netto 2021', fieldType: 'number', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 13, isActive: 1, createdAt: new Date() },
      { id: '14', fieldKey: 'revenue2022', fieldLabel: 'Obrót Netto 2022', fieldType: 'number', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 14, isActive: 1, createdAt: new Date() },
      { id: '15', fieldKey: 'revenue2023', fieldLabel: 'Obrót Netto 2023', fieldType: 'number', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 15, isActive: 1, createdAt: new Date() },
      { id: '16', fieldKey: 'revenue2024', fieldLabel: 'Obrót Netto 2024', fieldType: 'number', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 16, isActive: 1, createdAt: new Date() },
      { id: '17', fieldKey: 'revenue2025', fieldLabel: 'Obrót Netto 2025', fieldType: 'number', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 17, isActive: 1, createdAt: new Date() },
      { id: '18', fieldKey: 'totalRevenue', fieldLabel: 'Suma kontrahenta', fieldType: 'number', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 18, isActive: 1, createdAt: new Date() },
      
      // Pola dla potencjalnych klientów (deals)
      { id: '19', fieldKey: 'contractorName', fieldLabel: 'Nazwa klienta', fieldType: 'text', entityType: 'deals', fieldOptions: null, isRequired: 1, isDefault: 1, displayOrder: 1, isActive: 1, createdAt: new Date() },
      { id: '20', fieldKey: 'streetAddress', fieldLabel: 'Ulica, nr lokalu', fieldType: 'text', entityType: 'deals', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 2, isActive: 1, createdAt: new Date() },
      { id: '21', fieldKey: 'postalCode', fieldLabel: 'Kod pocztowy', fieldType: 'text', entityType: 'deals', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 3, isActive: 1, createdAt: new Date() },
      { id: '22', fieldKey: 'city', fieldLabel: 'Miasto', fieldType: 'text', entityType: 'deals', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 4, isActive: 1, createdAt: new Date() },
      { id: '23', fieldKey: 'phone', fieldLabel: 'Nr telefonu', fieldType: 'phone', entityType: 'deals', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 5, isActive: 1, createdAt: new Date() },
      { id: '24', fieldKey: 'email', fieldLabel: 'E-mail', fieldType: 'email', entityType: 'deals', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 6, isActive: 1, createdAt: new Date() },
      { id: '25', fieldKey: 'acquisitionMethod', fieldLabel: 'Sposób pozyskania', fieldType: 'list', entityType: 'deals', fieldOptions: '["klient Cedrus","klient Rozkwit","telefon"]', isRequired: 0, isDefault: 1, displayOrder: 7, isActive: 1, createdAt: new Date() },
      { id: '26', fieldKey: 'salesperson', fieldLabel: 'Handlowiec', fieldType: 'list', entityType: 'deals', fieldOptions: '["administrator","koordynator","handlowiec"]', isRequired: 0, isDefault: 1, displayOrder: 8, isActive: 1, createdAt: new Date() },
    ];
    
    defaultFields.forEach(field => this.fieldDefinitions.set(field.id, field));
  }

  private initializeDefaultUsers() {
    const defaultAdmin: User = {
      id: 'admin-1',
      username: 'admin',
      email: 'admin@firma.pl',
      password: '$2b$10$rGz7V4gF3mKnLdOoP8hK5O5Y.GvGJK.2YhJ.7aLq8V5N6X8C9oUb.', // hasło: admin123
      firstName: 'Administrator',
      lastName: 'Systemu',
      role: 'administrator',
      isActive: 1,
      lastLogin: null,
      createdAt: new Date()
    };
    
    this.users.set(defaultAdmin.id, defaultAdmin);
  }

  private initializeDefaultSettings() {
    const defaultSettings: SystemSetting[] = [
      {
        id: 'setting-1',
        settingKey: 'company_name',
        settingValue: 'Moja Firma',
        settingType: 'text',
        category: 'general',
        description: 'Nazwa firmy wyświetlana w aplikacji',
        updatedBy: 'admin-1',
        updatedAt: new Date()
      },
      {
        id: 'setting-2',
        settingKey: 'dashboard_show_activities',
        settingValue: 'true',
        settingType: 'boolean',
        category: 'dashboard',
        description: 'Czy pokazywać sekcję ostatnich aktywności na pulpicie',
        updatedBy: 'admin-1',
        updatedAt: new Date()
      },
      {
        id: 'setting-3',
        settingKey: 'customers_per_page',
        settingValue: '10',
        settingType: 'number',
        category: 'general',
        description: 'Liczba klientów wyświetlanych na stronie',
        updatedBy: 'admin-1',
        updatedAt: new Date()
      },
      {
        id: 'setting-4',
        settingKey: 'restrict_salesperson_view',
        settingValue: 'false',
        settingType: 'boolean',
        category: 'users',
        description: 'Czy handlowcy widzą tylko swoich przypisanych klientów',
        updatedBy: 'admin-1',
        updatedAt: new Date()
      },
      {
        id: 'setting-5',
        settingKey: 'hide_financial_from_salesperson',
        settingValue: 'false',
        settingType: 'boolean',
        category: 'users',
        description: 'Czy ukrywać dane finansowe przed handlowcami',
        updatedBy: 'admin-1',
        updatedAt: new Date()
      },
      {
        id: 'setting-6',
        settingKey: 'coordinator_can_manage_fields',
        settingValue: 'true',
        settingType: 'boolean',
        category: 'users',
        description: 'Czy koordynatorzy mogą zarządzać polami',
        updatedBy: 'admin-1',
        updatedAt: new Date()
      },
      {
        id: 'setting-7',
        settingKey: 'sidebar_auto_hide',
        settingValue: 'false',
        settingType: 'boolean',
        category: 'interface',
        description: 'Czy sidebar ma się automatycznie chować',
        updatedBy: 'admin-1',
        updatedAt: new Date()
      }
    ];
    
    defaultSettings.forEach(setting => this.systemSettings.set(setting.settingKey, setting));
  }

  private initializeDefaultColumnPermissions() {
    const customerColumns = [
      { id: 'contractorName', label: 'Nazwa kontrahenta', category: 'basic' },
      { id: 'groupName', label: 'Nazwa grupy', category: 'basic' },
      { id: 'nip', label: 'NIP', category: 'basic' },
      { id: 'city', label: 'Miasto', category: 'contact' },
      { id: 'email', label: 'Email', category: 'contact' },
      { id: 'phone', label: 'Telefon', category: 'contact' },
      { id: 'salesperson', label: 'Handlowiec', category: 'management' },
      { id: 'classification', label: 'Klasyfikacja', category: 'metadata' },
      { id: 'totalRevenue', label: 'Suma obrotów', category: 'financial' },
      { id: 'revenue2024', label: 'Obrót 2024', category: 'financial' },
      { id: 'revenue2025', label: 'Obrót 2025', category: 'financial' },
    ];

    const roles = ['administrator', 'dyrektor', 'koordynator', 'handlowiec'];

    roles.forEach(role => {
      customerColumns.forEach((column, index) => {
        let isVisible = true;
        
        // Handlowcy nie widzą danych finansowych domyślnie
        if (role === 'handlowiec' && column.category === 'financial') {
          isVisible = false;
        }

        const permission: RoleColumnPermission = {
          id: randomUUID(),
          role,
          entityType: 'customers',
          columnId: column.id,
          columnLabel: column.label,
          columnCategory: column.category,
          isVisible: isVisible ? 1 : 0,
          displayOrder: index,
          createdAt: new Date(),
          updatedAt: new Date()
        };

        this.roleColumnPermissions.set(`${role}-customers-${column.id}`, permission);
      });
    });
  }

  // Customer operations
  async getCustomers(): Promise<Customer[]> {
    return Array.from(this.customers.values());
  }

  async getCustomer(id: string): Promise<Customer | undefined> {
    return this.customers.get(id);
  }

  async getCustomerWithProspects(id: string): Promise<CustomerWithProspects | undefined> {
    const customer = this.customers.get(id);
    if (!customer) return undefined;

    const customerProspects: Prospect[] = []; // Prospects are independent from customers now
    const totalValue = customerProspects.length; // Simple count for now
    const activeProspectCount = 0;

    return {
      ...customer,
      prospects: customerProspects,
      totalValue,
      activeProspectCount,
    };
  }

  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const id = randomUUID();
    const customer: Customer = {
      ...insertCustomer,
      id,
      createdAt: new Date(),
      groupName: insertCustomer.groupName ?? null,
      nip: insertCustomer.nip ?? null,
      city: insertCustomer.city ?? null,
      code: insertCustomer.code ?? null,
      streetAddress: insertCustomer.streetAddress ?? null,
      contract: insertCustomer.contract ?? null,
      classification: insertCustomer.classification ?? null,
      salesperson: insertCustomer.salesperson ?? null,
      email: insertCustomer.email ?? null,
      phone: insertCustomer.phone ?? null,
      revenue2020: insertCustomer.revenue2020 ?? null,
      revenue2021: insertCustomer.revenue2021 ?? null,
      revenue2022: insertCustomer.revenue2022 ?? null,
      revenue2023: insertCustomer.revenue2023 ?? null,
      revenue2024: insertCustomer.revenue2024 ?? null,
      revenue2025: insertCustomer.revenue2025 ?? null,
      totalRevenue: insertCustomer.totalRevenue ?? null,
      acquisitionMethod: insertCustomer.acquisitionMethod ?? null,
      website: insertCustomer.website ?? null,
      allegro: insertCustomer.allegro ?? null,
      googlePlaceId: insertCustomer.googlePlaceId ?? null,
      googleRating: insertCustomer.googleRating ?? null,
      googlePhotoReference: insertCustomer.googlePhotoReference ?? null,
      streetViewAvailable: insertCustomer.streetViewAvailable ?? null,
      businessStatus: insertCustomer.businessStatus ?? null,
      businessTypes: insertCustomer.businessTypes ?? null,
      enrichedAt: insertCustomer.enrichedAt ?? null,
      notes: insertCustomer.notes ?? null,
    };
    this.customers.set(id, customer);

    // Create activity
    await this.createActivity({
      customerId: id,
      type: "customer_added",
      description: `Nowy klient dodany: ${customer.contractorName}`,
      salesperson: 'System',
    });

    return customer;
  }

  async updateCustomer(id: string, customerUpdate: Partial<InsertCustomer>): Promise<Customer> {
    const existing = this.customers.get(id);
    if (!existing) throw new Error("Customer not found");

    const updated = { ...existing, ...customerUpdate };
    this.customers.set(id, updated);
    return updated;
  }

  async deleteCustomer(id: string): Promise<boolean> {
    const result = this.customers.delete(id);
    
    // Clean up related prospects, tasks, and activities
    if (result) {
      // Prospects are independent - no cleanup needed
      
      Array.from(this.tasks.entries()).forEach(([taskId, task]) => {
        if (task.customerId === id) {
          this.tasks.delete(taskId);
        }
      });
      
      Array.from(this.activities.entries()).forEach(([activityId, activity]) => {
        if (activity.customerId === id) {
          this.activities.delete(activityId);
        }
      });
    }
    
    return result;
  }

  // Prospect operations  
  async getProspects(): Promise<Prospect[]> {
    return Array.from(this.prospects.values());
  }

  async getProspect(id: string): Promise<Prospect | undefined> {
    return this.prospects.get(id);
  }

  async createProspect(insertProspect: InsertProspect): Promise<Prospect> {
    const id = randomUUID();
    const prospect: Prospect = {
      ...insertProspect,
      id,
      createdAt: new Date(),
      contractorName: insertProspect.contractorName || '',
      streetAddress: insertProspect.streetAddress || '',
      postalCode: insertProspect.postalCode || '',
      city: insertProspect.city || '',
      phone: insertProspect.phone || '',
      email: insertProspect.email || '',
      acquisitionMethod: insertProspect.acquisitionMethod || '',
      salesperson: insertProspect.salesperson || '',
      status: insertProspect.status || 'new',
      notes: insertProspect.notes || '',
      hasGardenEquipment: insertProspect.hasGardenEquipment ?? 0,
      hasOnlineStore: insertProspect.hasOnlineStore ?? 0,
      allegro_store: insertProspect.allegro_store ?? '',
      facebook_url: insertProspect.facebook_url ?? '',
      founded_year: insertProspect.founded_year ?? '',
      debt_status: insertProspect.debt_status ?? '',
      business_description: insertProspect.business_description ?? '',
      googlePlaceId: insertProspect.googlePlaceId ?? '',
      google_photos: insertProspect.google_photos ?? '',
      streetview_available: insertProspect.streetview_available ?? 0,
    };
    this.prospects.set(id, prospect);

    // Create activity
    await this.createActivity({
      prospectId: id,
      type: "prospect_created",
      description: `Nowy potencjalny klient utworzony: ${prospect.contractorName}`,
      salesperson: 'System',
    });

    return prospect;
  }

  async updateProspect(id: string, prospectUpdate: Partial<InsertProspect>): Promise<Prospect> {
    const existing = this.prospects.get(id);
    if (!existing) throw new Error("Prospect not found");

    const updated = { ...existing, ...prospectUpdate };
    this.prospects.set(id, updated);

    // Create activity for status changes
    if (prospectUpdate.status && prospectUpdate.status !== existing.status) {
      await this.createActivity({
        prospectId: id,
        type: "prospect_updated",
        description: `Status potencjalnego klienta zmieniony z ${existing.status} na ${prospectUpdate.status}`,
        salesperson: 'System',
      });
    }

    return updated;
  }

  async deleteProspect(id: string): Promise<boolean> {
    const result = this.prospects.delete(id);
    
    // Clean up related tasks and activities
    if (result) {
      Array.from(this.tasks.entries()).forEach(([taskId, task]) => {
        if (task.prospectId === id) {
          this.tasks.delete(taskId);
        }
      });
      
      Array.from(this.activities.entries()).forEach(([activityId, activity]) => {
        if (activity.prospectId === id) {
          this.activities.delete(activityId);
        }
      });
    }
    
    return result;
  }

  // Task operations
  async getTasks(): Promise<Task[]> {
    return Array.from(this.tasks.values());
  }

  async getTask(id: string): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async getTasksWithRelations(): Promise<TaskWithRelations[]> {
    const tasks = Array.from(this.tasks.values());
    return tasks.map(task => {
      const customer = task.customerId ? this.customers.get(task.customerId) : undefined;
      const prospect = task.prospectId ? this.prospects.get(task.prospectId) : undefined;
      return {
        ...task,
        customer,
        prospect,
      };
    });
  }

  async getTasksByCustomer(customerId: string): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(task => task.customerId === customerId);
  }

  async getTasksByProspect(prospectId: string): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(task => task.prospectId === prospectId);
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = randomUUID();
    const task: Task = {
      ...insertTask,
      id,
      createdAt: new Date(),
      customerId: insertTask.customerId ?? null,
      prospectId: insertTask.prospectId ?? null,
      description: insertTask.description ?? null,
      dueDate: insertTask.dueDate ?? null,
      completed: insertTask.completed ?? null,
      priority: insertTask.priority ?? null,
    };
    this.tasks.set(id, task);

    // Create activity
    if (task.customerId || task.prospectId) {
      await this.createActivity({
        customerId: task.customerId,
        prospectId: task.prospectId,
        taskId: id,
        type: "task_created",
        description: `New task created: ${task.title}`,
        salesperson: 'System',
      });
    }

    return task;
  }

  async updateTask(id: string, taskUpdate: Partial<InsertTask>): Promise<Task> {
    const existing = this.tasks.get(id);
    if (!existing) throw new Error("Task not found");

    const updated = { ...existing, ...taskUpdate };
    this.tasks.set(id, updated);

    // Create activity for completion
    if (taskUpdate.completed === 1 && existing.completed === 0) {
      if (updated.customerId) {
        await this.createActivity({
          customerId: updated.customerId,
          prospectId: updated.prospectId,
          taskId: id,
          type: "task_completed",
          description: `Task completed: ${updated.title}`,
          salesperson: 'System',
        });
      }
    }

    return updated;
  }

  async deleteTask(id: string): Promise<boolean> {
    const result = this.tasks.delete(id);
    
    // Clean up related activities
    if (result) {
      Array.from(this.activities.entries()).forEach(([activityId, activity]) => {
        if (activity.taskId === id) {
          this.activities.delete(activityId);
        }
      });
    }
    
    return result;
  }

  // Activity operations
  async getActivities(): Promise<Activity[]> {
    return Array.from(this.activities.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getActivity(id: string): Promise<Activity | undefined> {
    return this.activities.get(id);
  }

  async getActivitiesWithRelations(): Promise<ActivityWithRelations[]> {
    const activities = await this.getActivities();
    return activities.map(activity => {
      const customer = activity.customerId ? this.customers.get(activity.customerId) : undefined;
      const prospect = activity.prospectId ? this.prospects.get(activity.prospectId) : undefined;
      const task = activity.taskId ? this.tasks.get(activity.taskId) : undefined;
      return {
        ...activity,
        customer,
        prospect,
        task,
      };
    });
  }

  async getActivitiesByCustomer(customerId: string): Promise<Activity[]> {
    return Array.from(this.activities.values())
      .filter(activity => activity.customerId === customerId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = randomUUID();
    const activity: Activity = {
      ...insertActivity,
      id,
      salesperson: insertActivity.salesperson || 'System',
      activityDate: new Date(),
      createdAt: new Date(),
      customerId: insertActivity.customerId ?? null,
      prospectId: insertActivity.prospectId ?? null,
      taskId: insertActivity.taskId ?? null,
      orderValue: insertActivity.orderValue ?? null,
    };
    this.activities.set(id, activity);
    
    // Automatycznie zmień status prospect na 'contacted' gdy dodamy pierwszą aktywność
    if (activity.prospectId && ['phone', 'email', 'meeting'].includes(activity.type)) {
      const prospect = this.prospects.get(activity.prospectId);
      if (prospect && prospect.status === 'new') {
        prospect.status = 'contacted';
        this.prospects.set(activity.prospectId, prospect);
      }
    }
    
    // Automatycznie zamknij prospect jako wygrany przy zamówieniu
    if (activity.type === 'order' && activity.prospectId) {
      const prospect = this.prospects.get(activity.prospectId);
      if (prospect) {
        prospect.status = 'won';
        this.prospects.set(activity.prospectId, prospect);
      }
    }
    
    return activity;
  }

  // Funkcja do przenoszenia wygranego deal do klientów

  // Field Definition operations
  async getFieldDefinitions(entityType?: string): Promise<FieldDefinition[]> {
    // Automatycznie dodaj pole dla bieżącego roku jeśli nie istnieje
    await this.ensureCurrentYearField();
    
    return Array.from(this.fieldDefinitions.values())
      .filter(field => field.isActive === 1 && (entityType ? field.entityType === entityType : true))
      .sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
  }

  private async ensureCurrentYearField(): Promise<void> {
    const currentYear = new Date().getFullYear();
    const fieldKey = `revenue${currentYear}`;
    
    // Sprawdź czy pole dla bieżącego roku już istnieje
    const existingField = Array.from(this.fieldDefinitions.values())
      .find(field => field.fieldKey === fieldKey);
    
    if (!existingField && currentYear >= 2026) {
      // Znajdź najwyższą kolejność wyświetlania wśród pól revenue
      const maxOrder = Array.from(this.fieldDefinitions.values())
        .filter(field => field.fieldKey.startsWith('revenue'))
        .reduce((max, field) => Math.max(max, field.displayOrder || 0), 0);
      
      // Dodaj nowe pole dla bieżącego roku
      const newField: FieldDefinition = {
        id: randomUUID(),
        fieldKey,
        fieldLabel: `Obrót Netto ${currentYear}`,
        fieldType: 'number',
        entityType: 'customers',
        fieldOptions: null,
        isRequired: 0,
        isDefault: 1,
        displayOrder: maxOrder + 1,
        isActive: 1,
        createdAt: new Date(),
      };
      
      this.fieldDefinitions.set(newField.id, newField);
    }
  }

  async getFieldDefinition(id: string): Promise<FieldDefinition | undefined> {
    return this.fieldDefinitions.get(id);
  }

  async createFieldDefinition(insertFieldDef: InsertFieldDefinition): Promise<FieldDefinition> {
    const id = randomUUID();
    const fieldDef: FieldDefinition = {
      ...insertFieldDef,
      id,
      fieldType: insertFieldDef.fieldType ?? 'text',
      entityType: insertFieldDef.entityType ?? 'customers',
      fieldOptions: insertFieldDef.fieldOptions ?? null,
      isRequired: insertFieldDef.isRequired ?? 0,
      isDefault: insertFieldDef.isDefault ?? 0,
      displayOrder: insertFieldDef.displayOrder ?? 0,
      isActive: insertFieldDef.isActive ?? 1,
      createdAt: new Date(),
    };
    this.fieldDefinitions.set(id, fieldDef);
    return fieldDef;
  }

  async updateFieldDefinition(id: string, fieldDefUpdate: Partial<InsertFieldDefinition>): Promise<FieldDefinition> {
    const existing = this.fieldDefinitions.get(id);
    if (!existing) throw new Error("Field definition not found");

    const updated = { ...existing, ...fieldDefUpdate };
    this.fieldDefinitions.set(id, updated);
    return updated;
  }

  async deleteFieldDefinition(id: string): Promise<boolean> {
    const field = this.fieldDefinitions.get(id);
    if (!field) return false;
    
    // Nie można usuwać domyślnych pól
    if (field.isDefault === 1) {
      throw new Error("Cannot delete default field");
    }
    
    return this.fieldDefinitions.delete(id);
  }

  // Analytics
  async getDashboardMetrics(): Promise<{
    totalCustomers: number;
    activeProspects: number;
    monthlyRevenue: number;
    pendingTasks: number;
  }> {
    const totalCustomers = this.customers.size;
    
    const prospects = Array.from(this.prospects.values());
    const activeProspects = prospects.filter(prospect => 
      !['won', 'lost'].includes(prospect.status)
    ).length;
    
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    const activities = Array.from(this.activities.values());
    const monthlyRevenue = activities
      .filter(activity => 
        activity.type === 'order' &&
        activity.createdAt &&
        new Date(activity.createdAt).getMonth() === currentMonth &&
        new Date(activity.createdAt).getFullYear() === currentYear
      )
      .reduce((sum, activity) => sum + Number(activity.orderValue || 0), 0);
    
    const tasks = Array.from(this.tasks.values());
    const pendingTasks = tasks.filter(task => task.completed === 0).length;

    return {
      totalCustomers,
      activeProspects,
      monthlyRevenue,
      pendingTasks,
    };
  }

  // User operations
  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      role: insertUser.role ?? 'handlowiec',
      isActive: insertUser.isActive ?? 1,
      lastLogin: null,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, userUpdate: Partial<InsertUser>): Promise<User> {
    const existing = this.users.get(id);
    if (!existing) throw new Error("User not found");

    const updated = { ...existing, ...userUpdate };
    this.users.set(id, updated);
    return updated;
  }

  async deleteUser(id: string): Promise<boolean> {
    return this.users.delete(id);
  }

  async changePassword(userId: string, newPasswordHash: string): Promise<boolean> {
    const user = this.users.get(userId);
    if (!user) return false;
    
    const updatedUser = { ...user, password: newPasswordHash };
    this.users.set(userId, updatedUser);
    return true;
  }

  // System Settings operations
  async getSystemSettings(): Promise<SystemSetting[]> {
    return Array.from(this.systemSettings.values());
  }

  async getSystemSetting(key: string): Promise<SystemSetting | undefined> {
    return this.systemSettings.get(key);
  }

  async getSystemSettingsByCategory(category: string): Promise<SystemSetting[]> {
    return Array.from(this.systemSettings.values()).filter(setting => setting.category === category);
  }

  async createSystemSetting(insertSetting: InsertSystemSetting): Promise<SystemSetting> {
    const id = randomUUID();
    const setting: SystemSetting = {
      ...insertSetting,
      id,
      settingType: insertSetting.settingType ?? 'text',
      category: insertSetting.category ?? 'general',
      description: insertSetting.description ?? null,
      settingValue: insertSetting.settingValue ?? null,
      updatedBy: insertSetting.updatedBy ?? null,
      updatedAt: new Date(),
    };
    this.systemSettings.set(insertSetting.settingKey, setting);
    return setting;
  }

  async updateSystemSetting(key: string, settingUpdate: Partial<InsertSystemSetting>): Promise<SystemSetting> {
    const existing = this.systemSettings.get(key);
    if (!existing) throw new Error("System setting not found");

    const updated = { ...existing, ...settingUpdate, updatedAt: new Date() };
    this.systemSettings.set(key, updated);
    return updated;
  }

  async deleteSystemSetting(key: string): Promise<boolean> {
    return this.systemSettings.delete(key);
  }

  // Role Column Permissions operations
  async getRoleColumnPermissions(role: string, entityType: string): Promise<RoleColumnPermission[]> {
    return Array.from(this.roleColumnPermissions.values())
      .filter(permission => permission.role === role && permission.entityType === entityType)
      .sort((a, b) => a.displayOrder - b.displayOrder);
  }

  async createRoleColumnPermission(insertPermission: InsertRoleColumnPermission): Promise<RoleColumnPermission> {
    const id = randomUUID();
    const permission: RoleColumnPermission = {
      ...insertPermission,
      id,
      isVisible: insertPermission.isVisible ?? 1,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    const key = `${permission.role}-${permission.entityType}-${permission.columnId}`;
    this.roleColumnPermissions.set(key, permission);
    return permission;
  }

  async updateRoleColumnPermissions(role: string, entityType: string, permissions: InsertRoleColumnPermission[]): Promise<RoleColumnPermission[]> {
    // Usuń istniejące uprawnienia dla tej roli i typu
    const keysToDelete = Array.from(this.roleColumnPermissions.keys())
      .filter(key => key.startsWith(`${role}-${entityType}-`));
    
    keysToDelete.forEach(key => this.roleColumnPermissions.delete(key));

    // Dodaj nowe uprawnienia
    const updatedPermissions: RoleColumnPermission[] = [];
    
    permissions.forEach(permission => {
      const id = randomUUID();
      const newPermission: RoleColumnPermission = {
        ...permission,
        id,
        isVisible: permission.isVisible ?? 1,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      const key = `${permission.role}-${permission.entityType}-${permission.columnId}`;
      this.roleColumnPermissions.set(key, newPermission);
      updatedPermissions.push(newPermission);
    });

    return updatedPermissions;
  }
}

// PostgreSQL Storage Implementation
export class PostgreSQLStorage implements IStorage {
  private db: ReturnType<typeof drizzle>;

  constructor() {
    if (!process.env.DATABASE_URL) {
      throw new Error("DATABASE_URL environment variable is required");
    }
    const sql = neon(process.env.DATABASE_URL);
    this.db = drizzle(sql);
    
    // Initialize default data
    this.initializeDefaults();
  }

  private async initializeDefaults() {
    try {
      // Check if we have any field definitions
      const existingFields = await this.db.select().from(fieldDefinitions).limit(1);
      if (existingFields.length === 0) {
        await this.seedDefaultData();
      }
    } catch (error) {
      console.error("Error initializing defaults:", error);
    }
  }

  private async seedDefaultData() {
    // Seed default field definitions
    const defaultFields: InsertFieldDefinition[] = [
      // Pola dla klientów
      { fieldKey: 'contractorName', fieldLabel: 'Nazwa kontrahenta', fieldType: 'text', entityType: 'customers', fieldOptions: null, isRequired: 1, isDefault: 1, displayOrder: 1, isActive: 1 },
      { fieldKey: 'groupName', fieldLabel: 'Nazwa grupy', fieldType: 'text', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 2, isActive: 1 },
      { fieldKey: 'nip', fieldLabel: 'NIP', fieldType: 'text', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 3, isActive: 1 },
      { fieldKey: 'city', fieldLabel: 'Miasto', fieldType: 'text', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 4, isActive: 1 },
      { fieldKey: 'code', fieldLabel: 'Kod pocztowy', fieldType: 'text', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 5, isActive: 1 },
      { fieldKey: 'streetAddress', fieldLabel: 'Ulica, nr lokalu', fieldType: 'text', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 6, isActive: 1 },
      { fieldKey: 'contract', fieldLabel: 'Umowa', fieldType: 'text', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 7, isActive: 1 },
      { fieldKey: 'classification', fieldLabel: 'Nazwa klasyfikacji', fieldType: 'text', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 8, isActive: 1 },
      { fieldKey: 'salesperson', fieldLabel: 'Handlowiec', fieldType: 'text', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 9, isActive: 1 },
      { fieldKey: 'email', fieldLabel: 'E-mail kontrahenta', fieldType: 'email', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 10, isActive: 1 },
      { fieldKey: 'phone', fieldLabel: 'Nr telefonu', fieldType: 'phone', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 11, isActive: 1 },
      { fieldKey: 'revenue2020', fieldLabel: 'Obrót Netto 2020', fieldType: 'number', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 12, isActive: 1 },
      { fieldKey: 'revenue2021', fieldLabel: 'Obrót Netto 2021', fieldType: 'number', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 13, isActive: 1 },
      { fieldKey: 'revenue2022', fieldLabel: 'Obrót Netto 2022', fieldType: 'number', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 14, isActive: 1 },
      { fieldKey: 'revenue2023', fieldLabel: 'Obrót Netto 2023', fieldType: 'number', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 15, isActive: 1 },
      { fieldKey: 'revenue2024', fieldLabel: 'Obrót Netto 2024', fieldType: 'number', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 16, isActive: 1 },
      { fieldKey: 'revenue2025', fieldLabel: 'Obrót Netto 2025', fieldType: 'number', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 17, isActive: 1 },
      { fieldKey: 'totalRevenue', fieldLabel: 'Suma kontrahenta', fieldType: 'number', entityType: 'customers', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 18, isActive: 1 },
      
      // Pola dla potencjalnych klientów (deals)
      { fieldKey: 'contractorName', fieldLabel: 'Nazwa klienta', fieldType: 'text', entityType: 'deals', fieldOptions: null, isRequired: 1, isDefault: 1, displayOrder: 1, isActive: 1 },
      { fieldKey: 'streetAddress', fieldLabel: 'Ulica, nr lokalu', fieldType: 'text', entityType: 'deals', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 2, isActive: 1 },
      { fieldKey: 'postalCode', fieldLabel: 'Kod pocztowy', fieldType: 'text', entityType: 'deals', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 3, isActive: 1 },
      { fieldKey: 'city', fieldLabel: 'Miasto', fieldType: 'text', entityType: 'deals', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 4, isActive: 1 },
      { fieldKey: 'phone', fieldLabel: 'Nr telefonu', fieldType: 'phone', entityType: 'deals', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 5, isActive: 1 },
      { fieldKey: 'email', fieldLabel: 'E-mail', fieldType: 'email', entityType: 'deals', fieldOptions: null, isRequired: 0, isDefault: 1, displayOrder: 6, isActive: 1 },
      { fieldKey: 'acquisitionMethod', fieldLabel: 'Sposób pozyskania', fieldType: 'list', entityType: 'deals', fieldOptions: '["klient Cedrus","klient Rozkwit","telefon"]', isRequired: 0, isDefault: 1, displayOrder: 7, isActive: 1 },
      { fieldKey: 'salesperson', fieldLabel: 'Handlowiec', fieldType: 'list', entityType: 'deals', fieldOptions: '["administrator","koordynator","handlowiec"]', isRequired: 0, isDefault: 1, displayOrder: 8, isActive: 1 },
    ];

    await this.db.insert(fieldDefinitions).values(defaultFields);

    // Seed default admin user
    await this.db.insert(users).values({
      username: 'admin',
      email: 'admin@firma.pl',
      password: 'hashed_admin_password',
      firstName: 'Administrator',
      lastName: 'Systemu',
      role: 'administrator',
      isActive: 1,
      lastLogin: null,
    });

    // Seed default system settings
    const defaultSettings: InsertSystemSetting[] = [
      {
        settingKey: 'company_name',
        settingValue: 'Moja Firma',
        settingType: 'text',
        category: 'general',
        description: 'Nazwa firmy wyświetlana w aplikacji',
        updatedBy: null,
      },
      {
        settingKey: 'dashboard_show_activities',
        settingValue: 'true',
        settingType: 'boolean',
        category: 'dashboard',
        description: 'Czy pokazywać sekcję ostatnich aktywności na pulpicie',
        updatedBy: null,
      },
      {
        settingKey: 'customers_per_page',
        settingValue: '10',
        settingType: 'number',
        category: 'general',
        description: 'Liczba klientów wyświetlanych na stronie',
        updatedBy: null,
      },
    ];

    await this.db.insert(systemSettings).values(defaultSettings);
  }

  // Customer operations
  async getCustomers(): Promise<Customer[]> {
    return await this.db.select().from(customers).orderBy(desc(customers.createdAt));
  }

  async getCustomer(id: string): Promise<Customer | undefined> {
    const result = await this.db.select().from(customers).where(eq(customers.id, id)).limit(1);
    return result[0];
  }

  async getCustomerWithProspects(id: string): Promise<CustomerWithProspects | undefined> {
    const customer = await this.getCustomer(id);
    if (!customer) return undefined;

    const customerProspects: Prospect[] = []; // Prospects are independent now
    const totalValue = 0;
    const activeProspectCount = 0;

    return {
      ...customer,
      prospects: customerProspects,
      totalValue,
      activeProspectCount,
    };
  }

  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const result = await this.db.insert(customers).values(insertCustomer).returning();
    const customer = result[0];

    // Create activity
    await this.createActivity({
      customerId: customer.id,
      type: "customer_added",
      description: `Nowy klient dodany: ${customer.contractorName}`,
      salesperson: 'System',
    });

    return customer;
  }

  async updateCustomer(id: string, customerUpdate: Partial<InsertCustomer>): Promise<Customer> {
    const result = await this.db.update(customers).set(customerUpdate).where(eq(customers.id, id)).returning();
    if (result.length === 0) throw new Error("Customer not found");
    return result[0];
  }

  async deleteCustomer(id: string): Promise<boolean> {
    const result = await this.db.delete(customers).where(eq(customers.id, id));
    return result.rowCount > 0;
  }

  // Deal operations
  async getProspects(): Promise<Prospect[]> {
    return await this.db.select().from(prospects).orderBy(desc(prospects.createdAt));
  }

  async getProspect(id: string): Promise<Prospect | undefined> {
    const result = await this.db.select().from(prospects).where(eq(prospects.id, id)).limit(1);
    return result[0];
  }



  async createProspect(insertProspect: InsertProspect): Promise<Prospect> {
    const result = await this.db.insert(prospects).values(insertProspect).returning();
    return result[0];
  }

  async updateProspect(id: string, prospectUpdate: Partial<InsertProspect>): Promise<Prospect> {
    console.log('updateProspect data:', prospectUpdate);
    if (!prospectUpdate || Object.keys(prospectUpdate).length === 0) {
      throw new Error("No update data provided");
    }
    const result = await this.db.update(prospects).set(prospectUpdate).where(eq(prospects.id, id)).returning();
    if (result.length === 0) throw new Error("Prospect not found");
    return result[0];
  }

  async deleteProspect(id: string): Promise<boolean> {
    const result = await this.db.delete(prospects).where(eq(prospects.id, id));
    return result.rowCount > 0;
  }

  // Task operations (simplified implementation)
  async getTasks(): Promise<Task[]> {
    return await this.db.select().from(tasks).orderBy(desc(tasks.createdAt));
  }

  async getTask(id: string): Promise<Task | undefined> {
    const result = await this.db.select().from(tasks).where(eq(tasks.id, id)).limit(1);
    return result[0];
  }

  async getTasksWithRelations(): Promise<TaskWithRelations[]> {
    const result = await this.db
      .select({
        task: tasks,
        customer: customers,
        prospect: prospects,
      })
      .from(tasks)
      .leftJoin(customers, eq(tasks.customerId, customers.id))
      .leftJoin(prospects, eq(tasks.prospectId, prospects.id))
      .orderBy(desc(tasks.createdAt));

    return result.map(row => ({
      ...row.task,
      customer: row.customer || undefined,
      prospect: row.prospect || undefined,
    }));
  }

  async getTasksByCustomer(customerId: string): Promise<Task[]> {
    return await this.db.select().from(tasks).where(eq(tasks.customerId, customerId));
  }

  async getTasksByProspect(prospectId: string): Promise<Task[]> {
    return await this.db.select().from(tasks).where(eq(tasks.prospectId, prospectId));
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const result = await this.db.insert(tasks).values(insertTask).returning();
    return result[0];
  }

  async updateTask(id: string, taskUpdate: Partial<InsertTask>): Promise<Task> {
    const result = await this.db.update(tasks).set(taskUpdate).where(eq(tasks.id, id)).returning();
    if (result.length === 0) throw new Error("Task not found");
    return result[0];
  }

  async deleteTask(id: string): Promise<boolean> {
    const result = await this.db.delete(tasks).where(eq(tasks.id, id));
    return result.rowCount > 0;
  }

  // Activity operations
  async getActivities(): Promise<Activity[]> {
    return await this.db.select().from(activities).orderBy(desc(activities.createdAt));
  }

  async getActivity(id: string): Promise<Activity | undefined> {
    const result = await this.db.select().from(activities).where(eq(activities.id, id)).limit(1);
    return result[0];
  }

  async getActivitiesWithRelations(): Promise<ActivityWithRelations[]> {
    const result = await this.db
      .select({
        activity: activities,
        customer: customers,
        prospect: prospects,
        task: tasks,
      })
      .from(activities)
      .leftJoin(customers, eq(activities.customerId, customers.id))
      .leftJoin(prospects, eq(activities.prospectId, prospects.id))
      .leftJoin(tasks, eq(activities.taskId, tasks.id))
      .orderBy(desc(activities.createdAt));

    return result.map(row => ({
      ...row.activity,
      customer: row.customer || undefined,
      prospect: row.prospect || undefined,
      task: row.task || undefined,
    }));
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const result = await this.db.insert(activities).values(insertActivity).returning();
    return result[0];
  }

  async updateActivity(id: string, activityUpdate: Partial<InsertActivity>): Promise<Activity> {
    const result = await this.db.update(activities).set(activityUpdate).where(eq(activities.id, id)).returning();
    if (result.length === 0) throw new Error("Activity not found");
    return result[0];
  }

  async deleteActivity(id: string): Promise<boolean> {
    const result = await this.db.delete(activities).where(eq(activities.id, id));
    return result.rowCount > 0;
  }

  // Field definition operations
  async getFieldDefinitions(): Promise<FieldDefinition[]> {
    return await this.db.select().from(fieldDefinitions).orderBy(fieldDefinitions.displayOrder);
  }

  async getFieldDefinition(id: string): Promise<FieldDefinition | undefined> {
    const result = await this.db.select().from(fieldDefinitions).where(eq(fieldDefinitions.id, id)).limit(1);
    return result[0];
  }

  async createFieldDefinition(insertFieldDef: InsertFieldDefinition): Promise<FieldDefinition> {
    const result = await this.db.insert(fieldDefinitions).values(insertFieldDef).returning();
    return result[0];
  }

  async updateFieldDefinition(id: string, fieldDefUpdate: Partial<InsertFieldDefinition>): Promise<FieldDefinition> {
    const result = await this.db.update(fieldDefinitions).set(fieldDefUpdate).where(eq(fieldDefinitions.id, id)).returning();
    if (result.length === 0) throw new Error("Field definition not found");
    return result[0];
  }

  async deleteFieldDefinition(id: string): Promise<boolean> {
    const field = await this.getFieldDefinition(id);
    if (!field) return false;
    
    if (field.isDefault === 1) {
      throw new Error("Cannot delete default field");
    }
    
    const result = await this.db.delete(fieldDefinitions).where(eq(fieldDefinitions.id, id));
    return result.rowCount > 0;
  }

  // User operations (simplified)
  async getUsers(): Promise<User[]> {
    return await this.db.select().from(users).orderBy(users.username);
  }

  async getUser(id: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async getActivitiesByCustomer(customerId: string): Promise<Activity[]> {
    return await this.db.select().from(activities)
      .where(eq(activities.customerId, customerId))
      .orderBy(desc(activities.createdAt));
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await this.db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async updateUser(id: string, userUpdate: Partial<InsertUser>): Promise<User> {
    const result = await this.db.update(users).set(userUpdate).where(eq(users.id, id)).returning();
    if (result.length === 0) throw new Error("User not found");
    return result[0];
  }

  async deleteUser(id: string): Promise<boolean> {
    const result = await this.db.delete(users).where(eq(users.id, id));
    return result.rowCount > 0;
  }

  async changePassword(userId: string, newPasswordHash: string): Promise<boolean> {
    const result = await this.db.update(users)
      .set({ password: newPasswordHash })
      .where(eq(users.id, userId));
    return result.rowCount > 0;
  }

  // System settings operations (simplified)
  async getSystemSettings(): Promise<SystemSetting[]> {
    return await this.db.select().from(systemSettings).orderBy(systemSettings.category);
  }

  async getSystemSetting(key: string): Promise<SystemSetting | undefined> {
    const result = await this.db.select().from(systemSettings).where(eq(systemSettings.settingKey, key)).limit(1);
    return result[0];
  }

  async getSystemSettingsByCategory(category: string): Promise<SystemSetting[]> {
    return await this.db.select().from(systemSettings).where(eq(systemSettings.category, category));
  }

  async createSystemSetting(insertSetting: InsertSystemSetting): Promise<SystemSetting> {
    const result = await this.db.insert(systemSettings).values(insertSetting).returning();
    return result[0];
  }

  async updateSystemSetting(key: string, settingUpdate: Partial<InsertSystemSetting>): Promise<SystemSetting> {
    const result = await this.db.update(systemSettings).set(settingUpdate).where(eq(systemSettings.settingKey, key)).returning();
    if (result.length === 0) throw new Error("System setting not found");
    return result[0];
  }

  async deleteSystemSetting(key: string): Promise<boolean> {
    const result = await this.db.delete(systemSettings).where(eq(systemSettings.settingKey, key));
    return result.rowCount > 0;
  }

  // Role column permissions (simplified)
  async getRoleColumnPermissions(role: string, entityType: string): Promise<RoleColumnPermission[]> {
    return await this.db.select().from(roleColumnPermissions)
      .where(sql`${roleColumnPermissions.role} = ${role} AND ${roleColumnPermissions.entityType} = ${entityType}`)
      .orderBy(roleColumnPermissions.displayOrder);
  }

  async createRoleColumnPermission(insertPermission: InsertRoleColumnPermission): Promise<RoleColumnPermission> {
    const result = await this.db.insert(roleColumnPermissions).values(insertPermission).returning();
    return result[0];
  }

  async updateRoleColumnPermissions(role: string, entityType: string, permissions: InsertRoleColumnPermission[]): Promise<RoleColumnPermission[]> {
    // Delete existing permissions
    await this.db.delete(roleColumnPermissions)
      .where(sql`${roleColumnPermissions.role} = ${role} AND ${roleColumnPermissions.entityType} = ${entityType}`);

    // Insert new permissions
    if (permissions.length > 0) {
      const result = await this.db.insert(roleColumnPermissions).values(permissions).returning();
      return result;
    }
    return [];
  }

  // Analytics
  async getDashboardMetrics(): Promise<{
    totalCustomers: number;
    activeProspects: number;
    monthlyRevenue: number;
    pendingTasks: number;
  }> {
    const [customerCount] = await this.db.select({ count: sql<number>`count(*)` }).from(customers);
    const [prospectCount] = await this.db.select({ count: sql<number>`count(*)` }).from(prospects)
      .where(sql`${prospects.status} NOT IN ('won', 'lost')`);
    const [taskCount] = await this.db.select({ count: sql<number>`count(*)` }).from(tasks)
      .where(eq(tasks.completed, 0));

    return {
      totalCustomers: customerCount.count,
      activeProspects: prospectCount.count,
      monthlyRevenue: 0, // Simplified
      pendingTasks: taskCount.count,
    };
  }
}

// Switch to PostgreSQL Storage
export const storage = new PostgreSQLStorage();
