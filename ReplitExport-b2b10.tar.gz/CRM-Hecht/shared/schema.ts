import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, decimal, integer, unique, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { randomUUID } from "crypto";

export const customers = pgTable("customers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  groupName: text("group_name").default(''), // Nazwa grupy
  contractorName: text("contractor_name").notNull(), // Nazwa kontrahenta
  nip: text("nip").default(''), // NIP
  city: text("city").default(''), // Miasto
  code: text("code").default(''), // Kod
  streetAddress: text("street_address").default(''), // Ulica, nr lokalu
  contract: text("contract").default(''), // Umowa
  classification: text("classification").default(''), // Nazwa klasyfikacji
  salesperson: text("salesperson").default(''), // Handlowiec
  email: text("email").default(''), // E-mail kontrahenta
  phone: text("phone").default(''), // Nr telefonu
  revenue2020: text("revenue_2020").default('0'), // Obrót Netto 2020
  revenue2021: text("revenue_2021").default('0'), // Obrót Netto 2021
  revenue2022: text("revenue_2022").default('0'), // Obrót Netto 2022
  revenue2023: text("revenue_2023").default('0'), // Obrót Netto 2023
  revenue2024: text("revenue_2024").default('0'), // Obrót Netto 2024
  revenue2025: text("revenue_2025").default('0'), // Obrót Netto 2025
  totalRevenue: text("total_revenue").default('0'), // Suma kontrahenta
  acquisitionMethod: text("acquisition_method").default(''), // Sposób pozyskania
  // Google Maps i wzbogacenie danych
  website: text("website").default(''), // Strona internetowa
  allegro: text("allegro").default(''), // Link do sklepu Allegro
  googlePlaceId: text("google_place_id").default(''), // Google Place ID
  googleRating: text("google_rating").default(''), // Ocena w Google
  googlePhotoReference: text("google_photo_reference").default(''), // Referencja do zdjęcia
  streetViewAvailable: integer("street_view_available").default(0), // 0 = false, 1 = true
  businessStatus: text("business_status").default(''), // OPERATIONAL, CLOSED_TEMPORARILY, etc.
  businessTypes: text("business_types").default(''), // Typy działalności (JSON array)
  notes: text("notes").default(''), // Notatki i dane AI
  enrichedAt: timestamp("enriched_at"), // Kiedy ostatnio wzbogacono dane
  createdAt: timestamp("created_at").defaultNow(),
});

export const prospects = pgTable("prospects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  contractorName: text("contractor_name").notNull(), // Nazwa klienta
  streetAddress: text("street_address").default(''), // Ulica, nr lokalu
  postalCode: text("postal_code").default(''), // Kod pocztowy
  city: text("city").default(''), // Miasto
  phone: text("phone").default(''), // Nr telefonu
  email: text("email").default(''), // E-mail
  acquisitionMethod: text("acquisition_method").default(''), // Sposób pozyskania (lista)
  salesperson: text("salesperson").default(''), // Handlowiec (lista)
  status: text("status").notNull().default("new"), // new, contacted, qualified, negotiation, won, lost
  notes: text("notes").default(''), // Notatki
  // Wzbogacone dane AI
  hasGardenEquipment: integer("has_garden_equipment").default(0), // 0=nieznane, 1=tak, 2=nie
  hasOnlineStore: integer("has_online_store").default(0), // 0=nieznane, 1=tak, 2=nie
  allegro_store: text("allegro_store").default(''), // Link do sklepu Allegro
  facebook_url: text("facebook_url").default(''), // Link do Facebooka
  founded_year: text("founded_year").default(''), // Rok założenia
  debt_status: text("debt_status").default(''), // Status zadłużenia
  business_description: text("business_description").default(''), // Opis działalności z AI
  googlePlaceId: text("google_place_id").default(''), // Google Place ID do pobierania zdjęć
  google_photos: text("google_photos").default(''), // JSON z linkami do zdjęć
  streetview_available: integer("streetview_available").default(0), // 0=nieznane, 1=tak, 2=nie
  createdAt: timestamp("created_at").defaultNow(),
});

export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  customerId: varchar("customer_id").references(() => customers.id),
  prospectId: varchar("prospect_id").references(() => prospects.id),
  title: text("title").notNull(),
  description: text("description"),
  dueDate: timestamp("due_date"),
  completed: integer("completed").default(0), // 0 = false, 1 = true
  priority: text("priority").default("medium"), // low, medium, high
  createdAt: timestamp("created_at").defaultNow(),
});

export const activities = pgTable("activities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  customerId: varchar("customer_id").references(() => customers.id),
  prospectId: varchar("prospect_id").references(() => prospects.id),
  taskId: varchar("task_id").references(() => tasks.id),
  type: text("type").notNull(), // phone, email, meeting, order, note, prospect_created, customer_added, etc.
  description: text("description").notNull(),
  orderValue: decimal("order_value", { precision: 10, scale: 2 }), // Wartość zamówienia (tylko dla typu 'order')
  salesperson: text("salesperson").notNull(), // Handlowiec (automatycznie z sesji)
  activityDate: timestamp("activity_date").defaultNow(), // Data aktywności (automatycznie)
  createdAt: timestamp("created_at").defaultNow(),
});

// Session storage table for authentication
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for traditional login/password authentication
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(), // Will be hashed
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  role: text("role").notNull().default("handlowiec"), // administrator, handlowiec, dyrektor, koordynator
  isActive: integer("is_active").default(1), // 0 = false, 1 = true
  lastLogin: timestamp("last_login"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const fieldDefinitions = pgTable("field_definitions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fieldKey: text("field_key").notNull(), // Unikalny klucz pola (np. "contractorName", "nip")
  fieldLabel: text("field_label").notNull(), // Nazwa wyświetlana (np. "Nazwa kontrahenta", "NIP")
  fieldType: text("field_type").notNull().default("text"), // text, number, email, phone, date, list
  entityType: text("entity_type").notNull().default("customers"), // customers, prospects
  fieldOptions: text("field_options"), // JSON string z opcjami dla pól typu lista
  isRequired: integer("is_required").default(0), // 0 = false, 1 = true
  isDefault: integer("is_default").default(0), // 0 = false, 1 = true (nie można usunąć)
  displayOrder: integer("display_order").default(0), // Kolejność wyświetlania
  isActive: integer("is_active").default(1), // 0 = false, 1 = true
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  uniqueFieldKeyEntity: unique().on(table.fieldKey, table.entityType),
}));

export const systemSettings = pgTable("system_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  settingKey: text("setting_key").notNull().unique(), // np. "dashboard_layout", "company_name"
  settingValue: text("setting_value"), // Wartość ustawienia
  settingType: text("setting_type").notNull().default("text"), // text, boolean, number, json
  category: text("category").notNull().default("general"), // general, dashboard, fields, users
  description: text("description"), // Opis ustawienia
  updatedBy: varchar("updated_by").references(() => users.id),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCustomerSchema = createInsertSchema(customers).omit({
  id: true,
  createdAt: true,
}).passthrough(); // Pozwala na dodatkowe dynamiczne pola

export const insertProspectSchema = createInsertSchema(prospects).omit({
  id: true,
  createdAt: true,
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  createdAt: true,
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  createdAt: true,
  activityDate: true, // activityDate będzie ustawiona automatycznie przez serwer
});

export const insertFieldDefinitionSchema = createInsertSchema(fieldDefinitions).omit({
  id: true,
  createdAt: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  lastLogin: true,
});

export const insertSystemSettingSchema = createInsertSchema(systemSettings).omit({
  id: true,
  updatedAt: true,
});

export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type Customer = typeof customers.$inferSelect;

export type InsertProspect = z.infer<typeof insertProspectSchema>;
export type Prospect = typeof prospects.$inferSelect;

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;

export type InsertFieldDefinition = z.infer<typeof insertFieldDefinitionSchema>;
export type FieldDefinition = typeof fieldDefinitions.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Schema for password change
export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, "Aktualne hasło jest wymagane"),
  newPassword: z.string().min(6, "Nowe hasło musi mieć co najmniej 6 znaków"),
  confirmPassword: z.string().min(1, "Potwierdzenie hasła jest wymagane"),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Hasła nie są identyczne",
  path: ["confirmPassword"],
});

export type ChangePasswordInput = z.infer<typeof changePasswordSchema>;

export type InsertSystemSetting = z.infer<typeof insertSystemSettingSchema>;
export type SystemSetting = typeof systemSettings.$inferSelect;

// Extended types for API responses
export type CustomerWithProspects = Customer & {
  prospects: Prospect[];
  totalValue: number;
  activeProspectCount: number;
};

export type TaskWithRelations = Task & {
  customer?: Customer;
  prospect?: Prospect;
};

export type ActivityWithRelations = Activity & {
  customer?: Customer;
  prospect?: Prospect;
  task?: Task;
};

// Schemat dla konfiguracji kolumn ról
export const roleColumnPermissions = pgTable("role_column_permissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  role: text("role").notNull(), // administrator, handlowiec, dyrektor, koordynator
  entityType: text("entity_type").notNull(), // customers, deals, tasks, activities
  columnId: text("column_id").notNull(),
  columnLabel: text("column_label").notNull(),
  columnCategory: text("column_category").notNull(),
  isVisible: integer("is_visible").default(1), // 0 = false, 1 = true
  displayOrder: integer("display_order").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type RoleColumnPermission = typeof roleColumnPermissions.$inferSelect;
export const insertRoleColumnPermissionSchema = createInsertSchema(roleColumnPermissions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertRoleColumnPermission = z.infer<typeof insertRoleColumnPermissionSchema>;
