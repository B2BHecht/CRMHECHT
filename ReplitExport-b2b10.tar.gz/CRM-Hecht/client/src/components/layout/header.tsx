import { Button } from "@/components/ui/button";
import { Bell } from "lucide-react";

interface HeaderProps {
  title: string;
  subtitle: string;
  actionButton?: React.ReactNode;
}

export default function Header({ title, subtitle, actionButton }: HeaderProps) {
  return (
    <header className="bg-card border-b border-border px-4 sm:px-6 py-4" data-testid="page-header">
      <div className="flex items-start sm:items-center justify-between gap-4">
        <div className="flex-1 min-w-0">
          <h2 className="text-xl sm:text-2xl font-semibold text-foreground truncate" data-testid="page-title">
            {title}
          </h2>
          <p className="text-xs sm:text-sm text-muted-foreground hidden sm:block" data-testid="page-subtitle">
            {subtitle}
          </p>
        </div>
        <div className="flex items-center space-x-2 sm:space-x-4 shrink-0">
          <Button 
            variant="ghost" 
            size="icon" 
            className="relative text-muted-foreground hover:text-foreground mobile-button"
            data-testid="notifications-button"
          >
            <Bell className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 h-3 w-3 bg-destructive rounded-full"></span>
          </Button>
          <div className="hidden sm:block">
            {actionButton}
          </div>
        </div>
      </div>
      {/* Mobile action button */}
      <div className="mt-3 sm:hidden">
        {actionButton}
      </div>
    </header>
  );
}
