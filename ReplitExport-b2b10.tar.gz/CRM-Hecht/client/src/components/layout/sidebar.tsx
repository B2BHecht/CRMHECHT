
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useSidebar } from "@/hooks/use-sidebar";
import { 
  Home, 
  Users, 
  Building2, 
  CheckSquare, 
  BarChart3,
  Settings,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
  UserPlus,
  MapPin,
  LogOut
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

const navigation = [
  { name: "Pulpit", href: "/", icon: Home },
  { name: "Klienci", href: "/customers", icon: Users },
  { name: "Potencjalni Klienci", href: "/prospects", icon: UserPlus },
  { name: "Zadania", href: "/tasks", icon: CheckSquare },
  { name: "Raporty", href: "/reports", icon: BarChart3 },
  { name: "Ustawienia", href: "/settings", icon: Settings },
  // Pozycja 'Maps / Street View' została usunięta
];

export default function Sidebar() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { user, logout } = useAuth();
  const isAdmin = user?.role === 'administrator';
  const { isCollapsed, setIsCollapsed, sidebarAutoHide } = useSidebar();

  return (
    <>
      {/* Mobile menu button */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          data-testid="mobile-menu-toggle"
        >
          {isMobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
        </Button>
      </div>

      {/* Mobile overlay */}
      {isMobileMenuOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-black/50 z-40"
          onClick={() => setIsMobileMenuOpen(false)}
          data-testid="mobile-overlay"
        />
      )}

      {/* Sidebar */}
      <aside 
        className={cn(
          "bg-card border-r border-border flex flex-col transition-all duration-300 ease-in-out",
          "lg:relative lg:translate-x-0",
          "fixed top-0 left-0 h-full z-40",
          // Desktop: szerokość zależy od stanu zwinięcia
          isCollapsed ? "lg:w-16" : "lg:w-64",
          // Mobile: normalny sidebar o pełnej szerokości
          "w-64",
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
        data-testid="sidebar"
      >
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between" data-testid="app-title">
            <div className="flex items-center gap-3">
              {/* Na desktop: pokaż tylko H gdy zwinięty, pełne logo gdy rozwinięty */}
              <div className="flex items-center gap-2">
                {/* Pełne logo - ukryte gdy sidebar zwinięty na desktop */}
                <img 
                  src="/attached_assets/logo_1756804449449.webp" 
                  alt="HECHT Logo" 
                  className={cn(
                    "h-8 object-contain transition-opacity duration-200",
                    isCollapsed ? "hidden lg:hidden" : "block"
                  )}
                />
                {/* Logo H - pokazane tylko gdy sidebar zwinięty na desktop */}
                <img 
                  src="/attached_assets/H_1756804438134.png" 
                  alt="HECHT H" 
                  className={cn(
                    "h-8 w-8 object-contain transition-opacity duration-200",
                    isCollapsed ? "hidden lg:block" : "hidden"
                  )}
                />
              </div>
            </div>
            {/* Przycisk zwijania tylko dla desktop */}
            <div className="hidden lg:block">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsCollapsed(!isCollapsed)}
                className="p-1 h-6 w-6"
                data-testid="sidebar-collapse-toggle"
              >
                {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        </div>
        
        <nav className="flex-1 p-4 space-y-2" data-testid="navigation">
          {navigation
            .filter(item => item.name !== 'Ustawienia' || isAdmin)
            .map((item) => {
              const isActive = location === item.href;
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={cn(
                    "flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors",
                    isCollapsed && !isMobileMenuOpen ? "justify-center" : "",
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                  )}
                  data-testid={`nav-${item.name.toLowerCase().replace(' ', '-')}`}
                >
                  <item.icon className={cn(
                    "w-5 h-5 flex-shrink-0",
                    isCollapsed && !isMobileMenuOpen ? "mx-auto" : "mr-3"
                  )} />
                  {(!isCollapsed || isMobileMenuOpen) && (
                    <span className="transition-opacity duration-200">{item.name}</span>
                  )}
                </Link>
              );
            })}
        </nav>
        
        {user && (
          <div className="p-4 border-t border-border" data-testid="user-info">
            <div className={cn("flex items-center", isCollapsed ? "justify-center" : "space-x-3")}>
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <span className="text-sm font-medium text-primary-foreground" data-testid="user-initials">
                  {user.firstName[0]}{user.lastName[0]}
                </span>
              </div>
              {(!isCollapsed || isMobileMenuOpen) && (
                <div className="flex-1 min-w-0 transition-opacity duration-200">
                  <p className="text-sm font-medium text-foreground truncate" data-testid="user-name">
                    {user.firstName} {user.lastName}
                  </p>
                  <p className="text-xs text-muted-foreground truncate" data-testid="user-role">
                    {user.role === 'administrator' && 'Administrator'}
                    {user.role === 'dyrektor' && 'Dyrektor'}
                    {user.role === 'koordynator' && 'Koordynator'}
                    {user.role === 'handlowiec' && 'Handlowiec'}
                  </p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={logout}
                    className="w-full mt-2 text-xs"
                    data-testid="button-logout"
                  >
                    <LogOut className="h-3 w-3 mr-1" />
                    Wyloguj
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}
      </aside>
    </>
  );
}

