
import { useState } from "react";

export default function PhotoCarousel({ photos }: { photos: string[] }) {
  const [idx, setIdx] = useState(0);
  if (!photos?.length) return null;
  const next = () => setIdx((idx + 1) % photos.length);
  const prev = () => setIdx((idx - 1 + photos.length) % photos.length);

  return (
    <div className="relative w-full max-w-3xl overflow-hidden rounded-xl bg-black/60 border border-border">
      {photos.map((src, i) => (
        <img
          key={src + i}
          src={src}
          alt={`photo-${i+1}`}
          className={`w-full h-56 md:h-80 object-cover ${i===idx ? "block" : "hidden"}`}
          loading="lazy"
        />
      ))}
      <button onClick={prev} className="absolute left-2 top-1/2 -translate-y-1/2 px-3 py-2 bg-black/40 text-white rounded-lg">‹</button>
      <button onClick={next} className="absolute right-2 top-1/2 -translate-y-1/2 px-3 py-2 bg-black/40 text-white rounded-lg">›</button>
      <div className="flex gap-2 p-2 overflow-x-auto bg-black/30">
        {photos.map((src, i) => (
          <img
            key={"t"+i}
            src={src}
            onClick={()=>setIdx(i)}
            className={`h-14 w-20 object-cover rounded-md cursor-pointer border ${i===idx?"border-primary":"border-border opacity-70"}`}
            loading="lazy"
            alt={`thumb-${i+1}`}
          />
        ))}
      </div>
    </div>
  );
}
