import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Edit, Trash2 } from "lucide-react";
import type { TaskWithRelations } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

const priorityLabels = {
  low: "Niski",
  medium: "Średni", 
  high: "Wysoki",
};

const priorityVariants = {
  low: "secondary",
  medium: "default",
  high: "destructive",
} as const;

export default function TaskTable() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [deleteTaskId, setDeleteTaskId] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: tasks, isLoading } = useQuery<TaskWithRelations[]>({
    queryKey: ["/api/tasks"],
  });

  const deleteTaskMutation = useMutation({
    mutationFn: async (taskId: string) => {
      await apiRequest("DELETE", `/api/tasks/${taskId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/metrics"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      toast({
        title: "Sukces",
        description: "Zadanie zostało pomyślnie usunięte",
      });
      setDeleteTaskId(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się usunąć zadania",
        variant: "destructive",
      });
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ taskId, completed }: { taskId: string; completed: number }) => {
      const response = await apiRequest("PUT", `/api/tasks/${taskId}`, { completed });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/metrics"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się zaktualizować zadania",
        variant: "destructive",
      });
    },
  });

  const filteredTasks = tasks?.filter(task => {
    const matchesSearch = 
      task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.customer?.contractorName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.deal?.title?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = 
      statusFilter === "all" || 
      (statusFilter === "completed" && task.completed === 1) ||
      (statusFilter === "pending" && task.completed === 0);
    
    return matchesSearch && matchesStatus;
  }) || [];

  return (
    <Card data-testid="task-table">
      <CardHeader>
        <div className="flex items-center space-x-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Szukaj zadań..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
              data-testid="input-search-tasks"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48" data-testid="select-status-filter">
              <SelectValue placeholder="Filtruj według statusu" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Wszystkie Zadania</SelectItem>
              <SelectItem value="pending">Oczekujące</SelectItem>
              <SelectItem value="completed">Zakończone</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4">
                <Skeleton className="h-4 w-4" />
                <Skeleton className="h-4 w-48" />
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-8 w-20" />
              </div>
            ))}
          </div>
        ) : filteredTasks.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-muted-foreground" data-testid="text-no-tasks">
              {searchTerm || statusFilter !== "all" 
                ? "Nie znaleziono zadań pasujących do filtrów." 
                : "Brak zadań. Dodaj pierwsze zadanie, aby zacząć."}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12"></TableHead>
                  <TableHead className="min-w-[180px]">Zadanie</TableHead>
                  <TableHead className="min-w-[120px] hidden sm:table-cell">Klient</TableHead>
                  <TableHead className="min-w-[120px] hidden md:table-cell">Deal</TableHead>
                  <TableHead className="min-w-[100px]">Priorytet</TableHead>
                  <TableHead className="min-w-[120px] hidden lg:table-cell">Termin</TableHead>
                  <TableHead className="text-right min-w-[100px]">Akcje</TableHead>
                </TableRow>
              </TableHeader>
            <TableBody>
              {filteredTasks.map((task) => (
                <TableRow key={task.id} data-testid={`task-row-${task.id}`}>
                  <TableCell>
                    <Checkbox
                      checked={task.completed === 1}
                      onCheckedChange={(checked) => 
                        updateTaskMutation.mutate({ 
                          taskId: task.id, 
                          completed: checked ? 1 : 0 
                        })
                      }
                      data-testid={`checkbox-task-${task.id}`}
                    />
                  </TableCell>
                  <TableCell 
                    className={`font-medium ${task.completed === 1 ? 'line-through text-muted-foreground' : ''}`}
                    data-testid={`cell-title-${task.id}`}
                  >
                    {task.title}
                  </TableCell>
                  <TableCell className="hidden sm:table-cell" data-testid={`cell-customer-${task.id}`}>
                    {task.customer?.contractorName || "-"}
                  </TableCell>
                  <TableCell className="hidden md:table-cell" data-testid={`cell-deal-${task.id}`}>
                    {task.deal?.title || "-"}
                  </TableCell>
                  <TableCell data-testid={`cell-priority-${task.id}`}>
                    <Badge variant={priorityVariants[task.priority as keyof typeof priorityVariants]}>
                      {priorityLabels[task.priority as keyof typeof priorityLabels]}
                    </Badge>
                  </TableCell>
                  <TableCell className="hidden lg:table-cell" data-testid={`cell-due-date-${task.id}`}>
                    {task.dueDate ? format(new Date(task.dueDate), "MMM d, yyyy") : "-"}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end space-x-2">
                      <Button 
                        variant="ghost" 
                        size="sm"
                        data-testid={`button-edit-${task.id}`}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => setDeleteTaskId(task.id)}
                        data-testid={`button-delete-${task.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      <AlertDialog open={!!deleteTaskId} onOpenChange={() => setDeleteTaskId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Usuń Zadanie</AlertDialogTitle>
            <AlertDialogDescription>
              Czy na pewno chcesz usunąć to zadanie? Ta akcja nie może zostać cofnięta.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Anuluj</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteTaskId && deleteTaskMutation.mutate(deleteTaskId)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Usuń
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}
