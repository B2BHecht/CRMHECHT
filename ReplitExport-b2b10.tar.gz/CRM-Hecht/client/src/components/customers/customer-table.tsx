import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Search, Edit, Trash2, MapPin, Globe, Eye, Brain, ChevronLeft, ChevronRight, ArrowUpDown, ArrowUp, ArrowDown, Filter, X, Pin } from "lucide-react";
import type { Customer } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import GoogleMapsModal from "@/components/modals/google-maps-modal";
import { CustomerAIEnrichmentModal } from "@/components/modals/customer-ai-enrichment-modal";

// Funkcja formatowania kwot w złotych
const formatCurrency = (value: string | number): string => {
  const numValue = typeof value === 'string' ? parseFloat(value) || 0 : value;
  return new Intl.NumberFormat('pl-PL', {
    style: 'currency',
    currency: 'PLN'
  }).format(numValue);
};

// Funkcja obliczania sumy obrotów z lat 2020-2025
const calculateTotalRevenue = (customer: Customer): number => {
  const revenues = [
    customer.revenue2020,
    customer.revenue2021,
    customer.revenue2022, 
    customer.revenue2023,
    customer.revenue2024,
    customer.revenue2025
  ];

  return revenues.reduce((sum, revenue) => {
    const value = typeof revenue === 'string' ? parseFloat(revenue) || 0 : revenue || 0;
    return sum + value;
  }, 0);
};

// Definicja dostępnych kolumn i ich kategorii
// Domyślne kolumny, które będą wyświetlane jeśli ustawienia nie są dostępne
const DEFAULT_COLUMNS = [
  { id: 'contractorName', label: 'Nazwa kontrahenta', category: 'basic' },
  { id: 'groupName', label: 'Nazwa grupy', category: 'basic' },
  { id: 'nip', label: 'NIP', category: 'basic' },
  { id: 'city', label: 'Miasto', category: 'location' },
  { id: 'code', label: 'Kod pocztowy', category: 'location' },
  { id: 'streetAddress', label: 'Adres', category: 'location' },
  { id: 'email', label: 'Email', category: 'contact' },
  { id: 'phone', label: 'Telefon', category: 'contact' },
  { id: 'salesperson', label: 'Handlowiec', category: 'management' },
  { id: 'revenue2020', label: 'Obrót 2020', category: 'financial' },
  { id: 'revenue2021', label: 'Obrót 2021', category: 'financial' },
  { id: 'revenue2022', label: 'Obrót 2022', category: 'financial' },
  { id: 'revenue2023', label: 'Obrót 2023', category: 'financial' },
  { id: 'revenue2024', label: 'Obrót 2024', category: 'financial' },
  { id: 'revenue2025', label: 'Obrót 2025', category: 'financial' },
  { id: 'totalRevenue', label: 'Suma kontrahenta', category: 'financial' },
  { id: 'actions', label: 'Akcje', category: 'actions' },
];

export default function CustomerTable() {
  const [searchTerm, setSearchTerm] = useState("");
  const [deleteCustomerId, setDeleteCustomerId] = useState<string | null>(null);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [isGoogleMapsModalOpen, setIsGoogleMapsModalOpen] = useState(false);
  const [isAIEnrichmentModalOpen, setIsAIEnrichmentModalOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [sortColumn, setSortColumn] = useState<string>("");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");
  const [isFirstColumnPinned, setIsFirstColumnPinned] = useState(false);
  const [filters, setFilters] = useState<{[key: string]: string}>({});
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Pobranie konfiguracji kolumn z API na podstawie roli użytkownika
  const { data: rawColumnConfig } = useQuery({
    queryKey: ['/api/role-column-permissions', 'handlowiec', 'customers'],
    // Domyślne kolumny, jeśli dane z API nie są jeszcze dostępne
    initialData: [],
  });

  // Przekształć dane z API do oczekiwanej struktury lub użyj domyślnych kolumn
  const columnConfig = rawColumnConfig && rawColumnConfig.length > 0 
    ? rawColumnConfig
        .filter((permission: any) => permission.isVisible === 1)
        .sort((a: any, b: any) => a.displayOrder - b.displayOrder)
        .map((permission: any) => ({
          id: permission.columnId,
          label: permission.columnLabel,
          category: permission.columnCategory
        }))
        .concat([{ id: 'actions', label: 'Akcje', category: 'actions' }])
    : DEFAULT_COLUMNS;

  const { data: customers, isLoading } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });

  // Pobranie ustawień systemu dla paginacji
  const { data: settings = [] } = useQuery<any[]>({
    queryKey: ["/api/settings"],
  });

  // Funkcja pomocnicza do pobierania wartości ustawienia
  const getSettingValue = (key: string, defaultValue: string) => {
    const setting = settings.find((s: any) => s.key === key);
    return setting?.value || defaultValue;
  };

  const customersPerPage = parseInt(getSettingValue('customers_per_page', '10'));

  // Funkcje sortowania
  const handleSort = (columnId: string) => {
    if (sortColumn === columnId) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortColumn(columnId);
      setSortDirection("asc");
    }
    setCurrentPage(1);
  };

  const getSortIcon = (columnId: string) => {
    if (sortColumn !== columnId) return <ArrowUpDown className="h-4 w-4" />;
    return sortDirection === "asc" ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />;
  };

  // Funkcje filtrowania
  const handleFilterChange = (columnId: string, value: string) => {
    setFilters(prev => ({
      ...prev,
      [columnId]: value
    }));
    setCurrentPage(1);
  };

  const clearFilter = (columnId: string) => {
    setFilters(prev => {
      const newFilters = { ...prev };
      delete newFilters[columnId];
      return newFilters;
    });
  };

  const clearAllFilters = () => {
    setFilters({});
    setCurrentPage(1);
  };

  const deleteCustomerMutation = useMutation({
    mutationFn: async (customerId: string) => {
      await apiRequest("DELETE", `/api/customers/${customerId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/customers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/metrics"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      toast({
        title: "Sukces",
        description: "Klient został pomyślnie usunięty",
      });
      setDeleteCustomerId(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się usunąć klienta",
        variant: "destructive",
      });
    },
  });

  const enrichCustomerMutation = useMutation({
    mutationFn: async (customerId: string) => {
      return await apiRequest("POST", `/api/customers/${customerId}/enrich`);
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/customers"] });
      toast({
        title: "Sukces",
        description: `Wzbogacono dane klienta o ${data.enrichedFields?.length || 0} nowych informacji`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Błąd wzbogacania",
        description: error.message || "Nie udało się wzbogacić danych klienta",
        variant: "destructive",
      });
    },
  });

  // Tworzenie mapy ID kolumn na podstawie konfiguracji
  const visibleColumns = columnConfig.filter(col => col.category !== 'actions'); // Wyklucz kolumnę akcji z widocznych
  const columnVisibilityMap = new Map(visibleColumns.map(col => [col.id, true])); // Domyślnie wszystkie są widoczne

  const filteredCustomers = customers?.filter(customer => {
    // Ukryj potencjalnych klientów na stronie klientów (oni są na stronie "Potencjalni Klienci")
    if (customer.classification === "POTENCJALNY") return false;
    
    // Filtrowanie przez wyszukiwanie
    const matchesSearch = searchTerm === "" || 
      customer.contractorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.groupName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.email?.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (!matchesSearch) return false;
    
    // Filtrowanie przez kolumny
    for (const [columnId, filterValue] of Object.entries(filters)) {
      if (!filterValue) continue;
      
      const customerValue = customer[columnId as keyof Customer];
      if (typeof customerValue === 'string') {
        if (!customerValue.toLowerCase().includes(filterValue.toLowerCase())) {
          return false;
        }
      } else if (typeof customerValue === 'number') {
        if (!customerValue.toString().includes(filterValue)) {
          return false;
        }
      }
    }
    
    return true;
  }) || [];

  // Sortowanie
  const sortedCustomers = [...filteredCustomers].sort((a, b) => {
    if (!sortColumn) return 0;
    
    const aValue = a[sortColumn as keyof Customer] || "";
    const bValue = b[sortColumn as keyof Customer] || "";
    
    let comparison = 0;
    if (typeof aValue === 'string' && typeof bValue === 'string') {
      comparison = aValue.toLowerCase().localeCompare(bValue.toLowerCase());
    } else if (typeof aValue === 'number' && typeof bValue === 'number') {
      comparison = aValue - bValue;
    } else {
      comparison = String(aValue).localeCompare(String(bValue));
    }
    
    return sortDirection === "asc" ? comparison : -comparison;
  });

  // Paginacja
  const totalPages = Math.ceil(sortedCustomers.length / customersPerPage);
  const startIndex = (currentPage - 1) * customersPerPage;
  const endIndex = startIndex + customersPerPage;
  const paginatedCustomers = sortedCustomers.slice(startIndex, endIndex);

  // Reset current page when search changes
  const handleSearchChange = (value: string) => {
    setSearchTerm(value);
    setCurrentPage(1);
  };

  return (
    <Card data-testid="customer-table">
      <CardHeader>
        <div className="flex items-center space-x-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Szukaj klientów..."
              value={searchTerm}
              onChange={(e) => handleSearchChange(e.target.value)}
              className="pl-10"
              data-testid="input-search-customers"
            />
          </div>
          
          {/* Przycisk blokowania pierwszej kolumny */}
          <Button
            variant={isFirstColumnPinned ? "default" : "outline"}
            size="sm"
            onClick={() => setIsFirstColumnPinned(!isFirstColumnPinned)}
            data-testid="button-pin-column"
            title={isFirstColumnPinned ? "Odblokuj pierwszą kolumnę" : "Zablokuj pierwszą kolumnę"}
          >
            <Pin className="h-4 w-4" />
          </Button>
          
          {/* Przycisk filtrów */}
          <Popover open={isFilterOpen} onOpenChange={setIsFilterOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                data-testid="button-filters"
              >
                <Filter className="h-4 w-4" />
                Filtry
                {Object.keys(filters).length > 0 && (
                  <Badge variant="secondary" className="ml-2">
                    {Object.keys(filters).length}
                  </Badge>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80" align="end">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">Filtry kolumn</h4>
                  {Object.keys(filters).length > 0 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={clearAllFilters}
                      data-testid="button-clear-filters"
                    >
                      <X className="h-4 w-4" />
                      Wyczyść
                    </Button>
                  )}
                </div>
                
                {columnConfig
                  .filter(col => col.category !== 'actions')
                  .slice(0, 6)
                  .map((column) => (
                    <div key={column.id} className="space-y-2">
                      <Label htmlFor={`filter-${column.id}`}>{column.label}</Label>
                      <div className="flex gap-2">
                        <Input
                          id={`filter-${column.id}`}
                          placeholder={`Filtruj ${column.label.toLowerCase()}...`}
                          value={filters[column.id] || ""}
                          onChange={(e) => handleFilterChange(column.id, e.target.value)}
                          data-testid={`input-filter-${column.id}`}
                        />
                        {filters[column.id] && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => clearFilter(column.id)}
                            data-testid={`button-clear-filter-${column.id}`}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  ))
                }
              </div>
            </PopoverContent>
          </Popover>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-4 w-48" />
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-8 w-20" />
              </div>
            ))}
          </div>
        ) : filteredCustomers.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-muted-foreground" data-testid="text-no-customers">
              {searchTerm ? "Nie znaleziono klientów pasujących do wyszukiwania." : "Brak klientów. Dodaj pierwszego klienta, aby zacząć."}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table className={isFirstColumnPinned ? "table-fixed" : ""}>
              <TableHeader>
                <TableRow>
                  {/* Renderowanie nagłówków kolumn na podstawie konfiguracji */}
                  {columnConfig.map((column, index) => (
                    column.category !== 'actions' ? (
                      <TableHead 
                        key={column.id} 
                        className={`min-w-[120px] ${
                          column.id === 'email' ? 'hidden sm:table-cell' : 
                          column.id === 'phone' ? 'hidden md:table-cell' : 
                          column.id === 'city' ? 'hidden lg:table-cell' : 
                          column.id === 'salesperson' ? 'hidden xl:table-cell' : ''
                        } ${
                          isFirstColumnPinned && index === 0 ? 'sticky left-0 bg-background z-10 border-r' : ''
                        }`}
                      >
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleSort(column.id)}
                          className="h-auto p-0 hover:bg-transparent"
                          data-testid={`button-sort-${column.id}`}
                        >
                          <span className="flex items-center gap-2">
                            {column.label}
                            {getSortIcon(column.id)}
                          </span>
                        </Button>
                      </TableHead>
                    ) : null
                  ))}
                  <TableHead className={`text-right min-w-[100px] ${
                    isFirstColumnPinned ? 'sticky right-0 bg-background z-10 border-l' : ''
                  }`}>Akcje</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedCustomers.map((customer) => (
                  <TableRow key={customer.id} data-testid={`customer-row-${customer.id}`}>
                    {/* Renderowanie komórek danych na podstawie konfiguracji */}
                    {columnConfig.map((column, index) => (
                      column.category !== 'actions' && (
                        <TableCell 
                          key={column.id} 
                          data-testid={`cell-${column.id}-${customer.id}`} 
                          className={`${
                            column.id === 'email' ? 'hidden sm:table-cell' : 
                            column.id === 'phone' ? 'hidden md:table-cell' : 
                            column.id === 'city' ? 'hidden lg:table-cell' : 
                            column.id === 'salesperson' ? 'hidden xl:table-cell' : ''
                          } ${
                            isFirstColumnPinned && index === 0 ? 'sticky left-0 bg-background z-10 border-r' : ''
                          }`}
                        >
                          {column.id === 'contractorName' && <span className="font-medium">{customer.contractorName}</span>}
                          {column.id === 'groupName' && <>{customer.groupName || "-"}</>}
                          {column.id === 'nip' && <>{customer.nip || "-"}</>}
                          {column.id === 'city' && <>{customer.city || "-"}</>}
                          {column.id === 'code' && <>{customer.code || "-"}</>}
                          {column.id === 'streetAddress' && <>{customer.streetAddress || "-"}</>}
                          {column.id === 'email' && <>{customer.email || "-"}</>}
                          {column.id === 'phone' && <>{customer.phone || "-"}</>}
                          {column.id === 'salesperson' && <>{customer.salesperson || "-"}</>}
                          {column.id === 'revenue2020' && <span className="text-blue-600 dark:text-blue-400">{formatCurrency(customer.revenue2020 || "0")}</span>}
                          {column.id === 'revenue2021' && <span className="text-blue-600 dark:text-blue-400">{formatCurrency(customer.revenue2021 || "0")}</span>}
                          {column.id === 'revenue2022' && <span className="text-blue-600 dark:text-blue-400">{formatCurrency(customer.revenue2022 || "0")}</span>}
                          {column.id === 'revenue2023' && <span className="text-blue-600 dark:text-blue-400">{formatCurrency(customer.revenue2023 || "0")}</span>}
                          {column.id === 'revenue2024' && <span className="text-blue-600 dark:text-blue-400">{formatCurrency(customer.revenue2024 || "0")}</span>}
                          {column.id === 'revenue2025' && <span className="text-blue-600 dark:text-blue-400">{formatCurrency(customer.revenue2025 || "0")}</span>}
                          {column.id === 'totalRevenue' && (
                            <span className="font-medium text-green-700 dark:text-green-400">
                              {formatCurrency(calculateTotalRevenue(customer))}
                            </span>
                          )}
                        </TableCell>
                      )
                    ))}
                    {/* Komórka akcji - powinna być taka sama jak w prospect-table.tsx */}
                    <TableCell className={`text-right ${
                      isFirstColumnPinned ? 'sticky right-0 bg-background z-10 border-l' : ''
                    }`}>
                      <div className="flex justify-end space-x-1">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => enrichCustomerMutation.mutate(customer.id)}
                          disabled={enrichCustomerMutation.isPending}
                          title="Wzbogać dane Google Maps"
                          data-testid={`button-enrich-${customer.id}`}
                        >
                          <MapPin className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => {
                            setSelectedCustomer(customer);
                            setIsAIEnrichmentModalOpen(true);
                          }}
                          title="Wzbogać dane AI"
                          data-testid={`button-ai-enrich-${customer.id}`}
                        >
                          <Brain className="h-4 w-4" />
                        </Button>
                        {customer.website && (
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => customer.website && window.open(customer.website, '_blank')}
                            title="Odwiedź stronę internetową"
                            data-testid={`button-website-${customer.id}`}
                          >
                            <Globe className="h-4 w-4" />
                          </Button>
                        )}
                        {(customer.streetViewAvailable || customer.googlePlaceId || customer.enrichedAt) && (
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => {
                              setSelectedCustomer(customer);
                              setIsGoogleMapsModalOpen(true);
                            }}
                            title="Zobacz informacje Google Maps"
                            data-testid={`button-googleinfo-${customer.id}`}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        )}
                        <Button 
                          variant="ghost" 
                          size="sm"
                          data-testid={`button-edit-${customer.id}`}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => setDeleteCustomerId(customer.id)}
                          data-testid={`button-delete-${customer.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}

        {/* Kontrolki paginacji */}
        {filteredCustomers.length > 0 && totalPages > 1 && (
          <div className="mt-4 flex items-center justify-between border-t pt-4">
            <div className="text-sm text-muted-foreground">
              Strona {currentPage} z {totalPages} • Wyświetlanie {startIndex + 1}-{Math.min(endIndex, sortedCustomers.length)} z {sortedCustomers.length} klientów
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                data-testid="button-prev-page"
              >
                <ChevronLeft className="h-4 w-4" />
                Poprzednia
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
                data-testid="button-next-page"
              >
                Następna
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </CardContent>

      <AlertDialog open={!!deleteCustomerId} onOpenChange={() => setDeleteCustomerId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Usuń Klienta</AlertDialogTitle>
            <AlertDialogDescription>
              Czy na pewno chcesz usunąć tego klienta? Ta akcja nie może zostać cofnięta i usunie także wszystkie powiązane deale i zadania.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Anuluj</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteCustomerId && deleteCustomerMutation.mutate(deleteCustomerId)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Usuń
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {selectedCustomer && (
        <GoogleMapsModal
          isOpen={isGoogleMapsModalOpen}
          onClose={() => {
            setIsGoogleMapsModalOpen(false);
            setSelectedCustomer(null);
          }}
          customer={selectedCustomer}
        />
      )}

      {selectedCustomer && (
        <CustomerAIEnrichmentModal
          isOpen={isAIEnrichmentModalOpen}
          onClose={() => setIsAIEnrichmentModalOpen(false)}
          customerId={selectedCustomer.id}
          customerName={selectedCustomer.contractorName}
          currentNotes={selectedCustomer.notes || ""}
        />
      )}
    </Card>
  );
}