import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Edit, Trash2, Building2, Activity, Sparkles, MapPin, Globe, Eye, Brain, ChevronLeft, ChevronRight, ChevronUp, ChevronDown, ArrowUpDown, ArrowUp, ArrowDown, Filter, X, Pin } from "lucide-react";
import type { Prospect } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import AddActivityModal from "@/components/modals/add-activity-modal";
import { AIEnrichmentModal } from "@/components/modals/ai-enrichment-modal";
import GoogleMapsModal from "@/components/modals/google-maps-modal";

const statusLabels = {
  new: "Nowy",
  contacted: "Skontaktowany",
  qualified: "Kwalifikowany",
  negotiation: "Negocjacje",
  won: "Wygrany",
  lost: "Przegrany",
};

const statusVariants = {
  new: "secondary",
  contacted: "default",
  qualified: "default",
  negotiation: "default",
  won: "default",
  lost: "destructive",
} as const;

const statusIcons = {
  new: "🔵",
  contacted: "🟡",
  qualified: "🟢",
  negotiation: "⚡",
  won: "🎉",
  lost: "🔴",
};

export default function ProspectTable() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [deleteProspectId, setDeleteProspectId] = useState<string | null>(null);
  const [activityProspectId, setActivityProspectId] = useState<string | null>(null);
  const [aiEnrichmentProspect, setAiEnrichmentProspect] = useState<{id: string, name: string, notes?: string} | null>(null);
  const [selectedProspect, setSelectedProspect] = useState<Prospect | null>(null);
  const [isGoogleMapsModalOpen, setIsGoogleMapsModalOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [sortColumn, setSortColumn] = useState<string>("");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");
  
  const sortConfig = sortColumn ? { key: sortColumn, direction: sortDirection } : null;
  const [isFirstColumnPinned, setIsFirstColumnPinned] = useState(false);
  const [filters, setFilters] = useState<{[key: string]: string}>({});
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: prospects, isLoading } = useQuery<Prospect[]>({
    queryKey: ["/api/prospects"],
  });

  // Pobranie ustawień systemu dla paginacji
  const { data: settings = [] } = useQuery<any[]>({
    queryKey: ["/api/settings"],
  });

  // Funkcja pomocnicza do pobierania wartości ustawienia
  const getSettingValue = (key: string, defaultValue: string) => {
    const setting = settings.find((s: any) => s.key === key);
    return setting?.value || defaultValue;
  };

  const customersPerPage = parseInt(getSettingValue('customers_per_page', '10'));

  // Funkcje sortowania
  const handleSort = (columnId: string) => {
    if (sortColumn === columnId) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortColumn(columnId);
      setSortDirection("asc");
    }
    setCurrentPage(1);
  };

  const getSortIcon = (columnId: string) => {
    if (sortColumn !== columnId) return <ArrowUpDown className="h-4 w-4" />;
    return sortDirection === "asc" ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />;
  };

  // Funkcje filtrowania
  const handleFilterChange = (columnId: string, value: string) => {
    setFilters(prev => ({
      ...prev,
      [columnId]: value
    }));
    setCurrentPage(1);
  };

  const clearFilter = (columnId: string) => {
    setFilters(prev => {
      const newFilters = { ...prev };
      delete newFilters[columnId];
      return newFilters;
    });
  };

  const clearAllFilters = () => {
    setFilters({});
    setCurrentPage(1);
  };

  // Reset current page when search changes
  const handleSearchChange = (value: string) => {
    setSearchTerm(value);
    setCurrentPage(1);
  };

  const deleteProspectMutation = useMutation({
    mutationFn: async (prospectId: string) => {
      await apiRequest("DELETE", `/api/prospects/${prospectId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prospects"] });
      toast({
        title: "Sukces",
        description: "Potencjalny klient został usunięty.",
      });
      setDeleteProspectId(null);
    },
    onError: () => {
      toast({
        title: "Błąd",
        description: "Nie udało się usunąć potencjalnego klienta.",
        variant: "destructive",
      });
    },
  });

  const enrichProspectMutation = useMutation({
    mutationFn: async (prospectId: string) => {
      await apiRequest("POST", `/api/prospects/${prospectId}/enrich`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prospects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/metrics"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      toast({
        title: "Sukces",
        description: "Dane zostały wzbogacone przez Google Maps",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się wzbogacić danych",
        variant: "destructive",
      });
    },
  });


  const filteredProspects = prospects?.filter(prospect => {
    const matchesSearch = searchTerm === "" ||
      prospect.contractorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (prospect.email || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
      (prospect.phone || "").includes(searchTerm) ||
      (prospect.city || "").toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || prospect.status === statusFilter;
    
    if (!matchesSearch || !matchesStatus) return false;
    
    // Filtrowanie przez kolumny
    for (const [columnId, filterValue] of Object.entries(filters)) {
      if (!filterValue) continue;
      
      const prospectValue = prospect[columnId as keyof Prospect];
      if (typeof prospectValue === 'string') {
        if (!prospectValue.toLowerCase().includes(filterValue.toLowerCase())) {
          return false;
        }
      } else if (typeof prospectValue === 'number') {
        if (!prospectValue.toString().includes(filterValue)) {
          return false;
        }
      }
    }
    
    return true;
  }) || [];

  // Sortowanie
  const sortedProspects = [...filteredProspects].sort((a, b) => {
    if (!sortColumn) return 0;
    
    const aValue = a[sortColumn as keyof Prospect] || "";
    const bValue = b[sortColumn as keyof Prospect] || "";
    
    let comparison = 0;
    if (typeof aValue === 'string' && typeof bValue === 'string') {
      comparison = aValue.toLowerCase().localeCompare(bValue.toLowerCase());
    } else if (typeof aValue === 'number' && typeof bValue === 'number') {
      comparison = aValue - bValue;
    } else {
      comparison = String(aValue).localeCompare(String(bValue));
    }
    
    return sortDirection === "asc" ? comparison : -comparison;
  });

  // Paginacja
  const itemsPerPage = customersPerPage;
  const totalItems = sortedProspects.length;
  const totalPages = Math.ceil(sortedProspects.length / customersPerPage);
  const startIndex = (currentPage - 1) * customersPerPage;
  const endIndex = startIndex + customersPerPage;
  const paginatedProspects = sortedProspects.slice(startIndex, endIndex);
  
  // Funkcja pomocnicza do generowania numerów stron
  const getPageNumbers = (current: number, total: number) => {
    const pages: (number | string)[] = [];
    
    if (total <= 7) {
      for (let i = 1; i <= total; i++) {
        pages.push(i);
      }
    } else {
      pages.push(1);
      
      if (current > 3) {
        pages.push('...');
      }
      
      const start = Math.max(2, current - 1);
      const end = Math.min(total - 1, current + 1);
      
      for (let i = start; i <= end; i++) {
        pages.push(i);
      }
      
      if (current < total - 2) {
        pages.push('...');
      }
      
      if (total > 1) {
        pages.push(total);
      }
    }
    
    return pages;
  };

  const renderActionButtons = (prospect: Prospect) => (
    <div className="flex justify-end space-x-1">
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setActivityProspectId(prospect.id)}
        data-testid={`button-add-activity-${prospect.id}`}
        title="Dodaj aktywność"
      >
        <Activity className="h-4 w-4" />
      </Button>
      <Button 
        variant="ghost" 
        size="sm"
        onClick={() => enrichProspectMutation.mutate(prospect.id)}
        disabled={enrichProspectMutation.isPending}
        title="Wzbogać dane Google Maps"
        data-testid={`button-enrich-${prospect.id}`}
      >
        <MapPin className="h-4 w-4" />
      </Button>
      <Button 
        variant="ghost" 
        size="sm"
        onClick={() => setAiEnrichmentProspect({
          id: prospect.id,
          name: prospect.contractorName,
          notes: prospect.notes || undefined
        })}
        title="Wzbogać dane AI"
        data-testid={`button-ai-enrich-${prospect.id}`}
      >
        <Brain className="h-4 w-4" />
      </Button>
      {prospect.facebook_url && (
        <Button 
          variant="ghost" 
          size="sm"
          onClick={() => prospect.facebook_url && window.open(prospect.facebook_url, '_blank')}
          title="Odwiedź stronę Facebook"
          data-testid={`button-facebook-${prospect.id}`}
        >
          <Globe className="h-4 w-4" />
        </Button>
      )}
      {(prospect.streetview_available || prospect.googlePlaceId || prospect.google_photos) && (
        <Button 
          variant="ghost" 
          size="sm"
          onClick={() => {
            setSelectedProspect(prospect);
            setIsGoogleMapsModalOpen(true);
          }}
          title="Zobacz informacje Google Maps"
          data-testid={`button-googleinfo-${prospect.id}`}
        >
          <Eye className="h-4 w-4" />
        </Button>
      )}
      <Button
        variant="ghost"
        size="sm"
        data-testid={`button-edit-prospect-${prospect.id}`}
        title="Edytuj potencjalnego klienta"
      >
        <Edit className="h-4 w-4" />
      </Button>
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setDeleteProspectId(prospect.id)}
        data-testid={`button-delete-prospect-${prospect.id}`}
        title="Usuń potencjalnego klienta"
      >
        <Trash2 className="h-4 w-4" />
      </Button>
    </div>
  );

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row gap-4">
            <Skeleton className="h-10 flex-1" />
            <Skeleton className="h-10 w-40" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Szukaj po nazwie, e-mail, telefonie, mieście..."
              value={searchTerm}
              onChange={(e) => handleSearchChange(e.target.value)}
              className="pl-10"
              data-testid="input-search-prospects"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-40" data-testid="select-status-filter">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Wszystkie</SelectItem>
              {Object.entries(statusLabels).map(([status, label]) => (
                <SelectItem key={status} value={status}>
                  {statusIcons[status as keyof typeof statusIcons]} {label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          {/* Przycisk blokowania pierwszej kolumny */}
          <Button
            variant={isFirstColumnPinned ? "default" : "outline"}
            size="sm"
            onClick={() => setIsFirstColumnPinned(!isFirstColumnPinned)}
            data-testid="button-pin-column-prospects"
            title={isFirstColumnPinned ? "Odblokuj pierwszą kolumnę" : "Zablokuj pierwszą kolumnę"}
          >
            <Pin className="h-4 w-4" />
          </Button>
          
          {/* Przycisk filtrów */}
          <Popover open={isFilterOpen} onOpenChange={setIsFilterOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                data-testid="button-filters-prospects"
              >
                <Filter className="h-4 w-4" />
                Filtry
                {Object.keys(filters).length > 0 && (
                  <Badge variant="secondary" className="ml-2">
                    {Object.keys(filters).length}
                  </Badge>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80" align="end">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">Filtry kolumn</h4>
                  {Object.keys(filters).length > 0 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={clearAllFilters}
                      data-testid="button-clear-filters-prospects"
                    >
                      <X className="h-4 w-4" />
                      Wyczyść
                    </Button>
                  )}
                </div>
                
                {['contractorName', 'email', 'phone', 'city', 'salesperson', 'notes']
                  .map((columnId) => {
                    const columnLabels: {[key: string]: string} = {
                      contractorName: 'Nazwa kontrahenta',
                      email: 'Email',
                      phone: 'Telefon',
                      city: 'Miasto',
                      salesperson: 'Handlowiec',
                      notes: 'Notatki'
                    };
                    
                    return (
                      <div key={columnId} className="space-y-2">
                        <Label htmlFor={`filter-${columnId}`}>{columnLabels[columnId]}</Label>
                        <div className="flex gap-2">
                          <Input
                            id={`filter-${columnId}`}
                            placeholder={`Filtruj ${columnLabels[columnId].toLowerCase()}...`}
                            value={filters[columnId] || ""}
                            onChange={(e) => handleFilterChange(columnId, e.target.value)}
                            data-testid={`input-filter-${columnId}-prospects`}
                          />
                          {filters[columnId] && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => clearFilter(columnId)}
                              data-testid={`button-clear-filter-${columnId}-prospects`}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    );
                  })
                }
              </div>
            </PopoverContent>
          </Popover>
        </div>
      </CardHeader>

      <CardContent>
        {filteredProspects.length === 0 ? (
          <div className="text-center py-12">
            <Building2 className="mx-auto h-12 w-12 text-muted-foreground" />
            <h3 className="mt-4 text-lg font-semibold text-foreground">Brak potencjalnych klientów</h3>
            <p className="mt-2 text-muted-foreground">
              {searchTerm || statusFilter !== "all" 
                ? "Brak wyników spełniających kryteria wyszukiwania."
                : "Rozpocznij dodając swojego pierwszego potencjalnego klienta."
              }
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead 
                    className="cursor-pointer hover:bg-muted/50 select-none"
                    onClick={() => handleSort('contractorName')}
                    data-testid="header-sort-name-prospects"
                  >
                    <div className="flex items-center">
                      Nazwa
                      <div className="ml-1 flex flex-col">
                        <ChevronUp className={`h-3 w-3 ${sortConfig?.key === 'contractorName' && sortConfig.direction === 'asc' ? 'text-primary' : 'text-muted-foreground'}`} />
                        <ChevronDown className={`h-3 w-3 -mt-1 ${sortConfig?.key === 'contractorName' && sortConfig.direction === 'desc' ? 'text-primary' : 'text-muted-foreground'}`} />
                      </div>
                    </div>
                  </TableHead>
                  <TableHead 
                    className="cursor-pointer hover:bg-muted/50 select-none"
                    onClick={() => handleSort('city')}
                    data-testid="header-sort-city-prospects"
                  >
                    <div className="flex items-center">
                      Adres
                      <div className="ml-1 flex flex-col">
                        <ChevronUp className={`h-3 w-3 ${sortConfig?.key === 'city' && sortConfig.direction === 'asc' ? 'text-primary' : 'text-muted-foreground'}`} />
                        <ChevronDown className={`h-3 w-3 -mt-1 ${sortConfig?.key === 'city' && sortConfig.direction === 'desc' ? 'text-primary' : 'text-muted-foreground'}`} />
                      </div>
                    </div>
                  </TableHead>
                  <TableHead 
                    className="cursor-pointer hover:bg-muted/50 select-none"
                    onClick={() => handleSort('email')}
                    data-testid="header-sort-email-prospects"
                  >
                    <div className="flex items-center">
                      Kontakt
                      <div className="ml-1 flex flex-col">
                        <ChevronUp className={`h-3 w-3 ${sortConfig?.key === 'email' && sortConfig.direction === 'asc' ? 'text-primary' : 'text-muted-foreground'}`} />
                        <ChevronDown className={`h-3 w-3 -mt-1 ${sortConfig?.key === 'email' && sortConfig.direction === 'desc' ? 'text-primary' : 'text-muted-foreground'}`} />
                      </div>
                    </div>
                  </TableHead>
                  <TableHead 
                    className="cursor-pointer hover:bg-muted/50 select-none"
                    onClick={() => handleSort('salesperson')}
                    data-testid="header-sort-salesperson-prospects"
                  >
                    <div className="flex items-center">
                      Handlowiec
                      <div className="ml-1 flex flex-col">
                        <ChevronUp className={`h-3 w-3 ${sortConfig?.key === 'salesperson' && sortConfig.direction === 'asc' ? 'text-primary' : 'text-muted-foreground'}`} />
                        <ChevronDown className={`h-3 w-3 -mt-1 ${sortConfig?.key === 'salesperson' && sortConfig.direction === 'desc' ? 'text-primary' : 'text-muted-foreground'}`} />
                      </div>
                    </div>
                  </TableHead>
                  <TableHead 
                    className="cursor-pointer hover:bg-muted/50 select-none"
                    onClick={() => handleSort('status')}
                    data-testid="header-sort-status-prospects"
                  >
                    <div className="flex items-center">
                      Status
                      <div className="ml-1 flex flex-col">
                        <ChevronUp className={`h-3 w-3 ${sortConfig?.key === 'status' && sortConfig.direction === 'asc' ? 'text-primary' : 'text-muted-foreground'}`} />
                        <ChevronDown className={`h-3 w-3 -mt-1 ${sortConfig?.key === 'status' && sortConfig.direction === 'desc' ? 'text-primary' : 'text-muted-foreground'}`} />
                      </div>
                    </div>
                  </TableHead>
                  <TableHead>Notatki AI</TableHead>
                  <TableHead className="text-right">Akcje</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedProspects.map((prospect) => (
                  <TableRow key={prospect.id} data-testid={`row-prospect-${prospect.id}`}>
                    <TableCell className="font-medium">
                      <div>
                        <div data-testid={`text-prospect-name-${prospect.id}`}>
                          {prospect.contractorName}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div>{prospect.streetAddress}</div>
                        <div className="text-muted-foreground">
                          {prospect.postalCode} {prospect.city}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div>{prospect.email}</div>
                        <div className="text-muted-foreground">{prospect.phone}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm">{prospect.salesperson}</span>
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={statusVariants[prospect.status as keyof typeof statusVariants]}
                        data-testid={`badge-status-${prospect.id}`}
                      >
                        {statusIcons[prospect.status as keyof typeof statusIcons]} {statusLabels[prospect.status as keyof typeof statusLabels]}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm max-w-xs">
                        {prospect.notes ? (
                          <span className="text-green-600 dark:text-green-400" title={prospect.notes}>
                            {prospect.notes.length > 50 ? `${prospect.notes.substring(0, 50)}...` : prospect.notes}
                          </span>
                        ) : (
                          <span className="text-muted-foreground">Brak danych AI</span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      {renderActionButtons(prospect)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
        
        {/* Paginacja */}
        {filteredProspects.length > 0 && (
          <div className="flex items-center justify-between px-4 py-4 border-t">
            <div className="text-sm text-muted-foreground">
              Pokazano {((currentPage - 1) * itemsPerPage) + 1}-{Math.min(currentPage * itemsPerPage, totalItems)} z {totalItems} pozycji
            </div>
            
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(currentPage - 1)}
                disabled={currentPage === 1}
                data-testid="button-prev-page-prospects"
              >
                <ChevronLeft className="h-4 w-4" />
                Poprzednia
              </Button>
              
              <div className="flex items-center space-x-1">
                {getPageNumbers(currentPage, totalPages).map((pageNum) =>
                  pageNum === '...' ? (
                    <span key={Math.random()} className="px-2 text-muted-foreground">...</span>
                  ) : (
                    <Button
                      key={pageNum}
                      variant={currentPage === pageNum ? "default" : "outline"}
                      size="sm"
                      onClick={() => setCurrentPage(pageNum as number)}
                      data-testid={`button-page-${pageNum}-prospects`}
                      className="w-8 h-8 p-0"
                    >
                      {pageNum}
                    </Button>
                  )
                )}
              </div>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(currentPage + 1)}
                disabled={currentPage === totalPages}
                data-testid="button-next-page-prospects"
              >
                Następna
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </CardContent>

      <AlertDialog open={!!deleteProspectId} onOpenChange={() => setDeleteProspectId(null)}>
        <AlertDialogContent data-testid="dialog-delete-prospect">
          <AlertDialogHeader>
            <AlertDialogTitle>Usunąć potencjalnego klienta?</AlertDialogTitle>
            <AlertDialogDescription>
              Ta akcja jest nieodwracalna. Potencjalny klient zostanie trwale usunięty z systemu.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete">
              Anuluj
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteProspectId && deleteProspectMutation.mutate(deleteProspectId)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete"
            >
              Usuń
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AddActivityModal
        isOpen={!!activityProspectId}
        onClose={() => setActivityProspectId(null)}
        prospectId={activityProspectId || undefined}
      />

      {/* Modal wzbogacania AI */}
      <AIEnrichmentModal
        isOpen={!!aiEnrichmentProspect}
        onClose={() => setAiEnrichmentProspect(null)}
        prospectId={aiEnrichmentProspect?.id || ""}
        prospectName={aiEnrichmentProspect?.name || ""}
        currentNotes={aiEnrichmentProspect?.notes}
      />

      {/* Google Maps Modal */}
      <GoogleMapsModal
        isOpen={isGoogleMapsModalOpen}
        onClose={() => setIsGoogleMapsModalOpen(false)}
        customer={selectedProspect as any}
      />

    </Card>
  );
}