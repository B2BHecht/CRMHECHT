import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { insertProspectSchema, type InsertProspect } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AddProspectModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const acquisitionMethods = [
  "Rekomendacja",
  "Marketing internetowy",
  "Targi",
  "Cold calling",
  "LinkedIn",
  "Facebook",
  "Strona internetowa",
  "Inne"
];

const salespeople = [
  "Jan Kowalski",
  "Anna Nowak", 
  "Piotr Wiśniewski",
  "Katarzyna Dąbrowska",
  "Michał Lewandowski"
];

export default function AddProspectModal({ isOpen, onClose }: AddProspectModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertProspect>({
    resolver: zodResolver(insertProspectSchema),
    defaultValues: {
      contractorName: "",
      streetAddress: "",
      postalCode: "",
      city: "",
      phone: "",
      email: "",
      acquisitionMethod: "",
      salesperson: "",
      status: "new",
      notes: "",
    },
  });

  const createProspectMutation = useMutation({
    mutationFn: async (data: InsertProspect) => {
      return await apiRequest("POST", "/api/prospects", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prospects"] });
      toast({
        title: "Sukces",
        description: "Potencjalny klient został pomyślnie dodany.",
      });
      form.reset();
      onClose();
    },
    onError: () => {
      toast({
        title: "Błąd",
        description: "Nie udało się dodać potencjalnego klienta.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertProspect) => {
    createProspectMutation.mutate(data);
  };

  const handleClose = () => {
    form.reset();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="w-[95vw] sm:w-full sm:max-w-[600px] max-h-[90vh] overflow-y-auto" data-testid="dialog-add-prospect">
        <DialogHeader>
          <DialogTitle>Dodaj Potencjalnego Klienta</DialogTitle>
          <DialogDescription>
            Wprowadź dane nowego potencjalnego klienta do systemu.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="contractorName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nazwa kontrahenta *</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Wprowadź nazwę kontrahenta"
                      {...field}
                      data-testid="input-contractor-name"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="streetAddress"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Adres</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="ul. Przykładowa 123"
                        {...field}
                        data-testid="input-street-address"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="postalCode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Kod pocztowy</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="00-000"
                        {...field}
                        data-testid="input-postal-code"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="city"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Miasto</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Warszawa"
                      {...field}
                      data-testid="input-city"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Telefon</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="+48 123 456 789"
                        {...field}
                        data-testid="input-phone"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>E-mail</FormLabel>
                    <FormControl>
                      <Input
                        type="email"
                        placeholder="kontakt@example.com"
                        {...field}
                        data-testid="input-email"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="acquisitionMethod"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Sposób pozyskania</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-acquisition-method">
                          <SelectValue placeholder="Wybierz sposób pozyskania" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {acquisitionMethods.map((method) => (
                          <SelectItem key={method} value={method}>
                            {method}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="salesperson"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Handlowiec</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-salesperson">
                          <SelectValue placeholder="Wybierz handlowca" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {salespeople.map((person) => (
                          <SelectItem key={person} value={person}>
                            {person}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notatki</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Dodatkowe informacje o potencjalnym kliencie..."
                      className="resize-none"
                      rows={3}
                      {...field}
                      data-testid="textarea-notes"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end space-x-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={handleClose}
                data-testid="button-cancel-prospect"
              >
                Anuluj
              </Button>
              <Button
                type="submit"
                disabled={createProspectMutation.isPending}
                data-testid="button-save-prospect"
              >
                {createProspectMutation.isPending ? "Zapisywanie..." : "Zapisz"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}