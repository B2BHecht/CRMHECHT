import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Upload, FileSpreadsheet, Check, X, AlertCircle } from "lucide-react";
import * as XLSX from 'xlsx';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface ImportExcelModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface ExcelRow {
  [key: string]: any;
}

interface ColumnMapping {
  excelColumn: string;
  crmField: string;
}

const CRM_FIELDS = [
  { value: "groupName", label: "Nazwa grupy" },
  { value: "contractorName", label: "Nazwa kontrahenta" },
  { value: "nip", label: "NIP" },
  { value: "city", label: "Miasto" },
  { value: "code", label: "Kod" },
  { value: "streetAddress", label: "Ulica, nr lokalu" },
  { value: "contract", label: "Umowa" },
  { value: "classification", label: "Nazwa klasyfikacji" },
  { value: "salesperson", label: "Handlowiec" },
  { value: "email", label: "E-mail kontrahenta" },
  { value: "phone", label: "Nr telefonu" },
  { value: "revenue2020", label: "Obrót Netto 2020" },
  { value: "revenue2021", label: "Obrót Netto 2021" },
  { value: "revenue2022", label: "Obrót Netto 2022" },
  { value: "revenue2023", label: "Obrót Netto 2023" },
  { value: "revenue2024", label: "Obrót Netto 2024" },
  { value: "revenue2025", label: "Obrót Netto 2025" },
  { value: "totalRevenue", label: "Suma kontrahenta" },
  { value: "skip", label: "Pomiń kolumnę" }
];

export function ImportExcelModal({ open, onOpenChange }: ImportExcelModalProps) {
  const [file, setFile] = useState<File | null>(null);
  const [excelData, setExcelData] = useState<ExcelRow[]>([]);
  const [excelColumns, setExcelColumns] = useState<string[]>([]);
  const [columnMappings, setColumnMappings] = useState<ColumnMapping[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [step, setStep] = useState<'upload' | 'mapping' | 'preview'>('upload');
  const [previewData, setPreviewData] = useState<any[]>([]);
  const { toast } = useToast();

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      processExcelFile(selectedFile);
    }
  };

  const processExcelFile = async (file: File) => {
    try {
      setIsProcessing(true);
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);
      
      if (jsonData.length === 0) {
        toast({
          title: "Błąd",
          description: "Plik Excel jest pusty lub nie zawiera danych",
          variant: "destructive",
        });
        return;
      }

      setExcelData(jsonData as ExcelRow[]);
      const columns = Object.keys(jsonData[0] as ExcelRow);
      setExcelColumns(columns);
      
      // Initialize column mappings
      const mappings = columns.map(col => ({
        excelColumn: col,
        crmField: 'skip'
      }));
      setColumnMappings(mappings);
      setStep('mapping');

    } catch (error) {
      toast({
        title: "Błąd",
        description: "Nie można odczytać pliku Excel",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const updateColumnMapping = (excelColumn: string, crmField: string) => {
    setColumnMappings(prev => 
      prev.map(mapping => 
        mapping.excelColumn === excelColumn 
          ? { ...mapping, crmField }
          : mapping
      )
    );
  };

  const generatePreview = () => {
    const preview = excelData.slice(0, 5).map(row => {
      const mappedRow: any = {};
      columnMappings.forEach(mapping => {
        if (mapping.crmField !== 'skip') {
          mappedRow[mapping.crmField] = row[mapping.excelColumn];
        }
      });
      return mappedRow;
    });
    setPreviewData(preview);
    setStep('preview');
  };

  const handleImport = async () => {
    try {
      setIsProcessing(true);
      
      // Map all data
      const mappedData = excelData.map(row => {
        const mappedRow: any = {};
        columnMappings.forEach(mapping => {
          if (mapping.crmField !== 'skip') {
            mappedRow[mapping.crmField] = row[mapping.excelColumn];
          }
        });
        return mappedRow;
      }).filter(row => row.contractorName || row.email); // Filter out empty rows

      // Send to backend for import
      await apiRequest('POST', '/api/customers/import', { customers: mappedData });

      await queryClient.invalidateQueries({ queryKey: ['/api/customers'] });

      toast({
        title: "Sukces",
        description: `Zaimportowano ${mappedData.length} klientów`,
      });

      onOpenChange(false);
      resetModal();

    } catch (error: any) {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się zaimportować danych",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const resetModal = () => {
    setFile(null);
    setExcelData([]);
    setExcelColumns([]);
    setColumnMappings([]);
    setPreviewData([]);
    setStep('upload');
    setIsProcessing(false);
  };

  const handleClose = () => {
    onOpenChange(false);
    resetModal();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="w-[95vw] sm:w-full sm:max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5" />
            Import danych z Excel
          </DialogTitle>
        </DialogHeader>

        {step === 'upload' && (
          <div className="space-y-6">
            <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 text-center">
              <Upload className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Wybierz plik Excel</h3>
                <p className="text-sm text-gray-500">
                  Obsługiwane formaty: .xlsx, .xls
                </p>
                <div className="mt-4">
                  <input
                    type="file"
                    accept=".xlsx,.xls"
                    onChange={handleFileChange}
                    className="hidden"
                    id="excel-file"
                    disabled={isProcessing}
                  />
                  <label htmlFor="excel-file">
                    <Button 
                      variant="outline" 
                      disabled={isProcessing}
                      className="cursor-pointer"
                      asChild
                    >
                      <span>
                        {isProcessing ? "Przetwarzanie..." : "Wybierz plik"}
                      </span>
                    </Button>
                  </label>
                </div>
              </div>
            </div>

            {file && (
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-2">
                    <FileSpreadsheet className="h-4 w-4" />
                    <span className="font-medium">{file.name}</span>
                    <Badge variant="secondary">
                      {(file.size / 1024).toFixed(1)} KB
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {step === 'mapping' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium mb-2">Mapowanie kolumn</h3>
              <p className="text-sm text-gray-500 mb-4">
                Dopasuj kolumny z pliku Excel do pól w systemie CRM
              </p>
            </div>

            <div className="space-y-4">
              {columnMappings.map((mapping, index) => (
                <div key={index} className="flex items-center gap-4 p-3 border rounded-lg">
                  <div className="flex-1">
                    <Label className="text-sm font-medium">
                      {mapping.excelColumn}
                    </Label>
                    <p className="text-xs text-gray-500 mt-1">
                      Przykład: {excelData[0]?.[mapping.excelColumn] || 'Brak danych'}
                    </p>
                  </div>
                  <div className="flex-1">
                    <Select
                      value={mapping.crmField}
                      onValueChange={(value) => updateColumnMapping(mapping.excelColumn, value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Wybierz pole CRM" />
                      </SelectTrigger>
                      <SelectContent>
                        {CRM_FIELDS.map((field) => (
                          <SelectItem key={field.value} value={field.value}>
                            {field.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <Button onClick={() => setStep('upload')} variant="outline">
                Wstecz
              </Button>
              <Button onClick={generatePreview}>
                Podgląd danych
              </Button>
            </div>
          </div>
        )}

        {step === 'preview' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium mb-2">Podgląd importu</h3>
              <p className="text-sm text-gray-500 mb-4">
                Sprawdź dane przed importem (pokazano pierwsze 5 rekordów)
              </p>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm flex items-center gap-2">
                  <AlertCircle className="h-4 w-4" />
                  Podsumowanie
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-sm space-y-1">
                  <p>Całkowita liczba rekordów: <span className="font-medium">{excelData.length}</span></p>
                  <p>Rekordów z danymi: <span className="font-medium">
                    {excelData.filter(row => 
                      columnMappings.some(m => m.crmField === 'contractorName' && row[m.excelColumn]) ||
                      columnMappings.some(m => m.crmField === 'email' && row[m.excelColumn])
                    ).length}
                  </span></p>
                </div>
              </CardContent>
            </Card>

            <div className="border rounded-lg overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 dark:bg-gray-800">
                  <tr>
                    {Object.keys(previewData[0] || {}).map((key) => (
                      <th key={key} className="px-3 py-2 text-left font-medium">
                        {CRM_FIELDS.find(f => f.value === key)?.label || key}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {previewData.map((row, index) => (
                    <tr key={index} className="border-t">
                      {Object.values(row).map((value, i) => (
                        <td key={i} className="px-3 py-2">
                          {String(value || '')}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex gap-2">
              <Button onClick={() => setStep('mapping')} variant="outline">
                Wstecz
              </Button>
              <Button 
                onClick={handleImport} 
                disabled={isProcessing}
                className="flex items-center gap-2"
              >
                {isProcessing ? (
                  "Importowanie..."
                ) : (
                  <>
                    <Check className="h-4 w-4" />
                    Importuj dane
                  </>
                )}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}