import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin, ExternalLink, ChevronLeft, ChevronRight } from "lucide-react";
import type { Customer } from "@shared/schema";

type Prospect = {
  id?: string;
  contractorName?: string;
  streetAddress?: string;
  city?: string;
  phone?: string;
  email?: string;
  website?: string;
  businessStatus?: string;
  googleRating?: string;
  allegro?: string;
  enrichedAt?: string;
  googlePlaceId?: string;
};

interface GoogleMapsModalProps {
  isOpen: boolean;
  onClose: () => void;
  customer: Customer | null;
  prospect?: Prospect | null;
}

export default function GoogleMapsModal({ isOpen, onClose, customer, prospect }: GoogleMapsModalProps) {
  const [photos, setPhotos] = useState<string[]>([]);
  const [coords, setCoords] = useState<{lat: number, lng: number} | null>(null);
  const [settings, setSettings] = useState({maps_streetview_mode: "embed", maps_max_photos: 5});
  
  useEffect(() => {
    if (!isOpen) return;
    
    const data = customer || prospect;
    if (!data) return;
    
    async function fetchSettingsAndPhotos() {
      try {
        const settingsResponse = await fetch('/api/settings/maps');
        const settings = await settingsResponse.json();
        setSettings(settings);
        
        if (data?.googlePlaceId) {
          const photosResponse = await fetch(`/api/google-places/${data.googlePlaceId}/photos`);
          const { photos } = await photosResponse.json();
          setPhotos(photos);

          const coordsResponse = await fetch(`/api/google-maps/place-details-geometry?placeId=${data.googlePlaceId}`);
          const coordsData = await coordsResponse.json();
          setCoords(coordsData);
        } else {
          // Fallback: próbuj znaleźć współrzędne na podstawie adresu
          const address = `${data?.contractorName || ''} ${data?.streetAddress || ''} ${data?.city || ''}`.trim();
          if (address.length > 5) {
            try {
              const geocodeResponse = await fetch(`/api/google-maps/geocode?address=${encodeURIComponent(address)}`);
              const geocodeData = await geocodeResponse.json();
              if (geocodeData.lat && geocodeData.lng) {
                setCoords(geocodeData);
              }
            } catch (error) {
              console.error('Geocoding error:', error);
            }
          }
          
          // Nie dodawaj domyślnych zdjęć - pokaż tylko prawdziwe z Google Places API
          setPhotos([]);
        }
      } catch (error) {
        console.error('Error fetching photos and settings:', error);
      }
    }
    
    fetchSettingsAndPhotos();
  }, [isOpen, customer, prospect]);

  if (!customer && !prospect) return null;

  // Use customer data if available, otherwise use prospect data
  const data = customer || prospect;
  const title = data?.contractorName || "Firma";
  const address = `${data?.streetAddress || ''} ${data?.city || ''}`.trim();
  const enrichedAt = data?.enrichedAt;

  // Generate Google Maps link
  const getGoogleMapsLink = () => {
    const query = `${title} ${data?.city || ''} ${data?.streetAddress || ''}`.trim();
    return `https://www.google.com/maps/search/${encodeURIComponent(query)}`;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-[95vw] sm:w-full sm:max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-blue-600">
            <MapPin className="h-5 w-5" />
            Informacje Google Maps - {title}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Zdjęcia i Street View */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {photos.length > 0 && (
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-3 text-gray-900">Zdjęcia z Google Maps</h3>
                  <div className="grid grid-cols-2 gap-2">
                    {photos.map((photo, index) => (
                      <img
                        key={index}
                        src={photo}
                        alt={`Zdjęcie ${index + 1}`}
                        className="w-full h-32 object-cover rounded border"
                        loading="lazy"
                      />
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-3 text-gray-900">Street View</h3>
                {coords && coords.lat && coords.lng ? (
                  settings.maps_streetview_mode === "embed" ? (
                    <div className="flex items-center justify-center h-[300px] bg-gray-100 rounded-lg border">
                      <div className="text-center text-gray-500">
                        <MapPin className="h-12 w-12 mx-auto mb-2 text-gray-400" />
                        <p className="text-sm">Street View (Embed)</p>
                        <p className="text-xs text-gray-400 mt-1">
                          Współrzędne: {coords.lat.toFixed(6)}, {coords.lng.toFixed(6)}
                        </p>
                        <button 
                          onClick={() => window.open(`https://www.google.com/maps/@${coords.lat},${coords.lng},3a,75y,210h,90t/data=!3m6!1e1!3m4!1s0x0:0x0!2e0!7i16384!8i8192`, '_blank')}
                          className="mt-2 px-3 py-1 bg-blue-600 text-white text-xs rounded hover:bg-blue-700"
                        >
                          Otwórz w Google Maps
                        </button>
                      </div>
                    </div>
                  ) : (
                    <img
                      src={`/api/google-maps/streetview?location=${coords.lat},${coords.lng}&size=400x300`}
                      alt="Street View"
                      className="rounded-lg border w-full h-[300px] object-cover"
                      data-testid="streetview-image"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.style.display = 'none';
                        target.parentElement!.innerHTML = `
                          <div class="flex items-center justify-center h-[300px] bg-gray-100 rounded-lg border">
                            <div class="text-center text-gray-500">
                              <div class="h-12 w-12 mx-auto mb-2 text-gray-400">📍</div>
                              <p class="text-sm">Street View niedostępny</p>
                              <p class="text-xs text-gray-400 mt-1">Nie można załadować obrazu</p>
                            </div>
                          </div>
                        `;
                      }}
                    />
                  )
                ) : (
                  <div className="flex items-center justify-center h-[300px] bg-gray-100 rounded-lg border">
                    <div className="text-center text-gray-500">
                      <MapPin className="h-12 w-12 mx-auto mb-2 text-gray-400" />
                      <p className="text-sm">
                        {!coords ? 'Brak danych o lokalizacji' : 'Nieprawidłowe współrzędne'}
                      </p>
                      <p className="text-xs text-gray-400 mt-1">
                        Street View niedostępny
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Podstawowe informacje */}
          <Card>
            <CardContent className="p-4">
              <h3 className="font-semibold mb-3 text-gray-900">Podstawowe informacje</h3>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-gray-500" />
                  <span className="text-sm text-gray-700">{address || "Brak adresu"}</span>
                </div>
                {data?.website && (
                  <div className="flex items-center gap-2">
                    <ExternalLink className="h-4 w-4 text-gray-500" />
                    <a 
                      href={data.website} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-sm text-blue-600 hover:underline"
                    >
                      {data.website}
                    </a>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Status firmy */}
          <Card>
            <CardContent className="p-4">
              <h3 className="font-semibold mb-3 text-gray-900">Status firmy</h3>
              <div className="space-y-2">
                {data?.businessStatus && (
                  <div className="text-sm">
                    <span className="font-medium">Status: </span>
                    <span className={`${
                      data.businessStatus === 'OPERATIONAL' 
                        ? 'text-green-600' 
                        : 'text-red-600'
                    }`}>
                      {data.businessStatus === 'OPERATIONAL' ? 'Czynne' : data.businessStatus}
                    </span>
                  </div>
                )}
                {data?.googleRating && (
                  <div className="text-sm">
                    <span className="font-medium">Ocena Google: </span>
                    <span className="text-yellow-600">{data.googleRating}/5</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Dodatkowe usługi */}
          <Card>
            <CardContent className="p-4">
              <h3 className="font-semibold mb-3 text-gray-900">Dodatkowe usługi</h3>
              <div className="space-y-2">
                {data?.allegro && (
                  <div className="text-sm">
                    <span className="font-medium">Sklep Allegro: </span>
                    <a 
                      href={data.allegro} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline"
                    >
                      {data.allegro}
                    </a>
                  </div>
                )}
                {data?.website && (
                  <div className="text-sm">
                    <span className="font-medium">Strona internetowa: </span>
                    <a 
                      href={data.website} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline"
                    >
                      {data.website}
                    </a>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <Button 
              onClick={() => window.open(getGoogleMapsLink(), '_blank')} 
              className="flex-1 flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700"
              data-testid="button-open-google-maps"
            >
              <MapPin className="h-4 w-4" />
              Otwórz w Google Maps
            </Button>
            
            {enrichedAt && (
              <div className="text-xs text-gray-500 self-center text-center sm:text-right">
                Ostatnie wzbogacenie: {new Date(enrichedAt).toLocaleDateString('pl-PL')}
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}