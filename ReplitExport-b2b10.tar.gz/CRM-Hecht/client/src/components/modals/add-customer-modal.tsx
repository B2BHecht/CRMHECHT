import React, { useState, useEffect } from "react";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { insertCustomerSchema, type InsertCustomer, type FieldDefinition } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Funkcja formatowania kwot w złotych
const formatCurrency = (value: string | number): string => {
  const numValue = typeof value === 'string' ? parseFloat(value) || 0 : value;
  return new Intl.NumberFormat('pl-PL', {
    style: 'currency',
    currency: 'PLN'
  }).format(numValue);
};

interface AddCustomerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AddCustomerModal({ isOpen, onClose }: AddCustomerModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Pobierz definicje pól dla klientów
  const { data: fieldDefinitions = [] } = useQuery<FieldDefinition[]>({
    queryKey: ['/api/field-definitions'],
    select: (data) => data.filter(field => field.entityType === 'customers' && field.isActive === 1)
  });

  const form = useForm<InsertCustomer>({
    resolver: zodResolver(insertCustomerSchema),
    defaultValues: {
      groupName: "",
      contractorName: "",
      nip: "",
      city: "",
      code: "",
      streetAddress: "",
      contract: "",
      classification: "",
      salesperson: "",
      email: "",
      phone: "",
      revenue2020: "0",
      revenue2021: "0",
      revenue2022: "0",
      revenue2023: "0",
      revenue2024: "0",
      revenue2025: "0",
      totalRevenue: "0",
    },
  });

  // Automatyczne obliczanie sumy kontrahenta
  useEffect(() => {
    const watchFields = ['revenue2021', 'revenue2022', 'revenue2023', 'revenue2024', 'revenue2025'] as const;
    const subscription = form.watch((value, { name }) => {
      if (name && watchFields.includes(name as any)) {
        const sum = watchFields.reduce((total, field) => {
          const fieldValue = parseFloat(value[field] || '0') || 0;
          return total + fieldValue;
        }, 0);
        
        form.setValue('totalRevenue', sum.toString());
      }
    });
    
    return () => subscription.unsubscribe();
  }, [form]);

  const createCustomerMutation = useMutation({
    mutationFn: async (data: InsertCustomer) => {
      const response = await apiRequest("POST", "/api/customers", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/customers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/metrics"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      toast({
        title: "Sukces",
        description: "Klient został pomyślnie dodany",
      });
      form.reset();
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się dodać klienta",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertCustomer) => {
    createCustomerMutation.mutate(data);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-[95vw] sm:w-full sm:max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="modal-add-customer">
        <DialogHeader>
          <DialogTitle data-testid="modal-title">Dodaj Nowego Klienta</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 max-h-[70vh] overflow-y-auto">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="contractorName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nazwa kontrahenta *</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Wprowadź nazwę kontrahenta" 
                        {...field}
                        value={field.value || ""} 
                        data-testid="input-contractor-name"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="groupName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nazwa grupy</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Wprowadź nazwę grupy" 
                        {...field}
                        value={field.value || ""} 
                        data-testid="input-group-name"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="nip"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>NIP</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Wprowadź NIP" 
                        {...field}
                        value={field.value || ""} 
                        data-testid="input-nip"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="code"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Kod pocztowy</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Wprowadź kod pocztowy" 
                        {...field}
                        value={field.value || ""} 
                        data-testid="input-postal-code"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="city"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Miasto</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Wprowadź miasto" 
                        {...field}
                        value={field.value || ""} 
                        data-testid="input-city"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="streetAddress"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Ulica, nr lokalu</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Wprowadź adres" 
                        {...field}
                        value={field.value || ""} 
                        data-testid="input-street-address"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="contract"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Umowa</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Numer umowy" 
                        {...field}
                        value={field.value || ""} 
                        data-testid="input-contract"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="classification"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nazwa klasyfikacji</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Klasyfikacja" 
                        {...field}
                        value={field.value || ""} 
                        data-testid="input-classification"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="salesperson"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Handlowiec</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Przypisany handlowiec" 
                        {...field}
                        value={field.value || ""} 
                        data-testid="input-salesperson"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>E-mail kontrahenta</FormLabel>
                    <FormControl>
                      <Input 
                        type="email" 
                        placeholder="adres@email.com" 
                        {...field}
                        value={field.value || ""} 
                        data-testid="input-email"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nr telefonu</FormLabel>
                    <FormControl>
                      <Input 
                        type="tel" 
                        placeholder="+48 123 456 789" 
                        {...field}
                        value={field.value || ""} 
                        data-testid="input-phone"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="space-y-4">
              <h4 className="text-sm font-medium">Obroty roczne (zł)</h4>
              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="revenue2020"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>2020</FormLabel>
                      <FormControl>
                        <Input 
                          type="number"
                          placeholder="0"
                          {...field}
                        value={field.value || ""} 
                          data-testid="input-revenue-2020"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="revenue2021"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>2021</FormLabel>
                      <FormControl>
                        <Input 
                          type="number"
                          placeholder="0"
                          {...field}
                        value={field.value || ""} 
                          data-testid="input-revenue-2021"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="revenue2022"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>2022</FormLabel>
                      <FormControl>
                        <Input 
                          type="number"
                          placeholder="0"
                          {...field}
                        value={field.value || ""} 
                          data-testid="input-revenue-2022"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="revenue2023"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>2023</FormLabel>
                      <FormControl>
                        <Input 
                          type="number"
                          placeholder="0"
                          {...field}
                        value={field.value || ""} 
                          data-testid="input-revenue-2023"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="revenue2024"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>2024</FormLabel>
                      <FormControl>
                        <Input 
                          type="number"
                          placeholder="0"
                          {...field}
                        value={field.value || ""} 
                          data-testid="input-revenue-2024"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="revenue2025"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>2025</FormLabel>
                      <FormControl>
                        <Input 
                          type="number"
                          placeholder="0"
                          {...field}
                        value={field.value || ""} 
                          data-testid="input-revenue-2025"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              {/* Pole sumy kontrahenta - tylko do odczytu */}
              <div className="pt-4 border-t">
                <FormField
                  control={form.control}
                  name="totalRevenue"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Suma kontrahenta (automatycznie obliczona)</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Input 
                            {...field}
                        value={field.value || ""} 
                            readOnly
                            className="bg-muted font-semibold text-lg"
                            placeholder="0 zł"
                            data-testid="input-total-revenue"
                          />
                          <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-sm text-muted-foreground">
                            {formatCurrency(field.value || "0")}
                          </div>
                        </div>
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
            </div>

            {/* Dynamiczne pola */}
            {fieldDefinitions.filter(field => field.isDefault === 0).length > 0 && (
              <div className="space-y-4">
                <h4 className="text-sm font-medium border-t pt-4">Dodatkowe pola</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {fieldDefinitions
                    .filter(field => field.isDefault === 0)
                    .sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0))
                    .map((field) => (
                      <DynamicFieldComponent
                        key={field.id}
                        field={field}
                        form={form}
                      />
                    ))}
                </div>
              </div>
            )}

            <div className="flex space-x-3 pt-4">
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose} 
                className="flex-1"
                data-testid="button-cancel"
              >
                Anuluj
              </Button>
              <Button 
                type="submit" 
                className="flex-1" 
                disabled={createCustomerMutation.isPending}
                data-testid="button-submit"
              >
                {createCustomerMutation.isPending ? "Dodawanie..." : "Dodaj Klienta"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

// Komponent do renderowania dynamicznych pól
function DynamicFieldComponent({ 
  field, 
  form 
}: { 
  field: FieldDefinition; 
  form: any; 
}) {
  const fieldName = field.fieldKey as string;

  // Renderuj pole w zależności od typu
  const renderFieldControl = () => {
    switch (field.fieldType) {
      case 'text':
        return (
          <Input 
            placeholder={`Wprowadź ${field.fieldLabel.toLowerCase()}`}
            data-testid={`input-${field.fieldKey}`}
          />
        );
      
      case 'number':
        return (
          <Input 
            type="number"
            placeholder="0"
            data-testid={`input-${field.fieldKey}`}
          />
        );
      
      case 'email':
        return (
          <Input 
            type="email"
            placeholder="adres@email.com"
            data-testid={`input-${field.fieldKey}`}
          />
        );
      
      case 'phone':
        return (
          <Input 
            type="tel"
            placeholder="+48 123 456 789"
            data-testid={`input-${field.fieldKey}`}
          />
        );
      
      case 'date':
        return (
          <Input 
            type="date"
            data-testid={`input-${field.fieldKey}`}
          />
        );
      
      case 'list':
        return (
          <Select>
            <SelectTrigger data-testid={`select-${field.fieldKey}`}>
              <SelectValue placeholder={`Wybierz ${field.fieldLabel.toLowerCase()}`} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="opcja1">Opcja 1</SelectItem>
              <SelectItem value="opcja2">Opcja 2</SelectItem>
              <SelectItem value="opcja3">Opcja 3</SelectItem>
            </SelectContent>
          </Select>
        );
      
      default:
        return (
          <Input 
            placeholder={`Wprowadź ${field.fieldLabel.toLowerCase()}`}
            data-testid={`input-${field.fieldKey}`}
          />
        );
    }
  };

  return (
    <FormField
      control={form.control}
      name={fieldName}
      render={({ field: formField }) => (
        <FormItem>
          <FormLabel>
            {field.fieldLabel}
            {field.isRequired === 1 && ' *'}
          </FormLabel>
          <FormControl>
            {React.cloneElement(renderFieldControl(), {
              ...formField,
              value: formField.value || '',
              onChange: (e: any) => {
                const value = field.fieldType === 'list' ? e : e.target.value;
                formField.onChange(value);
              }
            })}
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );
}
