import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sparkles, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface EnrichProspectModalProps {
  isOpen: boolean;
  onClose: () => void;
  prospectId: string | null;
}

export default function EnrichProspectModal({
  isOpen,
  onClose,
  prospectId,
}: EnrichProspectModalProps) {
  const [companyName, setCompanyName] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const enrichMutation = useMutation({
    mutationFn: async (data: { prospectId: string; companyName: string }) => {
      return apiRequest(`/api/prospects/${data.prospectId}/enrich`, "POST", { 
        companyName: data.companyName 
      });
    },
    onSuccess: () => {
      toast({
        title: "Sukces",
        description: "Dane zostały wzbogacone pomyślnie",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/prospects"] });
      onClose();
      setCompanyName("");
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error.message || "Wystąpił błąd podczas wzbogacania danych",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prospectId || !companyName.trim()) return;

    enrichMutation.mutate({
      prospectId,
      companyName: companyName.trim(),
    });
  };

  const handleClose = () => {
    if (!enrichMutation.isPending) {
      setCompanyName("");
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[500px]" data-testid="enrich-prospect-modal">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5" />
            Wzbogać dane potencjalnego klienta
          </DialogTitle>
          <DialogDescription>
            Wprowadź nazwę firmy aby automatycznie uzupełnić brakujące informacje
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="companyName">Nazwa firmy</Label>
            <Input
              id="companyName"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              placeholder="Wprowadź nazwę firmy..."
              disabled={enrichMutation.isPending}
              data-testid="input-company-name"
              required
            />
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={enrichMutation.isPending}
              data-testid="button-cancel"
            >
              Anuluj
            </Button>
            <Button
              type="submit"
              disabled={enrichMutation.isPending || !companyName.trim()}
              data-testid="button-enrich"
            >
              {enrichMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Wzbogać dane
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}