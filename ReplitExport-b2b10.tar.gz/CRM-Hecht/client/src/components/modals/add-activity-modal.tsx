import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { insertActivitySchema, type InsertActivity, type Customer, type Prospect } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useCurrentUser } from "@/hooks/use-current-user";

interface AddActivityModalProps {
  isOpen: boolean;
  onClose: () => void;
  prospectId?: string;
  customerId?: string;
}

const activityTypeOptions = [
  { value: "phone", label: "Telefon", icon: "📞" },
  { value: "email", label: "Email", icon: "✉️" },
  { value: "meeting", label: "Spotkanie", icon: "🤝" },
  { value: "order", label: "Zamówienie", icon: "📋" },
];

export default function AddActivityModal({ isOpen, onClose, prospectId, customerId }: AddActivityModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useCurrentUser();

  const { data: customers } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
    enabled: !customerId && !prospectId, // Tylko pobierz jeśli nie mamy customerId ani prospectId
  });

  const { data: prospects } = useQuery<Prospect[]>({
    queryKey: ["/api/prospects"],
    enabled: !customerId && !prospectId, // Tylko pobierz jeśli nie mamy customerId ani prospectId
  });

  const form = useForm<InsertActivity>({
    resolver: zodResolver(insertActivitySchema.extend({
      orderValue: insertActivitySchema.shape.orderValue?.optional(),
    })),
    defaultValues: {
      customerId: customerId || null,
      prospectId: prospectId || null,
      type: "phone",
      description: "",
      salesperson: `${user.firstName} ${user.lastName}`,
    },
  });

  const selectedType = form.watch("type");

  const createActivityMutation = useMutation({
    mutationFn: async (data: InsertActivity) => {
      const response = await apiRequest("POST", "/api/activities", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      queryClient.invalidateQueries({ queryKey: ["/api/prospects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/metrics"] });
      toast({
        title: "Sukces",
        description: "Aktywność została pomyślnie dodana",
      });
      form.reset();
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się dodać aktywności",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (data: InsertActivity) => {
    // Automatycznie dodaj handlowca i datę
    const activityData = {
      ...data,
      salesperson: `${user.firstName} ${user.lastName}`,
      // Nie dodawaj activityDate - będzie ustawiona automatycznie przez serwer
    };
    
    createActivityMutation.mutate(activityData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]" data-testid="add-activity-modal">
        <DialogHeader>
          <DialogTitle>Dodaj Aktywność</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            {!customerId && !prospectId && (
              <>
                <FormField
                  control={form.control}
                  name="customerId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Klient</FormLabel>
                      <Select onValueChange={(value) => {
                        field.onChange(value);
                        form.setValue("prospectId", null);
                      }} defaultValue={field.value || ""}>
                        <FormControl>
                          <SelectTrigger data-testid="select-customer">
                            <SelectValue placeholder="Wybierz klienta" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {customers?.map((customer) => (
                            <SelectItem key={customer.id} value={customer.id}>
                              {customer.contractorName}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="prospectId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Potencjalny Klient</FormLabel>
                      <Select onValueChange={(value) => {
                        field.onChange(value);
                        form.setValue("customerId", null);
                      }} defaultValue={field.value || ""}>
                        <FormControl>
                          <SelectTrigger data-testid="select-prospect">
                            <SelectValue placeholder="Wybierz potencjalnego klienta" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {prospects?.map((prospect) => (
                            <SelectItem key={prospect.id} value={prospect.id}>
                              {prospect.contractorName}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </>
            )}

            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Typ Aktywności</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-activity-type">
                        <SelectValue placeholder="Wybierz typ aktywności" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {activityTypeOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.icon} {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {selectedType === "order" && (
              <FormField
                control={form.control}
                name="orderValue"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Wartość Zamówienia (zł)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        step="0.01"
                        placeholder="Wprowadź wartość zamówienia" 
                        value={field.value || ""} 
                        onChange={(e) => field.onChange(e.target.value)}
                        data-testid="input-order-value"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Opis</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Opisz aktywność..." 
                      {...field} 
                      data-testid="textarea-description"
                      rows={3}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="bg-muted/50 rounded-lg p-3">
              <p className="text-sm text-muted-foreground">
                <strong>Handlowiec:</strong> {user.firstName} {user.lastName}<br/>
                <strong>Data:</strong> {new Date().toLocaleDateString('pl-PL')} {new Date().toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' })}
              </p>
              {selectedType === "order" && (
                <p className="text-sm text-orange-600 font-medium mt-2">
                  ⚠️ Dodanie zamówienia automatycznie zmieni etap na "Wygrany"
                </p>
              )}
            </div>

            <div className="flex space-x-3 pt-4">
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose} 
                className="flex-1"
                data-testid="button-cancel"
              >
                Anuluj
              </Button>
              <Button 
                type="submit"
                disabled={createActivityMutation.isPending}
                className="flex-1"
                data-testid="button-submit"
              >
                {createActivityMutation.isPending ? "Dodaję..." : "Dodaj Aktywność"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}