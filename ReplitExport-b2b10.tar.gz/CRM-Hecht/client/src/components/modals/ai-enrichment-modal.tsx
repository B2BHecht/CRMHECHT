import { useState, useEffect } from "react";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Brain, Loader2, ExternalLink, ZoomIn, ChevronLeft, ChevronRight } from "lucide-react";

interface AIEnrichmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  prospectId: string;
  prospectName: string;
  currentNotes?: string;
}

export function AIEnrichmentModal({
  isOpen,
  onClose,
  prospectId,
  prospectName,
  currentNotes
}: AIEnrichmentModalProps) {
  const [customPrompt, setCustomPrompt] = useState("");
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [showImageViewer, setShowImageViewer] = useState(false);
  const [realPhotos, setRealPhotos] = useState<string[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Pobierz prospect data żeby mieć googlePlaceId
  const prospectQuery = useQuery({
    queryKey: [`/api/prospects/${prospectId}`],
    enabled: isOpen
  });

  const prospect = prospectQuery.data as { googlePlaceId?: string } | undefined;

  // Pobierz prawdziwe zdjęcia z Google Places API
  const photosQuery = useQuery({
    queryKey: [`/api/google-places/${prospect?.googlePlaceId}/photos`],
    enabled: !!prospect?.googlePlaceId,
    staleTime: 1000 * 60 * 60, // Cache for 1 hour
  });

  // Update real photos when query resolves
  useEffect(() => {
    const photos = photosQuery.data as { photos?: string[] };
    if (photos?.photos) {
      setRealPhotos(photos.photos);
    }
  }, [photosQuery.data]);

  // Parsowanie danych AI z notes
  const parseAIData = () => {
    if (!currentNotes) return null;
    try {
      // Sprawdź czy to JSON
      if (currentNotes.startsWith('{')) {
        return JSON.parse(currentNotes);
      }
      return null;
    } catch {
      return null;
    }
  };

  const aiData = parseAIData();

  const enrichMutation = useMutation({
    mutationFn: async (prompt?: string) => {
      return apiRequest("POST", `/api/prospects/${prospectId}/ai-enrich`, {
        customPrompt: prompt
      });
    },
    onSuccess: () => {
      toast({
        title: "Sukces",
        description: "Dane zostały wzbogacone przez AI",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/prospects"] });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error.message || "Wystąpił błąd podczas wzbogacania danych",
        variant: "destructive",
      });
    },
  });

  const handleEnrich = () => {
    enrichMutation.mutate(customPrompt || undefined);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            Wzbogacanie AI - {prospectName}
          </DialogTitle>
          <DialogDescription>
            Wyświetl aktualne informacje z AI lub zadaj dodatkowe pytanie
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Aktualne informacje AI */}
          <div>
            <h4 className="font-medium mb-2">Aktualne informacje z AI:</h4>
            
            {aiData ? (
              <div className="space-y-4">
                {/* Podstawowe informacje */}
                <div className="grid grid-cols-2 gap-2">
                  {aiData.hasGardenEquipment && (
                    <Badge variant="secondary" className="justify-start">
                      🌿 Sprzęt ogrodniczy
                    </Badge>
                  )}
                  {aiData.hasOnlineStore && (
                    <Badge variant="secondary" className="justify-start">
                      🛒 Sklep online
                    </Badge>
                  )}
                  {aiData.allegroStore && (
                    <Badge variant="secondary" className="justify-start">
                      🏪 Allegro
                    </Badge>
                  )}
                  {aiData.facebookUrl && (
                    <Badge variant="secondary" className="justify-start">
                      📘 Facebook
                    </Badge>
                  )}
                  {aiData.foundedYear && (
                    <Badge variant="secondary" className="justify-start">
                      📅 {aiData.foundedYear}
                    </Badge>
                  )}
                  {aiData.storeArea && (
                    <Badge variant="secondary" className="justify-start">
                      📏 {aiData.storeArea}
                    </Badge>
                  )}
                  {aiData.salesPotential && (
                    <Badge variant="secondary" className="justify-start">
                      💰 {aiData.salesPotential}
                    </Badge>
                  )}
                </div>

                {/* Opis działalności */}
                {aiData.businessDescription && (
                  <div>
                    <h5 className="text-sm font-medium mb-1">Opis działalności:</h5>
                    <p className="text-sm text-muted-foreground">{aiData.businessDescription}</p>
                  </div>
                )}

                {/* Zdjęcia Google Maps - używaj prawdziwych zdjęć z Google Places API */}
                {realPhotos.length > 0 ? (
                  <div>
                    <h5 className="text-sm font-medium mb-2">Zdjęcia lokalu ({realPhotos.length}):</h5>
                    <div className="grid grid-cols-3 gap-2">
                      {realPhotos.map((photo: string, index: number) => (
                        <div key={index} className="relative group cursor-pointer">
                          <img
                            src={photo}
                            alt={`Zdjęcie ${index + 1}`}
                            className="w-full h-20 object-cover rounded border"
                            onClick={() => {
                              setSelectedImageIndex(index);
                              setShowImageViewer(true);
                            }}
                          />
                          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity rounded flex items-center justify-center">
                            <ZoomIn className="h-4 w-4 text-white" />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : photosQuery.isLoading ? (
                  <div className="flex items-center space-x-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span className="text-sm">Ładowanie zdjęć...</span>
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">Brak dostępnych zdjęć.</p>
                )}

                {/* Google Street View */}
                {aiData.streetViewUrl && (
                  <div>
                    <h5 className="text-sm font-medium mb-2">Street View:</h5>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => window.open(aiData.streetViewUrl, '_blank')}
                      className="w-full"
                    >
                      <ExternalLink className="mr-2 h-4 w-4" />
                      Otwórz Google Street View
                    </Button>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-3 bg-muted rounded-lg text-sm">
                {currentNotes ? (
                  <pre className="whitespace-pre-wrap">{currentNotes}</pre>
                ) : (
                  <span className="text-muted-foreground">Brak danych AI</span>
                )}
              </div>
            )}</div>

          {/* Pole na dodatkowy prompt */}
          <div>
            <h4 className="font-medium mb-2">Zadaj dodatkowe pytanie (opcjonalnie):</h4>
            <Textarea
              placeholder="Np. Sprawdź zdjęcia lokalu, powierzchnię sklepu i potencjał sprzedażowy dla firmy Hecht Polska"
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              rows={3}
              data-testid="textarea-custom-prompt"
            />
            <p className="text-xs text-muted-foreground mt-1">
              Możesz zapytać o zdjęcia lokalu, powierzchnię, potencjał sprzedażowy itp.
            </p>
          </div>

          {/* Przyciski akcji */}
          <div className="flex gap-2 pt-4">
            <Button
              onClick={handleEnrich}
              disabled={enrichMutation.isPending}
              className="flex-1"
              data-testid="button-enrich-ai"
            >
              {enrichMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Wzbogacam...
                </>
              ) : (
                <>
                  <Brain className="mr-2 h-4 w-4" />
                  {customPrompt ? "Zadaj pytanie AI" : "Odśwież dane AI"}
                </>
              )}
            </Button>
            <Button variant="outline" onClick={onClose} data-testid="button-cancel">
              Anuluj
            </Button>
          </div>
        </div>

        {/* Modal podglądu zdjęć */}
        {/* Modal podglądu zdjęć - używaj prawdziwych zdjęć */}
        {showImageViewer && realPhotos.length > 0 && (
          <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center">
            <div className="relative max-w-4xl max-h-[90vh] w-full h-full flex items-center justify-center p-4">
              {/* Przycisk zamknięcia */}
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-4 right-4 text-white hover:bg-white/20"
                onClick={() => setShowImageViewer(false)}
              >
                ✕
              </Button>

              {/* Nawigacja lewo */}
              {selectedImageIndex > 0 && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute left-4 text-white hover:bg-white/20"
                  onClick={() => setSelectedImageIndex(selectedImageIndex - 1)}
                >
                  <ChevronLeft className="h-6 w-6" />
                </Button>
              )}

              {/* Zdjęcie */}
              <img
                src={realPhotos[selectedImageIndex]}
                alt={`Zdjęcie ${selectedImageIndex + 1}`}
                className="max-w-full max-h-full object-contain"
              />

              {/* Nawigacja prawo */}
              {selectedImageIndex < realPhotos.length - 1 && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-4 text-white hover:bg-white/20"
                  onClick={() => setSelectedImageIndex(selectedImageIndex + 1)}
                >
                  <ChevronRight className="h-6 w-6" />
                </Button>
              )}

              {/* Licznik zdjęć */}
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black/50 text-white px-3 py-1 rounded">
                {selectedImageIndex + 1} / {realPhotos.length}
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}