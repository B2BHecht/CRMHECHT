import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { MapPin, Settings, Save } from "lucide-react";

interface MapsSettingsPageProps {
  user: any;
}

export default function MapsSettingsPage({ user }: MapsSettingsPageProps) {
  const [apiKey, setApiKey] = useState("");
  const [enrichmentPrompt, setEnrichmentPrompt] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    // Load saved settings from localStorage
    const savedApiKey = localStorage.getItem("google_maps_api_key") || "";
    const savedPrompt = localStorage.getItem("ai_enrichment_prompt") || "";
    
    setApiKey(savedApiKey);
    setEnrichmentPrompt(savedPrompt);
  }, []);

  const handleSaveSettings = () => {
    try {
      localStorage.setItem("google_maps_api_key", apiKey);
      localStorage.setItem("ai_enrichment_prompt", enrichmentPrompt);
      
      toast({
        title: "Ustawienia zapisane",
        description: "Ustawienia Maps i Street View zostały pomyślnie zapisane.",
      });
    } catch (error) {
      toast({
        title: "Błąd",
        description: "Nie udało się zapisać ustawień. Spróbuj ponownie.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Ustawienia Google Maps
          </CardTitle>
          <CardDescription>
            Skonfiguruj integrację z Google Maps API dla funkcji mapowania i Street View
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="google-api-key">Klucz API Google Maps</Label>
            <Input
              id="google-api-key"
              type="password"
              placeholder="Wprowadź klucz API Google Maps"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              data-testid="input-google-api-key"
            />
            <p className="text-sm text-muted-foreground">
              Klucz API jest wymagany do korzystania z funkcji Google Maps i Street View
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Prompt wzbogacania AI
          </CardTitle>
          <CardDescription>
            Skonfiguruj instrukcje dla AI do automatycznego wzbogacania danych firm
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="enrichment-prompt">Prompt wzbogacania</Label>
            <Textarea
              id="enrichment-prompt"
              placeholder="Wprowadź instrukcje dla AI dotyczące wzbogacania danych..."
              value={enrichmentPrompt}
              onChange={(e) => setEnrichmentPrompt(e.target.value)}
              className="min-h-[150px]"
              data-testid="textarea-enrichment-prompt"
            />
            <p className="text-sm text-muted-foreground">
              Te instrukcje będą używane przez AI do automatycznego wzbogacania informacji o firmach
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={handleSaveSettings} className="flex items-center gap-2" data-testid="button-save-settings">
          <Save className="h-4 w-4" />
          Zapisz ustawienia
        </Button>
      </div>
    </div>
  );
}