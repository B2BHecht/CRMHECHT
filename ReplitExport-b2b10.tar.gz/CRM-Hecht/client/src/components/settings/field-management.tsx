import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit2, Trash2, GripVertical } from "lucide-react";
import type { FieldDefinition, InsertFieldDefinition } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import {
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

export default function FieldManagement() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingField, setEditingField] = useState<FieldDefinition | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedEntityType, setSelectedEntityType] = useState<string>('customers');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch field definitions
  const { data: fieldDefinitions = [], isLoading } = useQuery<FieldDefinition[]>({
    queryKey: ['/api/field-definitions'],
  });

  // Add field mutation
  const addFieldMutation = useMutation({
    mutationFn: (data: InsertFieldDefinition) => 
      apiRequest('POST', '/api/field-definitions', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/field-definitions'] });
      setIsAddModalOpen(false);
      toast({
        title: "Sukces",
        description: "Pole zostało dodane pomyślnie",
      });
    },
    onError: () => {
      toast({
        title: "Błąd",
        description: "Nie udało się dodać pola",
        variant: "destructive",
      });
    },
  });

  // Update field mutation
  const updateFieldMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertFieldDefinition> }) =>
      apiRequest('PATCH', `/api/field-definitions/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/field-definitions'] });
      setIsEditModalOpen(false);
      setEditingField(null);
      toast({
        title: "Sukces",
        description: "Pole zostało zaktualizowane pomyślnie",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się zaktualizować pola",
        variant: "destructive",
      });
    },
  });

  // Delete field mutation
  const deleteFieldMutation = useMutation({
    mutationFn: (id: string) => 
      apiRequest('DELETE', `/api/field-definitions/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/field-definitions'] });
      toast({
        title: "Sukces",
        description: "Pole zostało usunięte pomyślnie",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się usunąć pola",
        variant: "destructive",
      });
    },
  });

  // Reorder fields mutation
  const reorderFieldsMutation = useMutation({
    mutationFn: (fields: Array<{ id: string; displayOrder: number }>) =>
      apiRequest('PUT', '/api/field-definitions/reorder', { fields }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/field-definitions'] });
      toast({
        title: "Sukces",
        description: "Kolejność pól została zaktualizowana",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się zaktualizować kolejności pól",
        variant: "destructive",
      });
    },
  });

  // Drag and drop sensors
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  // Filter and sort fields for current entity type
  const sortedFields = fieldDefinitions
    .filter((field: FieldDefinition) => field.entityType === selectedEntityType)
    .sort((a: FieldDefinition, b: FieldDefinition) => (a.displayOrder || 0) - (b.displayOrder || 0));

  function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event;

    if (active.id !== over?.id) {
      const oldIndex = sortedFields.findIndex(field => field.id === active.id);
      const newIndex = sortedFields.findIndex(field => field.id === over?.id);
      
      const reorderedFields = arrayMove(sortedFields, oldIndex, newIndex);
      
      // Create update data with new display orders
      const updates = reorderedFields.map((field, index) => ({
        id: field.id,
        displayOrder: index + 1
      }));
      
      reorderFieldsMutation.mutate(updates);
    }
  }


  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div>Ładowanie pól...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Zarządzanie Polami</CardTitle>
              <CardDescription>
                Zarządzaj polami danych - edytuj nazwy i dodawaj nowe pola
              </CardDescription>
            </div>
            
            <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
              <DialogTrigger asChild>
                <Button data-testid="button-add-field">
                  <Plus className="h-4 w-4 mr-2" />
                  Dodaj Pole
                </Button>
              </DialogTrigger>
              <AddFieldModal 
                onClose={() => setIsAddModalOpen(false)}
                onSubmit={(data) => addFieldMutation.mutate(data)}
                isLoading={addFieldMutation.isPending}
              />
            </Dialog>
          </div>
          
          {/* Filtr typu encji */}
          <div className="flex items-center space-x-2 mt-4">
            <Label htmlFor="entity-filter">Pokaż pola dla:</Label>
            <Select value={selectedEntityType} onValueChange={setSelectedEntityType}>
              <SelectTrigger className="w-48" data-testid="select-entity-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="customers">Klienci</SelectItem>
                <SelectItem value="deals">Potencjalni Klienci</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <DndContext 
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragEnd={handleDragEnd}
            >
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-8"></TableHead>
                    <TableHead className="w-20">Kolejność</TableHead>
                    <TableHead className="min-w-32">Nazwa</TableHead>
                    <TableHead className="min-w-24">Klucz</TableHead>
                    <TableHead className="w-20">Typ</TableHead>
                    <TableHead className="w-20">Wymagane</TableHead>
                    <TableHead className="w-24">Status</TableHead>
                    <TableHead className="w-20">Typ pola</TableHead>
                    <TableHead className="w-24">Akcje</TableHead>
                  </TableRow>
                </TableHeader>
                <SortableContext 
                  items={sortedFields.map(field => field.id)}
                  strategy={verticalListSortingStrategy}
                >
                  <TableBody>
                    {sortedFields.map((field: FieldDefinition, index: number) => (
                      <SortableTableRow
                        key={field.id}
                        field={field}
                        index={index}
                        onEdit={handleEdit}
                        onDelete={handleDelete}
                      />
                    ))}
                  </TableBody>
                </SortableContext>
              </Table>
            </DndContext>
          </div>
        </CardContent>
      </Card>

      {/* Edit Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        {editingField && (
          <EditFieldModal 
            field={editingField}
            onClose={() => {
              setIsEditModalOpen(false);
              setEditingField(null);
            }}
            onSubmit={(data) => updateFieldMutation.mutate({ 
              id: editingField.id, 
              data 
            })}
            isLoading={updateFieldMutation.isPending}
          />
        )}
      </Dialog>
    </div>
  );

  function handleEdit(field: FieldDefinition) {
    setEditingField(field);
    setIsEditModalOpen(true);
  }

  function handleDelete(field: FieldDefinition) {
    if (field.isDefault === 1) {
      toast({
        title: "Błąd",
        description: "Nie można usuwać domyślnych pól",
        variant: "destructive",
      });
      return;
    }

    if (window.confirm(`Czy na pewno chcesz usunąć pole "${field.fieldLabel}"?`)) {
      deleteFieldMutation.mutate(field.id);
    }
  }
}

// Sortable Table Row Component
function SortableTableRow({ 
  field, 
  index, 
  onEdit, 
  onDelete 
}: { 
  field: FieldDefinition; 
  index: number;
  onEdit: (field: FieldDefinition) => void;
  onDelete: (field: FieldDefinition) => void;
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: field.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <TableRow 
      ref={setNodeRef} 
      style={style}
      className={isDragging ? "bg-muted/50" : ""}
    >
      <TableCell>
        <div
          {...attributes}
          {...listeners}
          className="cursor-grab active:cursor-grabbing p-1 hover:bg-muted rounded"
          data-testid={`drag-handle-${field.id}`}
        >
          <GripVertical className="h-4 w-4 text-muted-foreground" />
        </div>
      </TableCell>
      <TableCell data-testid={`text-order-${field.id}`}>
        {index + 1}
      </TableCell>
      <TableCell data-testid={`text-label-${field.id}`}>
        <span className="font-medium">{field.fieldLabel}</span>
      </TableCell>
      <TableCell data-testid={`text-key-${field.id}`}>
        <code className="bg-muted px-2 py-1 rounded text-sm">
          {field.fieldKey}
        </code>
      </TableCell>
      <TableCell data-testid={`text-type-${field.id}`}>
        {field.fieldType}
      </TableCell>
      <TableCell data-testid={`text-required-${field.id}`}>
        {field.isRequired === 1 ? "Tak" : "Nie"}
      </TableCell>
      <TableCell data-testid={`text-status-${field.id}`}>
        <span className={`px-2 py-1 rounded text-xs ${
          field.isActive === 1 
            ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
            : "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
        }`}>
          {field.isActive === 1 ? "Aktywne" : "Nieaktywne"}
        </span>
      </TableCell>
      <TableCell data-testid={`text-default-${field.id}`}>
        {field.isDefault === 1 ? (
          <span className="text-xs text-blue-600 dark:text-blue-400">Domyślne</span>
        ) : (
          <span className="text-xs text-gray-500">Niestandardowe</span>
        )}
      </TableCell>
      <TableCell>
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onEdit(field)}
            data-testid={`button-edit-${field.id}`}
          >
            <Edit2 className="h-4 w-4" />
          </Button>
          {field.isDefault === 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDelete(field)}
              className="text-red-600 hover:text-red-700"
              data-testid={`button-delete-${field.id}`}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>
      </TableCell>
    </TableRow>
  );
}

// Add Field Modal Component
function AddFieldModal({ 
  onClose, 
  onSubmit, 
  isLoading 
}: { 
  onClose: () => void;
  onSubmit: (data: InsertFieldDefinition) => void;
  isLoading: boolean;
}) {
  const [formData, setFormData] = useState<InsertFieldDefinition>({
    fieldKey: '',
    fieldLabel: '',
    fieldType: 'text',
    entityType: 'customers',
    isRequired: 0,
    isDefault: 0,
    displayOrder: 0,
    isActive: 1,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.fieldKey.trim() || !formData.fieldLabel.trim()) {
      return;
    }

    onSubmit({
      ...formData,
      fieldKey: formData.fieldKey.trim(),
      fieldLabel: formData.fieldLabel.trim(),
    });
  };

  return (
    <DialogContent className="w-[95vw] sm:w-full sm:max-w-md max-h-[90vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle>Dodaj Nowe Pole</DialogTitle>
        <DialogDescription>
          Stwórz nowe pole danych dla klientów w systemie.
        </DialogDescription>
      </DialogHeader>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="fieldKey">Klucz Pola</Label>
          <Input
            id="fieldKey"
            value={formData.fieldKey}
            onChange={(e) => setFormData(prev => ({ ...prev, fieldKey: e.target.value }))}
            placeholder="np. customField1"
            data-testid="input-field-key"
          />
          <p className="text-xs text-muted-foreground">
            Unikalny identyfikator pola (bez spacji, tylko litery i cyfry)
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="fieldLabel">Nazwa Wyświetlana</Label>
          <Input
            id="fieldLabel"
            value={formData.fieldLabel}
            onChange={(e) => setFormData(prev => ({ ...prev, fieldLabel: e.target.value }))}
            placeholder="np. Dodatkowe Informacje"
            data-testid="input-field-label"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="fieldType">Typ Pola</Label>
          <Select 
            value={formData.fieldType} 
            onValueChange={(value) => setFormData(prev => ({ ...prev, fieldType: value }))}
          >
            <SelectTrigger data-testid="select-field-type">
              <SelectValue placeholder="Wybierz typ pola" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="text">Tekst</SelectItem>
              <SelectItem value="number">Liczba</SelectItem>
              <SelectItem value="email">Email</SelectItem>
              <SelectItem value="phone">Telefon</SelectItem>
              <SelectItem value="date">Data</SelectItem>
              <SelectItem value="list">Lista</SelectItem>
            </SelectContent>
          </Select>
        </div>

        

        {formData.fieldType === 'list' && (
          <div className="space-y-2">
            <Label htmlFor="fieldOptions">Opcje listy</Label>
            <Input
              id="fieldOptions"
              value={formData.fieldOptions || ''}
              onChange={(e) => setFormData(prev => ({ ...prev, fieldOptions: e.target.value }))}
              placeholder='Wpisz opcje oddzielone przecinkami, np. "opcja1,opcja2,opcja3"'
              data-testid="input-field-options"
            />
            <p className="text-xs text-muted-foreground">
              Wpisz opcje oddzielone przecinkami. Będą one dostępne w liście rozwijanej.
            </p>
          </div>
        )}

        <div className="space-y-2">
          <Label htmlFor="displayOrder">Kolejność Wyświetlania</Label>
          <Input
            id="displayOrder"
            type="number"
            value={formData.displayOrder || 0}
            onChange={(e) => setFormData(prev => ({ ...prev, displayOrder: parseInt(e.target.value) || 0 }))}
            placeholder="0"
            data-testid="input-display-order"
          />
        </div>

        <div className="flex items-center space-x-2">
          <Switch
            id="isRequired"
            checked={formData.isRequired === 1}
            onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isRequired: checked ? 1 : 0 }))}
            data-testid="switch-required"
          />
          <Label htmlFor="isRequired">Pole wymagane</Label>
        </div>

        <DialogFooter>
          <Button type="button" variant="outline" onClick={onClose}>
            Anuluj
          </Button>
          <Button 
            type="submit" 
            disabled={isLoading || !formData.fieldKey.trim() || !formData.fieldLabel.trim()}
            data-testid="button-submit-add-field"
          >
            {isLoading ? "Dodaję..." : "Dodaj Pole"}
          </Button>
        </DialogFooter>
      </form>
    </DialogContent>
  );
}

// Edit Field Modal Component
function EditFieldModal({ 
  field,
  onClose, 
  onSubmit, 
  isLoading 
}: { 
  field: FieldDefinition;
  onClose: () => void;
  onSubmit: (data: Partial<InsertFieldDefinition>) => void;
  isLoading: boolean;
}) {
  const [formData, setFormData] = useState<Partial<InsertFieldDefinition>>({
    fieldLabel: field.fieldLabel,
    fieldType: field.fieldType,
    entityType: field.entityType,
    fieldOptions: field.fieldOptions,
    isRequired: field.isRequired,
    displayOrder: field.displayOrder,
    isActive: field.isActive,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.fieldLabel?.trim()) {
      return;
    }

    onSubmit({
      ...formData,
      fieldLabel: formData.fieldLabel?.trim(),
    });
  };

  return (
    <DialogContent className="w-[95vw] sm:w-full sm:max-w-md max-h-[90vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle>Edytuj Pole</DialogTitle>
        <DialogDescription>
          Zmodyfikuj ustawienia pola "{field.fieldLabel}"
        </DialogDescription>
      </DialogHeader>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="editFieldKey">Klucz Pola</Label>
          <Input
            id="editFieldKey"
            value={field.fieldKey}
            disabled
            className="bg-muted"
            data-testid="input-edit-field-key"
          />
          <p className="text-xs text-muted-foreground">
            Klucza pola nie można zmieniać
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="editFieldLabel">Nazwa Wyświetlana</Label>
          <Input
            id="editFieldLabel"
            value={formData.fieldLabel || ''}
            onChange={(e) => setFormData(prev => ({ ...prev, fieldLabel: e.target.value }))}
            placeholder="np. Dodatkowe Informacje"
            data-testid="input-edit-field-label"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="editFieldType">Typ Pola</Label>
          <Select 
            value={formData.fieldType} 
            onValueChange={(value) => setFormData(prev => ({ ...prev, fieldType: value }))}
          >
            <SelectTrigger data-testid="select-edit-field-type">
              <SelectValue placeholder="Wybierz typ pola" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="text">Tekst</SelectItem>
              <SelectItem value="number">Liczba</SelectItem>
              <SelectItem value="email">Email</SelectItem>
              <SelectItem value="phone">Telefon</SelectItem>
              <SelectItem value="date">Data</SelectItem>
              <SelectItem value="list">Lista</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="editEntityType">Typ Encji</Label>
          <Select 
            value={formData.entityType} 
            onValueChange={(value) => setFormData(prev => ({ ...prev, entityType: value }))}
            disabled={field.isDefault === 1}
          >
            <SelectTrigger data-testid="select-edit-entity-type">
              <SelectValue placeholder="Wybierz typ encji" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="customers">Klienci</SelectItem>
              <SelectItem value="deals">Potencjalni Klienci</SelectItem>
            </SelectContent>
          </Select>
          {field.isDefault === 1 && (
            <p className="text-xs text-muted-foreground">
              Typu encji dla domyślnych pól nie można zmieniać
            </p>
          )}
        </div>

        {formData.fieldType === 'list' && (
          <div className="space-y-2">
            <Label htmlFor="editFieldOptions">Opcje listy</Label>
            <Input
              id="editFieldOptions"
              value={formData.fieldOptions || ''}
              onChange={(e) => setFormData(prev => ({ ...prev, fieldOptions: e.target.value }))}
              placeholder='Wpisz opcje oddzielone przecinkami, np. "opcja1,opcja2,opcja3"'
              data-testid="input-edit-field-options"
            />
            <p className="text-xs text-muted-foreground">
              Wpisz opcje oddzielone przecinkami. Będą one dostępne w liście rozwijanej.
            </p>
          </div>
        )}

        <div className="space-y-2">
          <Label htmlFor="editDisplayOrder">Kolejność Wyświetlania</Label>
          <Input
            id="editDisplayOrder"
            type="number"
            value={formData.displayOrder || 0}
            onChange={(e) => setFormData(prev => ({ ...prev, displayOrder: parseInt(e.target.value) || 0 }))}
            data-testid="input-edit-display-order"
          />
        </div>

        <div className="flex items-center space-x-2">
          <Switch
            id="editIsRequired"
            checked={formData.isRequired === 1}
            onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isRequired: checked ? 1 : 0 }))}
            disabled={field.isDefault === 1 && field.isRequired === 1}
            data-testid="switch-edit-required"
          />
          <Label htmlFor="editIsRequired">Pole wymagane</Label>
          {field.isDefault === 1 && field.isRequired === 1 && (
            <span className="text-xs text-muted-foreground">(nie można zmienić)</span>
          )}
        </div>

        <div className="flex items-center space-x-2">
          <Switch
            id="editIsActive"
            checked={formData.isActive === 1}
            onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked ? 1 : 0 }))}
            data-testid="switch-edit-active"
          />
          <Label htmlFor="editIsActive">Pole aktywne</Label>
        </div>

        <DialogFooter>
          <Button type="button" variant="outline" onClick={onClose}>
            Anuluj
          </Button>
          <Button 
            type="submit" 
            disabled={isLoading || !formData.fieldLabel?.trim()}
            data-testid="button-submit-edit-field"
          >
            {isLoading ? "Zapisuję..." : "Zapisz Zmiany"}
          </Button>
        </DialogFooter>
      </form>
    </DialogContent>
  );
}