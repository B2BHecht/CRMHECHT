import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowUp, ArrowDown, Eye, EyeOff, Settings as SettingsIcon, GripVertical } from "lucide-react";
import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { RoleColumnPermission, InsertRoleColumnPermission, FieldDefinition } from "@shared/schema";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import {
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

const AVAILABLE_COLUMNS = {
  customers: [
    { id: 'groupName', label: 'Nazwa grupy', category: 'basic' },
    { id: 'contractorName', label: 'Nazwa kontrahenta', category: 'basic' },
    { id: 'nip', label: 'NIP', category: 'basic' },
    { id: 'city', label: 'Miasto', category: 'location' },
    { id: 'code', label: 'Kod pocztowy', category: 'location' },
    { id: 'streetAddress', label: 'Adres', category: 'location' },
    { id: 'contract', label: 'Umowa', category: 'business' },
    { id: 'classification', label: 'Klasyfikacja', category: 'business' },
    { id: 'salesperson', label: 'Handlowiec', category: 'management' },
    { id: 'email', label: 'Email', category: 'contact' },
    { id: 'phone', label: 'Telefon', category: 'contact' },
    { id: 'revenue2020', label: 'Obrót 2020', category: 'financial' },
    { id: 'revenue2021', label: 'Obrót 2021', category: 'financial' },
    { id: 'revenue2022', label: 'Obrót 2022', category: 'financial' },
    { id: 'revenue2023', label: 'Obrót 2023', category: 'financial' },
    { id: 'revenue2024', label: 'Obrót 2024', category: 'financial' },
    { id: 'revenue2025', label: 'Obrót 2025', category: 'financial' },
    { id: 'totalRevenue', label: 'Suma kontrahenta', category: 'financial' },
    { id: 'acquisitionMethod', label: 'Sposób pozyskania', category: 'business' },
    { id: 'website', label: 'Strona internetowa', category: 'contact' },
    { id: 'allegro', label: 'Allegro', category: 'contact' },
    { id: 'notes', label: 'Notatki', category: 'metadata' },
    { id: 'createdAt', label: 'Data utworzenia', category: 'metadata' }
  ],
  deals: [] // Will be populated dynamically from field definitions
};

const ROLES = [
  { value: 'administrator', label: 'Administrator' },
  { value: 'dyrektor', label: 'Dyrektor' }, 
  { value: 'koordynator', label: 'Koordynator' },
  { value: 'handlowiec', label: 'Handlowiec' }
];

const ENTITY_TYPES = [
  { value: 'customers', label: 'Klienci' },
  { value: 'deals', label: 'Potencjalni klienci' }
];

type RoleKey = 'administrator' | 'dyrektor' | 'koordynator' | 'handlowiec';
type EntityType = 'customers' | 'deals';

type ColumnConfig = {
  id: string;
  label: string;
  category: string;
  visible: boolean;
  order: number;
};

export function ColumnPermissions() {
  const [selectedRole, setSelectedRole] = useState<RoleKey>('handlowiec');
  const [selectedEntityType, setSelectedEntityType] = useState<EntityType>('customers');
  const [localPermissions, setLocalPermissions] = useState<ColumnConfig[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Configure DnD sensors
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  // Pobierz definicje pól dla dynamicznych kolumn
  const { data: fieldDefinitions = [] } = useQuery<FieldDefinition[]>({
    queryKey: ['/api/field-definitions'],
  });

  // Pobierz uprawnienia dla wybranej roli i typu encji
  const { data: permissions = [], isLoading } = useQuery<RoleColumnPermission[]>({
    queryKey: ['/api/role-column-permissions', selectedRole, selectedEntityType],
  });

  // Zaktualizuj lokalne uprawnienia gdy zmieni się rola, typ encji lub dane
  useEffect(() => {
    let availableColumns: any[] = [];
    
    if (selectedEntityType === 'customers') {
      availableColumns = AVAILABLE_COLUMNS.customers;
    } else if (selectedEntityType === 'deals') {
      // Dynamicznie generuj kolumny na podstawie definicji pól dla deals
      availableColumns = fieldDefinitions
        .filter(field => field.entityType === 'deals' && field.isActive === 1)
        .map(field => ({
          id: field.fieldKey,
          label: field.fieldLabel,
          category: getFieldCategory(field.fieldType)
        }));
    }

    if (permissions.length > 0) {
      const mappedPermissions = permissions.map(p => ({
        id: p.columnId,
        label: p.columnLabel,
        category: p.columnCategory,
        visible: p.isVisible === 1,
        order: p.displayOrder
      }));
      setLocalPermissions(mappedPermissions);
    } else {
      // Jeśli brak uprawnień, użyj domyślnych kolumn
      const defaultPermissions = availableColumns.map((col, index) => ({
        id: col.id,
        label: col.label,
        category: col.category,
        visible: true,
        order: index
      }));
      setLocalPermissions(defaultPermissions);
    }
  }, [permissions, selectedEntityType, fieldDefinitions]);

  // Pomocnicza funkcja do określenia kategorii pola
  const getFieldCategory = (fieldType: string): string => {
    switch (fieldType) {
      case 'email': return 'contact';
      case 'phone': return 'contact';
      case 'list': return 'basic';
      case 'text': return 'basic';
      case 'number': return 'financial';
      case 'date': return 'metadata';
      default: return 'basic';
    }
  };

  // Mutation do zapisywania uprawnień
  const savePermissionsMutation = useMutation({
    mutationFn: (permissionsToSave: InsertRoleColumnPermission[]) => 
      apiRequest('PUT', `/api/role-column-permissions/${selectedRole}/${selectedEntityType}`, permissionsToSave),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/role-column-permissions'] });
      toast({
        title: "Sukces",
        description: "Konfiguracja kolumn została zapisana",
      });
    },
    onError: () => {
      toast({
        title: "Błąd",
        description: "Nie udało się zapisać konfiguracji kolumn",
        variant: "destructive",
      });
    },
  });

  const toggleColumnVisibility = (columnId: string, visible: boolean) => {
    setLocalPermissions(prev => 
      prev.map(col => col.id === columnId ? { ...col, visible } : col)
    );
  };

  const moveColumn = (columnId: string, direction: 'up' | 'down') => {
    const currentIndex = localPermissions.findIndex(col => col.id === columnId);
    
    if (
      (direction === 'up' && currentIndex === 0) ||
      (direction === 'down' && currentIndex === localPermissions.length - 1)
    ) {
      return;
    }

    const newIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
    const newPermissions = [...localPermissions];
    [newPermissions[currentIndex], newPermissions[newIndex]] = [newPermissions[newIndex], newPermissions[currentIndex]];
    
    const reorderedWithIndex = newPermissions.map((item, index) => ({ ...item, order: index }));
    setLocalPermissions(reorderedWithIndex);
  };

  // Handle drag end for DnD
  function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event;

    if (active.id !== over?.id) {
      const oldIndex = localPermissions.findIndex(col => col.id === active.id);
      const newIndex = localPermissions.findIndex(col => col.id === over?.id);
      
      const reorderedPermissions = arrayMove(localPermissions, oldIndex, newIndex);
      const reorderedWithIndex = reorderedPermissions.map((item, index) => ({ ...item, order: index }));
      setLocalPermissions(reorderedWithIndex);
    }
  }

  const saveColumnPermissions = () => {
    const permissionsToSave: InsertRoleColumnPermission[] = localPermissions.map((col, index) => ({
      role: selectedRole,
      entityType: selectedEntityType,
      columnId: col.id,
      columnLabel: col.label,
      columnCategory: col.category,
      isVisible: col.visible ? 1 : 0,
      displayOrder: index,
    }));

    savePermissionsMutation.mutate(permissionsToSave);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <SettingsIcon className="h-5 w-5" />
            Konfiguracja Kolumn dla Ról
          </CardTitle>
          <CardDescription>
            Określ jakie kolumny są widoczne dla każdej roli i w jakiej kolejności
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex items-center gap-4">
              <Label>Wybierz rolę:</Label>
              <Select value={selectedRole} onValueChange={(value) => setSelectedRole(value as RoleKey)}>
                <SelectTrigger className="w-48" data-testid="select-role-permissions">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ROLES.map(role => (
                    <SelectItem key={role.value} value={role.value}>
                      {role.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center gap-4">
              <Label>Typ tabeli:</Label>
              <Select value={selectedEntityType} onValueChange={(value) => setSelectedEntityType(value as EntityType)}>
                <SelectTrigger className="w-48" data-testid="select-entity-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ENTITY_TYPES.map(entityType => (
                    <SelectItem key={entityType.value} value={entityType.value}>
                      {entityType.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="bg-muted/30 rounded-lg p-4">
            <h4 className="font-medium mb-3">
              Kolumny dla roli: {ROLES.find(r => r.value === selectedRole)?.label} - {ENTITY_TYPES.find(e => e.value === selectedEntityType)?.label}
            </h4>
            
            {isLoading ? (
              <div className="space-y-2">
                {[1, 2, 3, 4].map(i => (
                  <div key={i} className="h-16 bg-muted animate-pulse rounded-lg" />
                ))}
              </div>
            ) : (
              <DndContext 
                sensors={sensors}
                collisionDetection={closestCenter}
                onDragEnd={handleDragEnd}
              >
                <SortableContext 
                  items={localPermissions.map(col => col.id)}
                  strategy={verticalListSortingStrategy}
                >
                  <div className="space-y-2">
                    {localPermissions?.map((column, index) => (
                      <SortableColumnItem
                        key={column.id}
                        column={column}
                        index={index}
                        moveColumn={moveColumn}
                        toggleColumnVisibility={toggleColumnVisibility}
                        totalCount={localPermissions.length}
                      />
                    ))}
                  </div>
                </SortableContext>
              </DndContext>
            )}
          </div>

          <div className="flex justify-end">
            <Button onClick={saveColumnPermissions} data-testid="button-save-column-permissions">
              Zapisz konfigurację kolumn
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Sortable Column Item Component
function SortableColumnItem({ 
  column, 
  index, 
  moveColumn, 
  toggleColumnVisibility,
  totalCount
}: { 
  column: ColumnConfig; 
  index: number;
  moveColumn: (columnId: string, direction: 'up' | 'down') => void;
  toggleColumnVisibility: (columnId: string, visible: boolean) => void;
  totalCount: number;
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: column.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div 
      ref={setNodeRef} 
      style={style}
      className={`flex items-center gap-3 p-3 bg-background border rounded-lg ${isDragging ? "bg-muted/50" : ""}`}
    >
      {/* Drag Handle */}
      <div
        {...attributes}
        {...listeners}
        className="cursor-grab active:cursor-grabbing p-1 hover:bg-muted rounded"
        data-testid={`drag-handle-${column.id}`}
      >
        <GripVertical className="h-4 w-4 text-muted-foreground" />
      </div>

      {/* Move Buttons */}
      <div className="flex flex-col gap-1">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => moveColumn(column.id, 'up')}
          disabled={index === 0}
          data-testid={`button-move-up-${column.id}`}
          className="h-6 w-6 p-0"
        >
          <ArrowUp className="h-3 w-3" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => moveColumn(column.id, 'down')}
          disabled={index === totalCount - 1}
          data-testid={`button-move-down-${column.id}`}
          className="h-6 w-6 p-0"
        >
          <ArrowDown className="h-3 w-3" />
        </Button>
      </div>
      
      {/* Visibility Checkbox */}
      <Checkbox
        checked={column.visible}
        onCheckedChange={(checked) => toggleColumnVisibility(column.id, checked as boolean)}
        data-testid={`checkbox-column-${column.id}`}
      />
      
      {/* Column Info */}
      <div className="flex-1">
        <div className="flex items-center gap-2">
          {column.visible ? (
            <Eye className="h-4 w-4 text-green-600" />
          ) : (
            <EyeOff className="h-4 w-4 text-muted-foreground" />
          )}
          <span className="font-medium">{column.label}</span>
          <Badge variant="outline" className="text-xs">
            {column.category}
          </Badge>
        </div>
      </div>
      
      {/* Position */}
      <span className="text-sm text-muted-foreground min-w-[80px] text-right">
        Pozycja {index + 1}
      </span>
    </div>
  );
}