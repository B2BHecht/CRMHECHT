import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit2, Trash2, UserCheck, UserX } from "lucide-react";
import type { User, InsertUser } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export default function UserManagement() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch users
  const { data: users = [], isLoading } = useQuery<User[]>({
    queryKey: ['/api/users'],
  });

  // Add user mutation
  const addUserMutation = useMutation({
    mutationFn: (data: InsertUser) => 
      apiRequest('POST', '/api/users', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      setIsAddModalOpen(false);
      toast({
        title: "Sukces",
        description: "Użytkownik został dodany pomyślnie",
      });
    },
    onError: () => {
      toast({
        title: "Błąd",
        description: "Nie udało się dodać użytkownika",
        variant: "destructive",
      });
    },
  });

  // Update user mutation
  const updateUserMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertUser> }) =>
      apiRequest('PATCH', `/api/users/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      setIsEditModalOpen(false);
      setEditingUser(null);
      toast({
        title: "Sukces",
        description: "Użytkownik został zaktualizowany pomyślnie",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się zaktualizować użytkownika",
        variant: "destructive",
      });
    },
  });

  // Delete user mutation
  const deleteUserMutation = useMutation({
    mutationFn: (id: string) => 
      apiRequest('DELETE', `/api/users/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "Sukces",
        description: "Użytkownik został usunięty pomyślnie",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się usunąć użytkownika",
        variant: "destructive",
      });
    },
  });

  const handleEdit = (user: User) => {
    setEditingUser(user);
    setIsEditModalOpen(true);
  };

  const handleDelete = async (user: User) => {
    if (user.username === 'admin') {
      toast({
        title: "Błąd",
        description: "Nie można usunąć konta administratora",
        variant: "destructive",
      });
      return;
    }

    if (window.confirm(`Czy na pewno chcesz usunąć użytkownika "${user.firstName} ${user.lastName}"?`)) {
      deleteUserMutation.mutate(user.id);
    }
  };

  const getRoleDisplay = (role: string) => {
    switch (role) {
      case 'administrator': return 'Administrator';
      case 'handlowiec': return 'Handlowiec';
      case 'dyrektor': return 'Dyrektor';
      case 'koordynator': return 'Koordynator';
      default: return role;
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div>Ładowanie użytkowników...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Zarządzanie Użytkownikami</CardTitle>
              <CardDescription>
                Dodawaj użytkowników i przyznawaj im odpowiednie role w systemie
              </CardDescription>
            </div>
            
            <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
              <DialogTrigger asChild>
                <Button data-testid="button-add-user">
                  <Plus className="h-4 w-4 mr-2" />
                  Dodaj Użytkownika
                </Button>
              </DialogTrigger>
              <AddUserModal 
                onClose={() => setIsAddModalOpen(false)}
                onSubmit={(data) => addUserMutation.mutate(data)}
                isLoading={addUserMutation.isPending}
              />
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="min-w-32">Imię i nazwisko</TableHead>
                  <TableHead className="min-w-24">Nazwa użytkownika</TableHead>
                  <TableHead className="min-w-32">Email</TableHead>
                  <TableHead className="w-24">Rola</TableHead>
                  <TableHead className="w-20">Status</TableHead>
                  <TableHead className="min-w-32">Ostatnie logowanie</TableHead>
                  <TableHead className="w-24">Akcje</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user: User) => (
                  <TableRow key={user.id}>
                    <TableCell data-testid={`text-fullname-${user.id}`}>
                      <span className="font-medium">{user.firstName} {user.lastName}</span>
                    </TableCell>
                    <TableCell data-testid={`text-username-${user.id}`}>
                      {user.username}
                    </TableCell>
                    <TableCell data-testid={`text-email-${user.id}`}>
                      {user.email}
                    </TableCell>
                    <TableCell data-testid={`text-role-${user.id}`}>
                      <span className={`px-2 py-1 rounded text-xs ${
                        user.role === 'administrator' 
                          ? "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300"
                          : user.role === 'dyrektor'
                          ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
                          : "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                      }`}>
                        {getRoleDisplay(user.role)}
                      </span>
                    </TableCell>
                    <TableCell data-testid={`text-status-${user.id}`}>
                      {user.isActive === 1 ? (
                        <div className="flex items-center gap-1">
                          <UserCheck className="h-4 w-4 text-green-600" />
                          <span className="text-green-600">Aktywny</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1">
                          <UserX className="h-4 w-4 text-red-600" />
                          <span className="text-red-600">Nieaktywny</span>
                        </div>
                      )}
                    </TableCell>
                    <TableCell data-testid={`text-last-login-${user.id}`}>
                      {user.lastLogin ? new Date(user.lastLogin).toLocaleDateString('pl-PL') : 'Nigdy'}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(user)}
                          data-testid={`button-edit-user-${user.id}`}
                        >
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        {user.username !== 'admin' && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(user)}
                            className="text-red-600 hover:text-red-700"
                            data-testid={`button-delete-user-${user.id}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Edit Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        {editingUser && (
          <EditUserModal 
            user={editingUser}
            onClose={() => {
              setIsEditModalOpen(false);
              setEditingUser(null);
            }}
            onSubmit={(data) => updateUserMutation.mutate({ 
              id: editingUser.id, 
              data 
            })}
            isLoading={updateUserMutation.isPending}
          />
        )}
      </Dialog>
    </div>
  );
}

// Add User Modal Component
function AddUserModal({ 
  onClose, 
  onSubmit, 
  isLoading 
}: { 
  onClose: () => void;
  onSubmit: (data: InsertUser) => void;
  isLoading: boolean;
}) {
  const [formData, setFormData] = useState<InsertUser>({
    username: '',
    email: '',
    password: '',
    firstName: '',
    lastName: '',
    role: 'handlowiec',
    isActive: 1,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.username.trim() || !formData.email.trim() || !formData.firstName.trim() || !formData.lastName.trim() || !formData.password.trim()) {
      return;
    }

    onSubmit({
      ...formData,
      username: formData.username.trim(),
      email: formData.email.trim(),
      firstName: formData.firstName.trim(),
      lastName: formData.lastName.trim(),
    });
  };

  return (
    <DialogContent className="sm:max-w-md">
      <DialogHeader>
        <DialogTitle>Dodaj Nowego Użytkownika</DialogTitle>
        <DialogDescription>
          Stwórz nowe konto użytkownika i przyznaj mu odpowiednią rolę.
        </DialogDescription>
      </DialogHeader>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="firstName">Imię</Label>
            <Input
              id="firstName"
              value={formData.firstName}
              onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
              placeholder="Jan"
              data-testid="input-first-name"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="lastName">Nazwisko</Label>
            <Input
              id="lastName"
              value={formData.lastName}
              onChange={(e) => setFormData(prev => ({ ...prev, lastName: e.target.value }))}
              placeholder="Kowalski"
              data-testid="input-last-name"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="username">Nazwa użytkownika</Label>
          <Input
            id="username"
            value={formData.username}
            onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value }))}
            placeholder="jkowalski"
            data-testid="input-username"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            type="email"
            value={formData.email}
            onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
            placeholder="jan@firma.pl"
            data-testid="input-email"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="password">Hasło</Label>
          <Input
            id="password"
            type="password"
            value={formData.password}
            onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
            placeholder="••••••••"
            data-testid="input-password"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="role">Rola</Label>
          <Select 
            value={formData.role} 
            onValueChange={(value) => setFormData(prev => ({ ...prev, role: value }))}
          >
            <SelectTrigger data-testid="select-role">
              <SelectValue placeholder="Wybierz rolę" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="administrator">Administrator</SelectItem>
              <SelectItem value="dyrektor">Dyrektor</SelectItem>
              <SelectItem value="koordynator">Koordynator</SelectItem>
              <SelectItem value="handlowiec">Handlowiec</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center space-x-2">
          <Switch
            id="isActive"
            checked={formData.isActive === 1}
            onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked ? 1 : 0 }))}
            data-testid="switch-active"
          />
          <Label htmlFor="isActive">Konto aktywne</Label>
        </div>

        <DialogFooter>
          <Button type="button" variant="outline" onClick={onClose}>
            Anuluj
          </Button>
          <Button 
            type="submit" 
            disabled={isLoading || !formData.username.trim() || !formData.email.trim() || !formData.firstName.trim() || !formData.lastName.trim() || !formData.password.trim()}
            data-testid="button-submit-add-user"
          >
            {isLoading ? "Dodaję..." : "Dodaj Użytkownika"}
          </Button>
        </DialogFooter>
      </form>
    </DialogContent>
  );
}

// Edit User Modal Component
function EditUserModal({ 
  user,
  onClose, 
  onSubmit, 
  isLoading 
}: { 
  user: User;
  onClose: () => void;
  onSubmit: (data: Partial<InsertUser>) => void;
  isLoading: boolean;
}) {
  const [formData, setFormData] = useState<Partial<InsertUser>>({
    firstName: user.firstName,
    lastName: user.lastName,
    email: user.email,
    role: user.role,
    isActive: user.isActive,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.firstName?.trim() || !formData.lastName?.trim() || !formData.email?.trim()) {
      return;
    }

    onSubmit({
      ...formData,
      firstName: formData.firstName?.trim(),
      lastName: formData.lastName?.trim(),
      email: formData.email?.trim(),
    });
  };

  return (
    <DialogContent className="sm:max-w-md">
      <DialogHeader>
        <DialogTitle>Edytuj Użytkownika</DialogTitle>
        <DialogDescription>
          Zmodyfikuj dane użytkownika "{user.firstName} {user.lastName}"
        </DialogDescription>
      </DialogHeader>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="editUsername">Nazwa użytkownika</Label>
          <Input
            id="editUsername"
            value={user.username}
            disabled
            className="bg-muted"
            data-testid="input-edit-username"
          />
          <p className="text-xs text-muted-foreground">
            Nazwy użytkownika nie można zmieniać
          </p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="editFirstName">Imię</Label>
            <Input
              id="editFirstName"
              value={formData.firstName || ''}
              onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
              data-testid="input-edit-first-name"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="editLastName">Nazwisko</Label>
            <Input
              id="editLastName"
              value={formData.lastName || ''}
              onChange={(e) => setFormData(prev => ({ ...prev, lastName: e.target.value }))}
              data-testid="input-edit-last-name"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="editEmail">Email</Label>
          <Input
            id="editEmail"
            type="email"
            value={formData.email || ''}
            onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
            data-testid="input-edit-email"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="editRole">Rola</Label>
          <Select 
            value={formData.role} 
            onValueChange={(value) => setFormData(prev => ({ ...prev, role: value }))}
            disabled={user.username === 'admin'}
          >
            <SelectTrigger data-testid="select-edit-role">
              <SelectValue placeholder="Wybierz rolę" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="administrator">Administrator</SelectItem>
              <SelectItem value="dyrektor">Dyrektor</SelectItem>
              <SelectItem value="koordynator">Koordynator</SelectItem>
              <SelectItem value="handlowiec">Handlowiec</SelectItem>
            </SelectContent>
          </Select>
          {user.username === 'admin' && (
            <p className="text-xs text-muted-foreground">
              Roli administratora głównego nie można zmieniać
            </p>
          )}
        </div>

        <div className="flex items-center space-x-2">
          <Switch
            id="editIsActive"
            checked={formData.isActive === 1}
            onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked ? 1 : 0 }))}
            disabled={user.username === 'admin'}
            data-testid="switch-edit-active"
          />
          <Label htmlFor="editIsActive">Konto aktywne</Label>
          {user.username === 'admin' && (
            <span className="text-xs text-muted-foreground">(nie można zmienić)</span>
          )}
        </div>

        <DialogFooter>
          <Button type="button" variant="outline" onClick={onClose}>
            Anuluj
          </Button>
          <Button 
            type="submit" 
            disabled={isLoading || !formData.firstName?.trim() || !formData.lastName?.trim() || !formData.email?.trim()}
            data-testid="button-submit-edit-user"
          >
            {isLoading ? "Zapisuję..." : "Zapisz Zmiany"}
          </Button>
        </DialogFooter>
      </form>
    </DialogContent>
  );
}