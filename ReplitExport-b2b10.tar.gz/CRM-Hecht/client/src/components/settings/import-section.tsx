import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Upload, Download, FileSpreadsheet, AlertCircle } from "lucide-react";
import * as XLSX from "xlsx";
import { apiRequest } from "@/lib/queryClient";

export default function ImportSection() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [importType, setImportType] = useState<'customers' | 'deals'>('customers');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const importCustomersMutation = useMutation({
    mutationFn: (customers: any[]) => 
      apiRequest('POST', '/api/customers/import', { customers }),
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/customers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/deals'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/metrics'] });
      
      toast({
        title: "Sukces!",
        description: `Zaimportowano ${data.imported} klientów, pominięto ${data.skipped || 0} rekordów`,
      });
      
      setSelectedFile(null);
      setIsUploading(false);
    },
    onError: (error: any) => {
      toast({
        title: "Błąd importu",
        description: error.message || "Nie udało się zaimportować pliku",
        variant: "destructive",
      });
      setIsUploading(false);
    },
  });

  // Import deals (potential customers) mutation
  const importDealsMutation = useMutation({
    mutationFn: (potentialCustomers: any[]) => 
      apiRequest('POST', '/api/deals/import', { potentialCustomers }),
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/customers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/deals'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/metrics'] });
      
      toast({
        title: "Sukces!",
        description: `Zaimportowano ${data.imported} potencjalnych klientów, pominięto ${data.skipped || 0} rekordów`,
      });
      
      setSelectedFile(null);
      setIsUploading(false);
    },
    onError: (error: any) => {
      toast({
        title: "Błąd importu",
        description: error.message || "Nie udało się zaimportować pliku",
        variant: "destructive",
      });
      setIsUploading(false);
    },
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.match(/\.(xlsx|xls)$/)) {
      toast({
        title: "Błąd pliku",
        description: "Obsługiwane są tylko pliki Excel (.xlsx, .xls)",
        variant: "destructive",
      });
      return;
    }

    setSelectedFile(file);
  };

  const handleImport = async () => {
    if (!selectedFile) return;

    setIsUploading(true);
    
    try {
      const data = await selectedFile.arrayBuffer();
      const workbook = XLSX.read(data, { type: "array" });
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);

      if (importType === 'customers') {
        // Mapowanie kolumn Excel na pola systemu - zwykli klienci
        const customers = jsonData.map((row: any) => ({
          groupName: row['Nazwa grupy'] || row['groupName'] || '',
          contractorName: row['Nazwa kontrahenta'] || row['contractorName'] || '',
          nip: row['NIP'] || row['nip'] || '',
          city: row['Miasto'] || row['city'] || '',
          code: row['Kod'] || row['code'] || '',
          streetAddress: row['Ulica, nr lokalu'] || row['streetAddress'] || '',
          contract: row['Umowa'] || row['contract'] || '',
          classification: row['Nazwa klasyfikacji'] || row['classification'] || '',
          salesperson: row['Handlowiec'] || row['salesperson'] || '',
          email: row['E-mail kontrahenta'] || row['email'] || '',
          phone: row['Nr telefonu'] || row['phone'] || '',
          revenue2020: String(row['Obrót Netto 2020'] || row['revenue2020'] || '0'),
          revenue2021: String(row['Obrót Netto 2021'] || row['revenue2021'] || '0'),
          revenue2022: String(row['Obrót Netto 2022'] || row['revenue2022'] || '0'),
          revenue2023: String(row['Obrót Netto 2023'] || row['revenue2023'] || '0'),
          revenue2024: String(row['Obrót Netto 2024'] || row['revenue2024'] || '0'),
          revenue2025: String(row['Obrót Netto 2025'] || row['revenue2025'] || '0'),
          totalRevenue: String(row['Suma kontrahenta'] || row['totalRevenue'] || '0'),
        }));

        importCustomersMutation.mutate(customers);
      } else {
        // Mapowanie kolumn Excel na potencjalnych klientów
        const potentialCustomers = jsonData.map((row: any) => ({
          contractorName: row['Nazwa kontrahenta'] || row['contractorName'] || '',
          nip: row['NIP'] || row['nip'] || '',
          city: row['Miasto'] || row['city'] || '',
          code: row['Kod pocztowy'] || row['code'] || '',
          streetAddress: row['Adres'] || row['streetAddress'] || '',
          email: row['E-mail'] || row['email'] || '',
          phone: row['Telefon'] || row['phone'] || '',
          acquisitionMethod: row['Sposób pozyskania'] || row['acquisitionMethod'] || 'Inne',
          notes: row['Notatki'] || row['notes'] || '',
          salesperson: row['Handlowiec'] || row['salesperson'] || '',
        }));

        importDealsMutation.mutate(potentialCustomers);
      }

    } catch (error) {
      toast({
        title: "Błąd odczytu pliku",
        description: "Nie udało się odczytać pliku Excel",
        variant: "destructive",
      });
      setIsUploading(false);
    }
  };

  const downloadTemplate = () => {
    if (importType === 'customers') {
      const templateData = [{
        'Nazwa grupy': '',
        'Nazwa kontrahenta': 'Przykładowa Firma Sp. z o.o.',
        'NIP': '1234567890',
        'Miasto': 'Warszawa',
        'Kod': '00-001',
        'Ulica, nr lokalu': 'ul. Przykładowa 1',
        'Umowa': 'UZ/2024/001',
        'Nazwa klasyfikacji': 'Klient Premium',
        'Handlowiec': 'Jan Kowalski',
        'E-mail kontrahenta': 'kontakt@firma.pl',
        'Nr telefonu': '+48 123 456 789',
        'Obrót Netto 2020': '50000',
        'Obrót Netto 2021': '75000',
        'Obrót Netto 2022': '80000',
        'Obrót Netto 2023': '95000',
        'Obrót Netto 2024': '120000',
        'Obrót Netto 2025': '0',
        'Suma kontrahenta': '420000',
      }];

      const worksheet = XLSX.utils.json_to_sheet(templateData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Klienci');
      XLSX.writeFile(workbook, 'szablon_import_klientow.xlsx');
    } else {
      const templateData = [{
        'Nazwa kontrahenta': 'Przykładowa Firma Sp. z o.o.',
        'NIP': '1234567890',
        'Miasto': 'Warszawa', 
        'Kod pocztowy': '00-001',
        'Adres': 'ul. Przykładowa 1',
        'E-mail': 'kontakt@firma.pl',
        'Telefon': '+48 123 456 789',
        'Sposób pozyskania': 'Strona internetowa',
        'Notatki': 'Potencjalny klient z targów',
        'Handlowiec': 'Jan Kowalski',
      }];

      const worksheet = XLSX.utils.json_to_sheet(templateData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Potencjalni Klienci');
      XLSX.writeFile(workbook, 'szablon_import_potencjalnych_klientow.xlsx');
    }

    toast({
      title: "Pobrano szablon",
      description: `Szablon pliku Excel został pobrany dla ${importType === 'customers' ? 'klientów' : 'potencjalnych klientów'}`,
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Import z Excel</CardTitle>
          <CardDescription>
            Importuj {importType === 'customers' ? 'klientów' : 'potencjalnych klientów'} z pliku Excel (.xlsx lub .xls)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <Label htmlFor="import-type">Typ importu</Label>
            <Select value={importType} onValueChange={(value: 'customers' | 'deals') => setImportType(value)}>
              <SelectTrigger data-testid="select-import-type">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="customers">Klienci (istniejący)</SelectItem>
                <SelectItem value="deals">Potencjalni Klienci (nowe leady)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-center p-6 border-2 border-dashed border-muted-foreground/25 rounded-lg">
            <div className="text-center space-y-4">
              <FileSpreadsheet className="mx-auto h-12 w-12 text-muted-foreground" />
              <div className="space-y-2">
                <Label htmlFor="excel-file" className="text-sm font-medium">
                  Wybierz plik Excel
                </Label>
                <Input
                  id="excel-file"
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={handleFileSelect}
                  className="max-w-md"
                  data-testid="input-excel-file"
                />
              </div>
              {selectedFile && (
                <div className="text-sm text-green-600 dark:text-green-400">
                  Wybrany plik: {selectedFile.name}
                </div>
              )}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              onClick={downloadTemplate}
              variant="outline"
              className="flex items-center gap-2"
              data-testid="button-download-template"
            >
              <Download className="h-4 w-4" />
              Pobierz Szablon
            </Button>
            
            <Button
              onClick={handleImport}
              disabled={!selectedFile || isUploading}
              className="flex items-center gap-2"
              data-testid="button-import-excel"
            >
              {isUploading ? (
                <>Importuję...</>
              ) : (
                <>
                  <Upload className="h-4 w-4" />
                  Importuj Plik
                </>
              )}
            </Button>
          </div>

          <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-blue-600 dark:text-blue-400 mt-0.5" />
              <div className="space-y-2">
                <h4 className="font-medium text-blue-900 dark:text-blue-100">
                  Instrukcje importu
                </h4>
                <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
                  <li>• Pobierz szablon Excel i wypełnij go danymi</li>
                  <li>• Pierwszy wiersz zawiera nazwy kolumn - nie usuwaj go</li>
                  <li>• Puste komórki są dozwolone</li>
                  <li>• Duplikaty (na podstawie NIP) będą pominięte</li>
                  {importType === 'customers' ? (
                    <li>• Wartości liczbowe (obroty) muszą być w formacie numerycznym</li>
                  ) : (
                    <>
                      <li>• Każdy potencjalny klient automatycznie otrzyma status "Nowy"</li>
                      <li>• Zostanie utworzony deal z terminem zamknięcia za 30 dni</li>
                    </>
                  )}
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}