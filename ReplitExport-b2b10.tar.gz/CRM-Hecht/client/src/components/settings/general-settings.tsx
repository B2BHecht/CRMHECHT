import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Save, Settings, Eye, EyeOff, FileSpreadsheet, AlertCircle, Menu, Key, Brain, MessageSquare, Lock } from "lucide-react";
import type { SystemSetting, InsertSystemSetting } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";

export default function GeneralSettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { changePassword } = useAuth();
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  // Fetch system settings
  const { data: settings = [], isLoading } = useQuery<SystemSetting[]>({
    queryKey: ['/api/settings'],
  });

  // Update setting mutation
  const updateSettingMutation = useMutation({
    mutationFn: ({ key, data }: { key: string; data: Partial<InsertSystemSetting> }) =>
      apiRequest('PATCH', `/api/settings/${key}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
      toast({
        title: "Sukces",
        description: "Ustawienia zostały zapisane pomyślnie",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się zapisać ustawień",
        variant: "destructive",
      });
    },
  });

  const handleUpdateSetting = (settingKey: string, settingValue: string) => {
    console.log('🔧 Zapisuję ustawienie:', settingKey, '=', settingValue);
    updateSettingMutation.mutate({
      key: settingKey,
      data: { settingValue }
    });
  };

  const getSettingValue = (key: string, defaultValue: string = '') => {
    const setting = settings.find(s => s.settingKey === key);
    return setting?.settingValue || defaultValue;
  };

  const handlePasswordChange = async () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast({
        title: "Błąd",
        description: "Nowe hasło i potwierdzenie hasła muszą być identyczne",
        variant: "destructive",
      });
      return;
    }

    if (passwordData.newPassword.length < 6) {
      toast({
        title: "Błąd",
        description: "Nowe hasło musi mieć co najmniej 6 znaków",
        variant: "destructive",
      });
      return;
    }

    setIsChangingPassword(true);
    try {
      await changePassword(passwordData.currentPassword, passwordData.newPassword, passwordData.confirmPassword);
      setPasswordData({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      });
    } catch (error) {
      // Error is handled by the changePassword hook
    } finally {
      setIsChangingPassword(false);
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div>Ładowanie ustawień...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="h-5 w-5" />
            Zmiana Hasła
          </CardTitle>
          <CardDescription>
            Zmień swoje hasło dostępu do systemu
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="currentPassword">Obecne hasło</Label>
            <Input
              id="currentPassword"
              type="password"
              value={passwordData.currentPassword}
              onChange={(e) => setPasswordData(prev => ({ ...prev, currentPassword: e.target.value }))}
              placeholder="Wpisz obecne hasło"
              data-testid="input-current-password"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="newPassword">Nowe hasło</Label>
            <Input
              id="newPassword"
              type="password"
              value={passwordData.newPassword}
              onChange={(e) => setPasswordData(prev => ({ ...prev, newPassword: e.target.value }))}
              placeholder="Wpisz nowe hasło (min. 6 znaków)"
              data-testid="input-new-password"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="confirmPassword">Potwierdź nowe hasło</Label>
            <Input
              id="confirmPassword"
              type="password"
              value={passwordData.confirmPassword}
              onChange={(e) => setPasswordData(prev => ({ ...prev, confirmPassword: e.target.value }))}
              placeholder="Powtórz nowe hasło"
              data-testid="input-confirm-password"
            />
          </div>

          <Button
            onClick={handlePasswordChange}
            disabled={isChangingPassword || !passwordData.currentPassword || !passwordData.newPassword || !passwordData.confirmPassword}
            className="w-full"
            data-testid="button-change-password"
          >
            {isChangingPassword ? "Zmieniam hasło..." : "Zmień hasło"}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Ustawienia Ogólne</CardTitle>
          <CardDescription>
            Skonfiguruj podstawowe ustawienia aplikacji
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="companyName">Nazwa firmy</Label>
              <div className="flex gap-2">
                <Input
                  id="companyName"
                  defaultValue={getSettingValue('company_name', 'Moja Firma')}
                  placeholder="Nazwa Twojej firmy"
                  data-testid="input-company-name"
                  onBlur={(e) => handleUpdateSetting('company_name', e.target.value)}
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Ta nazwa będzie wyświetlana w nagłówku aplikacji
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="customersPerPage">Liczba klientów na stronie</Label>
              <div className="flex gap-2">
                <Input
                  id="customersPerPage"
                  type="number"
                  min="5"
                  max="100"
                  defaultValue={getSettingValue('customers_per_page', '10')}
                  data-testid="input-customers-per-page"
                  onBlur={(e) => handleUpdateSetting('customers_per_page', e.target.value)}
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Liczba klientów wyświetlanych w tabeli na jednej stronie
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Ustawienia Pulpitu</CardTitle>
          <CardDescription>
            Skonfiguruj jakie elementy mają być widoczne na pulpicie głównym
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Pokaż ostatnie aktywności
              </Label>
              <p className="text-sm text-muted-foreground">
                Wyświetl sekcję z ostatnimi aktywnościami na pulpicie
              </p>
            </div>
            <Switch
              checked={getSettingValue('dashboard_show_activities', 'true') === 'true'}
              onCheckedChange={(checked) => handleUpdateSetting('dashboard_show_activities', checked ? 'true' : 'false')}
              data-testid="switch-show-activities"
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label className="flex items-center gap-2">
                <Eye className="h-4 w-4" />
                Pokaż statystyki sprzedaży
              </Label>
              <p className="text-sm text-muted-foreground">
                Wyświetl karty ze statystykami na górze pulpitu
              </p>
            </div>
            <Switch
              checked={getSettingValue('dashboard_show_stats', 'true') === 'true'}
              onCheckedChange={(checked) => handleUpdateSetting('dashboard_show_stats', checked ? 'true' : 'false')}
              data-testid="switch-show-stats"
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label className="flex items-center gap-2">
                <FileSpreadsheet className="h-4 w-4" />
                Pokaż tabelę klientów
              </Label>
              <p className="text-sm text-muted-foreground">
                Wyświetl tabelę z listą klientów na pulpicie
              </p>
            </div>
            <Switch
              checked={getSettingValue('dashboard_show_customers', 'true') === 'true'}
              onCheckedChange={(checked) => handleUpdateSetting('dashboard_show_customers', checked ? 'true' : 'false')}
              data-testid="switch-show-customers"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Uprawnienia Ról</CardTitle>
          <CardDescription>
            Skonfiguruj jakie dane widzą użytkownicy z różnymi rolami
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label className="flex items-center gap-2">
                <Eye className="h-4 w-4" />
                Handlowcy widzą tylko swoich klientów
              </Label>
              <p className="text-sm text-muted-foreground">
                Gdy włączone, handlowcy widzą tylko klientów przypisanych do siebie
              </p>
            </div>
            <Switch
              checked={getSettingValue('restrict_salesperson_view', 'false') === 'true'}
              onCheckedChange={(checked) => handleUpdateSetting('restrict_salesperson_view', checked ? 'true' : 'false')}
              data-testid="switch-restrict-salesperson-view"
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label className="flex items-center gap-2">
                <EyeOff className="h-4 w-4" />
                Ukryj szczegóły finansowe przed handlowcami
              </Label>
              <p className="text-sm text-muted-foreground">
                Handlowcy nie będą widzieć obrotów i wartości dealów
              </p>
            </div>
            <Switch
              checked={getSettingValue('hide_financial_from_salesperson', 'false') === 'true'}
              onCheckedChange={(checked) => handleUpdateSetting('hide_financial_from_salesperson', checked ? 'true' : 'false')}
              data-testid="switch-hide-financial"
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Koordynatorzy mogą zarządzać polami
              </Label>
              <p className="text-sm text-muted-foreground">
                Pozwól koordynatorom na edycję definicji pól w systemie
              </p>
            </div>
            <Switch
              checked={getSettingValue('coordinator_can_manage_fields', 'true') === 'true'}
              onCheckedChange={(checked) => handleUpdateSetting('coordinator_can_manage_fields', checked ? 'true' : 'false')}
              data-testid="switch-coordinator-fields"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Ustawienia Systemu</CardTitle>
          <CardDescription>
            Zaawansowane opcje konfiguracji systemu
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-yellow-600 dark:text-yellow-400 mt-0.5" />
              <div className="space-y-2">
                <h4 className="font-medium text-yellow-900 dark:text-yellow-100">
                  Tryb Deweloperski
                </h4>
                <div className="flex items-center justify-between">
                  <p className="text-sm text-yellow-800 dark:text-yellow-200">
                    Włącz dodatkowe opcje debugowania i rozwoju
                  </p>
                  <Switch
                    checked={getSettingValue('developer_mode', 'false') === 'true'}
                    onCheckedChange={(checked) => handleUpdateSetting('developer_mode', checked ? 'true' : 'false')}
                    data-testid="switch-developer-mode"
                  />
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Ustawienia Interfejsu</CardTitle>
          <CardDescription>
            Opcje personalizacji wyglądu aplikacji
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label className="flex items-center gap-2">
                <Menu className="h-4 w-4" />
                Automatyczne chowanie sidebar
              </Label>
              <p className="text-sm text-muted-foreground">
                Sidebar będzie się automatycznie zwijać aby zaoszczędzić miejsce na ekranie
              </p>
            </div>
            <Switch
              checked={getSettingValue('sidebar_auto_hide', 'false') === 'true'}
              onCheckedChange={(checked) => handleUpdateSetting('sidebar_auto_hide', checked ? 'true' : 'false')}
              data-testid="switch-sidebar-auto-hide"
            />
          </div>
        </CardContent>
      </Card>

      {/* Karta kluczy API */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="h-5 w-5" />
            Klucze API
          </CardTitle>
          <CardDescription>
            Zarządzaj kluczami API i funkcjami zewnętrznych usług
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Klucz Perplexity AI */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="perplexityKey" className="flex items-center gap-2">
                <Brain className="h-4 w-4" />
                Klucz API Perplexity AI
              </Label>
              <div className="flex gap-2">
                <Input
                  id="perplexityKey"
                  type="password"
                  defaultValue={getSettingValue('perplexity_api_key', '')}
                  placeholder="pplx-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                  data-testid="input-perplexity-key"
                  onBlur={(e) => handleUpdateSetting('perplexity_api_key', e.target.value)}
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Klucz do wzbogacania danych firm przez AI. Znajdź na perplexity.ai
              </p>
            </div>

            {/* Przełącznik włączania funkcji AI */}
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label className="flex items-center gap-2">
                  <Brain className="h-4 w-4" />
                  Włącz wzbogacanie AI
                </Label>
                <p className="text-sm text-muted-foreground">
                  Pozwala na automatyczne wzbogacanie danych firm przez AI
                </p>
              </div>
              <Switch
                checked={getSettingValue('ai_enrichment_enabled', 'true') === 'true'}
                onCheckedChange={(checked) => handleUpdateSetting('ai_enrichment_enabled', checked ? 'true' : 'false')}
                data-testid="switch-ai-enrichment"
              />
            </div>
          </div>

          {/* Edycja prompta AI */}
          <div className="space-y-4 border-t pt-4">
            <h4 className="font-medium text-muted-foreground">Prompt automatycznego wzbogacania</h4>

            <div className="space-y-2">
              <Label htmlFor="aiPrompt" className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                Prompt wzbogacania AI
              </Label>
              <div className="flex gap-2">
                <Textarea
                  id="aiPrompt"
                  defaultValue={getSettingValue('ai_enrichment_prompt', '')}
                  placeholder="Opisz co AI ma sprawdzić dla każdej firmy..."
                  rows={8}
                  data-testid="textarea-ai-prompt"
                  onBlur={(e) => handleUpdateSetting('ai_enrichment_prompt', e.target.value)}
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Ten prompt będzie używany przy automatycznym wzbogacaniu danych firm
              </p>
            </div>
          </div>

          {/* Przyszłe klucze API */}
          <div className="space-y-4 border-t pt-4">
            <h4 className="text-sm font-medium text-muted-foreground">Przyszłe integracje</h4>

            <div className="space-y-2">
              <Label htmlFor="googleMapsKey" className="flex items-center gap-2">
                <Key className="h-4 w-4" />
                Klucz Google Maps API (wkrótce)
              </Label>
              <div className="flex gap-2">
                <Input
                  id="googleMapsKey"
                  type="password"
                  defaultValue={getSettingValue('google_maps_api_key', '')}
                  placeholder="AIza..."
                  data-testid="input-google-maps-key"
                  onBlur={(e) => handleUpdateSetting('google_maps_api_key', e.target.value)}
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Do weryfikacji adresów i pobierania zdjęć miejsc (funkcja w rozwoju)
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}