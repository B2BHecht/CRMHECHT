import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Users, 
  Building2, 
  DollarSign, 
  CheckSquare 
} from "lucide-react";

interface MetricsData {
  totalCustomers: number;
  activeProspects: number;
  monthlyRevenue: number;
  pendingTasks: number;
}

interface MetricCardsProps {
  metrics?: MetricsData;
  isLoading: boolean;
}

export default function MetricCards({ metrics, isLoading }: MetricCardsProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <Skeleton className="h-4 w-24 mb-2" />
              <Skeleton className="h-8 w-16 mb-4" />
              <Skeleton className="h-4 w-32" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!metrics) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <p className="text-sm text-muted-foreground">Nie udało się załadować metryk</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const cards = [
    {
      title: "Łączna liczba klientów",
      value: metrics.totalCustomers.toString(),
      icon: Users,
      change: "+12%",
      changeLabel: "od ostatniego miesiąca",
      iconBg: "bg-primary/10",
      iconColor: "text-primary",
      testId: "metric-customers",
    },
    {
      title: "Potencjalni Klienci",
      value: metrics.activeProspects.toString(),
      icon: Building2,
      change: "+1",
      changeLabel: "nowy w tym tygodniu",
      iconBg: "bg-green-100 dark:bg-green-900/20",
      iconColor: "text-green-600 dark:text-green-400",
      testId: "metric-prospects",
    },
    {
      title: "Przychód w tym miesiącu",
      value: `${metrics.monthlyRevenue.toLocaleString()} zł`,
      icon: DollarSign,
      change: "+8%",
      changeLabel: "vs ostatni miesiąc",
      iconBg: "bg-blue-100 dark:bg-blue-900/20",
      iconColor: "text-blue-600 dark:text-blue-400",
      testId: "metric-revenue",
    },
    {
      title: "Oczekujące zadania",
      value: metrics.pendingTasks.toString(),
      icon: CheckSquare,
      change: "2",
      changeLabel: "na dziś",
      iconBg: "bg-orange-100 dark:bg-orange-900/20",
      iconColor: "text-orange-600 dark:text-orange-400",
      testId: "metric-tasks",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {cards.map((card) => (
        <Card key={card.title} data-testid={card.testId}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">{card.title}</p>
                <p className="text-2xl font-semibold text-foreground" data-testid={`${card.testId}-value`}>
                  {card.value}
                </p>
              </div>
              <div className={`p-3 rounded-lg ${card.iconBg}`}>
                <card.icon className={`w-6 h-6 ${card.iconColor}`} />
              </div>
            </div>
            <div className="mt-4 flex items-center">
              <span className="text-sm text-green-600 dark:text-green-400">{card.change}</span>
              <span className="text-sm text-muted-foreground ml-2">{card.changeLabel}</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
