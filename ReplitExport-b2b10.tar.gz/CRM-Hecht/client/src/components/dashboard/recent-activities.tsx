import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { 
  Phone, 
  CheckCircle, 
  UserPlus, 
  Building2,
  ClipboardList 
} from "lucide-react";
import type { ActivityWithRelations } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

const activityIcons = {
  call: Phone,
  email: Phone,
  meeting: Phone,
  note: ClipboardList,
  deal_created: Building2,
  customer_added: UserPlus,
  task_created: ClipboardList,
  task_completed: CheckCircle,
  deal_updated: Building2,
};

const activityColors = {
  call: "bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400",
  email: "bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400",
  meeting: "bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400",
  note: "bg-gray-100 dark:bg-gray-900/20 text-gray-600 dark:text-gray-400",
  deal_created: "bg-green-100 dark:bg-green-900/20 text-green-600 dark:text-green-400",
  customer_added: "bg-purple-100 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400",
  task_created: "bg-orange-100 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400",
  task_completed: "bg-green-100 dark:bg-green-900/20 text-green-600 dark:text-green-400",
  deal_updated: "bg-green-100 dark:bg-green-900/20 text-green-600 dark:text-green-400",
};

export default function RecentActivities() {
  const { data: activities, isLoading } = useQuery<ActivityWithRelations[]>({
    queryKey: ["/api/activities"],
  });

  const recentActivities = activities?.slice(0, 5) || [];

  return (
    <Card data-testid="recent-activities">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium text-foreground">Najnowsze Aktywności i Zadania</h3>
          <Button variant="ghost" size="sm" asChild>
            <Link href="/tasks" data-testid="link-view-all-tasks">
              Zobacz Wszystkie Zadania
            </Link>
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {isLoading ? (
          <div className="divide-y divide-border">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="p-6 flex items-center space-x-4">
                <Skeleton className="w-8 h-8 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-64" />
                  <Skeleton className="h-3 w-32" />
                </div>
                <Skeleton className="h-3 w-16" />
              </div>
            ))}
          </div>
        ) : recentActivities.length === 0 ? (
          <div className="p-6">
            <p className="text-sm text-muted-foreground text-center" data-testid="text-no-activities">
              Brak najnowszych aktywności. Zacznij dodawać klientów i deale, aby zobaczyć aktywność.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {recentActivities.map((activity) => {
              const ActivityIcon = activityIcons[activity.type as keyof typeof activityIcons] || ClipboardList;
              const iconColor = activityColors[activity.type as keyof typeof activityColors] || activityColors.note;
              const timeAgo = activity.createdAt ? formatDistanceToNow(new Date(activity.createdAt), { addSuffix: true }) : "";

              return (
                <div 
                  key={activity.id} 
                  className="p-6 flex items-center space-x-4"
                  data-testid={`activity-item-${activity.id}`}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${iconColor}`}>
                    <ActivityIcon className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground" data-testid={`activity-description-${activity.id}`}>
                      {activity.description}
                    </p>
                    {activity.customer && (
                      <p className="text-sm text-muted-foreground" data-testid={`activity-customer-${activity.id}`}>
                        {activity.customer.companyName}
                      </p>
                    )}
                  </div>
                  <span className="text-xs text-muted-foreground" data-testid={`activity-time-${activity.id}`}>
                    {timeAgo}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
