import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import type { DealWithCustomer } from "@shared/schema";

const stageColors = {
  prospecting: "bg-yellow-400",
  qualified: "bg-blue-400",
  proposal: "bg-orange-400",
  negotiation: "bg-green-400",
  closed_won: "bg-green-600",
  closed_lost: "bg-red-400",
};

const stageLabels = {
  prospecting: "Prospektowanie",
  qualified: "Wykwalifikowani",
  proposal: "Propozycja",
  negotiation: "Negocjacja",
  closed_won: "Zamknięte - Wygrane",
  closed_lost: "Zamknięte - Przegrane",
};

export default function DealPipeline() {
  return null;
}