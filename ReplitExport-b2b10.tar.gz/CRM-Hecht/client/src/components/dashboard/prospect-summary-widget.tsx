import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Building2, TrendingUp, Clock, Target, Eye, Plus, Users } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";
import type { Prospect } from "@shared/schema";
import AddProspectModal from "@/components/modals/add-prospect-modal";

interface ProspectSummary {
  totalProspects: number;
  byStatus: {
    new: number;
    contacted: number;
    qualified: number;
    negotiation: number;
    won: number;
    lost: number;
  };
  recentProspects: Prospect[];
  conversionRate: number;
}

const statusLabels = {
  new: "Nowe",
  contacted: "Skontaktowane", 
  qualified: "Kwalifikowane",
  negotiation: "Negocjacje",
  won: "Wygrane",
  lost: "Przegrane",
};

const statusIcons = {
  new: "🔵",
  contacted: "🟡", 
  qualified: "🟢",
  negotiation: "⚡",
  won: "🎉",
  lost: "🔴",
};

const statusVariants = {
  new: "secondary",
  contacted: "default",
  qualified: "default", 
  negotiation: "default",
  won: "default",
  lost: "destructive",
} as const;

export default function ProspectSummaryWidget() {
  const [, setLocation] = useLocation();
  const [isAddProspectModalOpen, setIsAddProspectModalOpen] = useState(false);

  const { data: prospects, isLoading } = useQuery<Prospect[]>({
    queryKey: ["/api/prospects"],
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Podsumowanie Potencjalnych Klientów
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <Skeleton className="h-16" />
            <Skeleton className="h-16" />
            <Skeleton className="h-16" />
          </div>
          <Skeleton className="h-32" />
        </CardContent>
      </Card>
    );
  }

  if (!prospects) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Podsumowanie Potencjalnych Klientów
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Nie udało się załadować danych</p>
        </CardContent>
      </Card>
    );
  }

  // Obliczanie metryk
  const totalProspects = prospects.length;
  const statusCounts = prospects.reduce((acc, prospect) => {
    acc[prospect.status as keyof typeof acc] = (acc[prospect.status as keyof typeof acc] || 0) + 1;
    return acc;
  }, {
    new: 0,
    contacted: 0,
    qualified: 0,
    negotiation: 0,
    won: 0,
    lost: 0,
  });

  const activeProspects = statusCounts.new + statusCounts.contacted + statusCounts.qualified + statusCounts.negotiation;
  const closedProspects = statusCounts.won + statusCounts.lost;
  const conversionRate = closedProspects > 0 ? Math.round((statusCounts.won / closedProspects) * 100) : 0;

  // Ostatnio dodani potencjalni klienci
  const recentProspects = prospects
    .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
    .slice(0, 5);

  return (
    <Card data-testid="widget-prospect-summary">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Podsumowanie Potencjalnych Klientów
          </CardTitle>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setIsAddProspectModalOpen(true)}
              data-testid="button-add-prospect-quick"
            >
              <Plus className="h-4 w-4 mr-1" />
              Dodaj
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setLocation("/prospects")}
              data-testid="button-view-all-prospects"
            >
              <Eye className="h-4 w-4 mr-1" />
              Zobacz wszystkich
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Kluczowe metryki */}
        <div className="grid grid-cols-3 gap-2 sm:gap-4">
          <div className="text-center p-3 bg-primary/5 rounded-lg" data-testid="metric-total-prospects">
            <div className="text-2xl font-bold text-primary">{totalProspects}</div>
            <div className="text-sm text-muted-foreground">Łącznie</div>
          </div>
          <div className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg" data-testid="metric-active-prospects">
            <div className="text-2xl font-bold text-blue-600">{activeProspects}</div>
            <div className="text-sm text-muted-foreground">Aktywne</div>
          </div>
          <div className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg" data-testid="metric-conversion-rate">
            <div className="text-2xl font-bold text-green-600">{conversionRate}%</div>
            <div className="text-sm text-muted-foreground">Konwersja</div>
          </div>
        </div>

        {/* Podział według statusu */}
        <div>
          <h4 className="font-medium mb-3 flex items-center gap-2">
            <Target className="h-4 w-4" />
            Podział według statusu
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {Object.entries(statusCounts).map(([status, count]) => (
              <div 
                key={status}
                className="flex items-center justify-between p-2 rounded-md bg-muted/30"
                data-testid={`status-count-${status}`}
              >
                <div className="flex items-center gap-2">
                  <span>{statusIcons[status as keyof typeof statusIcons]}</span>
                  <span className="text-sm">{statusLabels[status as keyof typeof statusLabels]}</span>
                </div>
                <Badge variant={statusVariants[status as keyof typeof statusVariants]}>
                  {count}
                </Badge>
              </div>
            ))}
          </div>
        </div>

        {/* Ostatnio dodani */}
        <div>
          <h4 className="font-medium mb-3 flex items-center gap-2">
            <Clock className="h-4 w-4" />
            Ostatnio dodani
          </h4>
          <div className="space-y-2">
            {recentProspects.map((prospect) => (
              <div 
                key={prospect.id}
                className="flex items-center justify-between p-3 rounded-md border bg-card hover:bg-muted/50 transition-colors cursor-pointer"
                onClick={() => setLocation("/prospects")}
                data-testid={`recent-prospect-${prospect.id}`}
              >
                <div>
                  <div className="font-medium text-sm">{prospect.contractorName}</div>
                  <div className="text-xs text-muted-foreground">
                    {prospect.city} • {prospect.salesperson}
                  </div>
                </div>
                <Badge variant={statusVariants[prospect.status as keyof typeof statusVariants]}>
                  {statusIcons[prospect.status as keyof typeof statusIcons]} {statusLabels[prospect.status as keyof typeof statusLabels]}
                </Badge>
              </div>
            ))}
            
            {recentProspects.length === 0 && (
              <div className="text-center py-4 text-muted-foreground">
                <Building2 className="mx-auto h-8 w-8 mb-2" />
                <p className="text-sm">Brak potencjalnych klientów</p>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="mt-2"
                  onClick={() => setLocation("/prospects")}
                  data-testid="button-add-first-prospect"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Dodaj pierwszego
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Trend konwersji */}
        {closedProspects > 0 && (
          <div className="flex items-center gap-2 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
            <TrendingUp className="h-4 w-4 text-green-600" />
            <div className="text-sm">
              <span className="font-medium text-green-600">
                {statusCounts.won} wygranych z {closedProspects} zakończonych
              </span>
              <span className="text-muted-foreground ml-2">
                (wskaźnik konwersji {conversionRate}%)
              </span>
            </div>
          </div>
        )}
      </CardContent>

      {/* Modal dodawania potencjalnego klienta */}
      <AddProspectModal
        isOpen={isAddProspectModalOpen}
        onClose={() => setIsAddProspectModalOpen(false)}
      />
    </Card>
  );
}