import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import type { Customer } from "@shared/schema";

export default function RecentCustomers() {
  const { data: customers, isLoading } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });

  const recentCustomers = customers?.slice(0, 3) || [];

  return (
    <Card data-testid="recent-customers">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium text-foreground">Najnowsi Klienci</h3>
          <Button variant="ghost" size="sm" asChild>
            <Link href="/customers" data-testid="link-view-all-customers">
              Zobacz Wszystkich
            </Link>
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4">
                <Skeleton className="w-10 h-10 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-3 w-48" />
                </div>
                <div className="text-right space-y-2">
                  <Skeleton className="h-4 w-16" />
                  <Skeleton className="h-3 w-12" />
                </div>
              </div>
            ))}
          </div>
        ) : recentCustomers.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4" data-testid="text-no-customers">
            Brak klientów. Dodaj pierwszego klienta, aby zacząć.
          </p>
        ) : (
          <div className="space-y-4">
            {recentCustomers.map((customer) => {
              const initials = customer.contractorName
                .split(" ")
                .map(word => word[0])
                .join("")
                .substring(0, 2)
                .toUpperCase();

              return (
                <div 
                  key={customer.id} 
                  className="flex items-center space-x-4"
                  data-testid={`customer-item-${customer.id}`}
                >
                  <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                    <span className="text-sm font-medium text-primary-foreground">
                      {initials}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground" data-testid={`text-company-${customer.id}`}>
                      {customer.contractorName}
                    </p>
                    <p className="text-sm text-muted-foreground" data-testid={`text-email-${customer.id}`}>
                      {customer.email}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-foreground">0 zł</p>
                    
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
