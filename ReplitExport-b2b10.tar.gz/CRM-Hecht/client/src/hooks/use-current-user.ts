import { useState, useEffect } from 'react';

// Na razie symulujemy różne role dla demonstracji
// W przyszłości to będzie pobierane z prawdziwego systemu uwierzytelniania
export function useCurrentUser() {
  // Domyślnie administrator żeby mieć dostęp do wszystkich funkcji
  const [currentUser] = useState({
    id: 'admin-1',
    username: 'admin',
    email: 'admin@firma.pl',
    firstName: 'Jan',
    lastName: 'Kowalski',
    role: 'administrator' as 'administrator' | 'dyrektor' | 'koordynator' | 'handlowiec',
    isActive: 1,
    lastLogin: new Date(),
    createdAt: new Date()
  });

  return {
    user: currentUser,
    isAdmin: currentUser.role === 'administrator',
    isDirector: currentUser.role === 'dyrektor', 
    isCoordinator: currentUser.role === 'koordynator',
    isSalesperson: currentUser.role === 'handlowiec'
  };
}