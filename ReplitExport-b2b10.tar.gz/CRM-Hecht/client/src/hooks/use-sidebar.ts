import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import type { SystemSetting } from "@shared/schema";

export function useSidebar() {
  const [isCollapsed, setIsCollapsed] = useState(false);
  
  // Pobierz ustawienie auto-chowania sidebar
  const { data: settings = [] } = useQuery<SystemSetting[]>({
    queryKey: ['/api/settings'],
  });
  
  const sidebarAutoHide = settings.find(s => s.settingKey === 'sidebar_auto_hide')?.settingValue === 'true';

  // Zastosuj ustawienie auto-chowania przy ładowaniu
  useEffect(() => {
    if (sidebarAutoHide) {
      setIsCollapsed(true);
    }
  }, [sidebarAutoHide]);

  return {
    isCollapsed,
    setIsCollapsed,
    sidebarAutoHide
  };
}