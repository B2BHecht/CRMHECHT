import { useQuery } from "@tanstack/react-query";

interface MetricsData {
  totalCustomers: number;
  activeDeals: number;
  monthlyRevenue: number;
  pendingTasks: number;
}
import Header from "@/components/layout/header";
import MetricCards from "@/components/dashboard/metric-cards";
import RecentCustomers from "@/components/dashboard/recent-customers";
import DealPipeline from "@/components/dashboard/deal-pipeline";
import RecentActivities from "@/components/dashboard/recent-activities";
import ProspectSummaryWidget from "@/components/dashboard/prospect-summary-widget";
import AddCustomerModal from "@/components/modals/add-customer-modal";
import { Button } from "@/components/ui/button";
import { useState } from "react";

export default function Dashboard() {
  const [isAddCustomerModalOpen, setIsAddCustomerModalOpen] = useState(false);

  const { data: metrics, isLoading: metricsLoading } = useQuery<MetricsData>({
    queryKey: ["/api/dashboard/metrics"],
  });

  return (
    <div className="flex flex-col h-full">
      <Header
        title="Pulpit"
        subtitle="Witaj z powrotem! Oto co dzieje się z Twoim biznesem."
        actionButton={null}
      />

      <div className="flex-1 overflow-auto p-6 space-y-6">
        <MetricCards metrics={metrics} isLoading={metricsLoading} />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <RecentCustomers />
          <DealPipeline />
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          <div className="xl:col-span-2">
            <RecentActivities />
          </div>
          <div className="min-w-0">
            <ProspectSummaryWidget />
          </div>
        </div>
      </div>

      <AddCustomerModal
        isOpen={isAddCustomerModalOpen}
        onClose={() => setIsAddCustomerModalOpen(false)}
      />
    </div>
  );
}