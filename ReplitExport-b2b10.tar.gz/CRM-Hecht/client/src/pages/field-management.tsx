import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit2, Trash2, Move } from "lucide-react";
import type { FieldDefinition, InsertFieldDefinition } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export default function FieldManagement() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingField, setEditingField] = useState<FieldDefinition | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch field definitions
  const { data: fieldDefinitions = [], isLoading } = useQuery<FieldDefinition[]>({
    queryKey: ['/api/field-definitions'],
  });

  // Add field mutation
  const addFieldMutation = useMutation({
    mutationFn: (data: InsertFieldDefinition) => 
      apiRequest('POST', '/api/field-definitions', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/field-definitions'] });
      setIsAddModalOpen(false);
      toast({
        title: "Sukces",
        description: "Pole zostało dodane pomyślnie",
      });
    },
    onError: () => {
      toast({
        title: "Błąd",
        description: "Nie udało się dodać pola",
        variant: "destructive",
      });
    },
  });

  // Update field mutation
  const updateFieldMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertFieldDefinition> }) =>
      apiRequest('PATCH', `/api/field-definitions/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/field-definitions'] });
      setIsEditModalOpen(false);
      setEditingField(null);
      toast({
        title: "Sukces",
        description: "Pole zostało zaktualizowane pomyślnie",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się zaktualizować pola",
        variant: "destructive",
      });
    },
  });

  // Delete field mutation
  const deleteFieldMutation = useMutation({
    mutationFn: (id: string) => 
      apiRequest('DELETE', `/api/field-definitions/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/field-definitions'] });
      toast({
        title: "Sukces",
        description: "Pole zostało usunięte pomyślnie",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error.message || "Nie udało się usunąć pola",
        variant: "destructive",
      });
    },
  });

  const handleEdit = (field: FieldDefinition) => {
    setEditingField(field);
    setIsEditModalOpen(true);
  };

  const handleDelete = async (field: FieldDefinition) => {
    if (field.isDefault === 1) {
      toast({
        title: "Błąd",
        description: "Nie można usuwać domyślnych pól",
        variant: "destructive",
      });
      return;
    }

    if (window.confirm(`Czy na pewno chcesz usunąć pole "${field.fieldLabel}"?`)) {
      deleteFieldMutation.mutate(field.id);
    }
  };

  if (isLoading) {
    return <div className="p-6">Ładowanie...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Zarządzanie Polami</h1>
          <p className="text-muted-foreground">
            Zarządzaj polami danych klientów - edytuj nazwy i dodawaj nowe pola
          </p>
        </div>
        
        <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-field">
              <Plus className="h-4 w-4 mr-2" />
              Dodaj Pole
            </Button>
          </DialogTrigger>
          <AddFieldModal 
            onClose={() => setIsAddModalOpen(false)}
            onSubmit={(data) => addFieldMutation.mutate(data)}
            isLoading={addFieldMutation.isPending}
          />
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lista Pól</CardTitle>
          <CardDescription>
            Wszystkie pola dostępne w systemie. Domyślne pola można edytować ale nie usuwać.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Kolejność</TableHead>
                <TableHead>Nazwa</TableHead>
                <TableHead>Klucz</TableHead>
                <TableHead>Typ</TableHead>
                <TableHead>Wymagane</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Typ pola</TableHead>
                <TableHead>Akcje</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {fieldDefinitions
                .sort((a: FieldDefinition, b: FieldDefinition) => (a.displayOrder || 0) - (b.displayOrder || 0))
                .map((field: FieldDefinition) => (
                <TableRow key={field.id}>
                  <TableCell data-testid={`text-order-${field.id}`}>
                    {field.displayOrder}
                  </TableCell>
                  <TableCell data-testid={`text-label-${field.id}`}>
                    <span className="font-medium">{field.fieldLabel}</span>
                  </TableCell>
                  <TableCell data-testid={`text-key-${field.id}`}>
                    <code className="bg-muted px-2 py-1 rounded text-sm">
                      {field.fieldKey}
                    </code>
                  </TableCell>
                  <TableCell data-testid={`text-type-${field.id}`}>
                    {field.fieldType}
                  </TableCell>
                  <TableCell data-testid={`text-required-${field.id}`}>
                    {field.isRequired === 1 ? "Tak" : "Nie"}
                  </TableCell>
                  <TableCell data-testid={`text-status-${field.id}`}>
                    <span className={`px-2 py-1 rounded text-xs ${
                      field.isActive === 1 
                        ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                        : "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
                    }`}>
                      {field.isActive === 1 ? "Aktywne" : "Nieaktywne"}
                    </span>
                  </TableCell>
                  <TableCell data-testid={`text-default-${field.id}`}>
                    {field.isDefault === 1 ? (
                      <span className="text-xs text-blue-600 dark:text-blue-400">Domyślne</span>
                    ) : (
                      <span className="text-xs text-gray-500">Niestandardowe</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEdit(field)}
                        data-testid={`button-edit-${field.id}`}
                      >
                        <Edit2 className="h-4 w-4" />
                      </Button>
                      {field.isDefault === 0 && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(field)}
                          className="text-red-600 hover:text-red-700"
                          data-testid={`button-delete-${field.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Edit Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        {editingField && (
          <EditFieldModal 
            field={editingField}
            onClose={() => {
              setIsEditModalOpen(false);
              setEditingField(null);
            }}
            onSubmit={(data) => updateFieldMutation.mutate({ 
              id: editingField.id, 
              data 
            })}
            isLoading={updateFieldMutation.isPending}
          />
        )}
      </Dialog>
    </div>
  );
}

// Add Field Modal Component
function AddFieldModal({ 
  onClose, 
  onSubmit, 
  isLoading 
}: { 
  onClose: () => void;
  onSubmit: (data: InsertFieldDefinition) => void;
  isLoading: boolean;
}) {
  const [formData, setFormData] = useState<InsertFieldDefinition>({
    fieldKey: '',
    fieldLabel: '',
    fieldType: 'text',
    isRequired: 0,
    isDefault: 0,
    displayOrder: 0,
    isActive: 1,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.fieldKey.trim() || !formData.fieldLabel.trim()) {
      return;
    }

    onSubmit({
      ...formData,
      fieldKey: formData.fieldKey.trim(),
      fieldLabel: formData.fieldLabel.trim(),
    });
  };

  return (
    <DialogContent className="sm:max-w-md">
      <DialogHeader>
        <DialogTitle>Dodaj Nowe Pole</DialogTitle>
        <DialogDescription>
          Stwórz nowe pole danych dla klientów w systemie.
        </DialogDescription>
      </DialogHeader>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="fieldKey">Klucz Pola</Label>
          <Input
            id="fieldKey"
            value={formData.fieldKey}
            onChange={(e) => setFormData(prev => ({ ...prev, fieldKey: e.target.value }))}
            placeholder="np. customField1"
            data-testid="input-field-key"
          />
          <p className="text-xs text-muted-foreground">
            Unikalny identyfikator pola (bez spacji, tylko litery i cyfry)
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="fieldLabel">Nazwa Wyświetlana</Label>
          <Input
            id="fieldLabel"
            value={formData.fieldLabel}
            onChange={(e) => setFormData(prev => ({ ...prev, fieldLabel: e.target.value }))}
            placeholder="np. Dodatkowe Informacje"
            data-testid="input-field-label"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="fieldType">Typ Pola</Label>
          <Select 
            value={formData.fieldType} 
            onValueChange={(value) => setFormData(prev => ({ ...prev, fieldType: value }))}
          >
            <SelectTrigger data-testid="select-field-type">
              <SelectValue placeholder="Wybierz typ pola" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="text">Tekst</SelectItem>
              <SelectItem value="number">Liczba</SelectItem>
              <SelectItem value="email">Email</SelectItem>
              <SelectItem value="phone">Telefon</SelectItem>
              <SelectItem value="date">Data</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="displayOrder">Kolejność Wyświetlania</Label>
          <Input
            id="displayOrder"
            type="number"
            value={formData.displayOrder || 0}
            onChange={(e) => setFormData(prev => ({ ...prev, displayOrder: parseInt(e.target.value) || 0 }))}
            placeholder="0"
            data-testid="input-display-order"
          />
        </div>

        <div className="flex items-center space-x-2">
          <Switch
            id="isRequired"
            checked={formData.isRequired === 1}
            onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isRequired: checked ? 1 : 0 }))}
            data-testid="switch-required"
          />
          <Label htmlFor="isRequired">Pole wymagane</Label>
        </div>

        <DialogFooter>
          <Button type="button" variant="outline" onClick={onClose}>
            Anuluj
          </Button>
          <Button 
            type="submit" 
            disabled={isLoading || !formData.fieldKey.trim() || !formData.fieldLabel.trim()}
            data-testid="button-submit-add-field"
          >
            {isLoading ? "Dodaję..." : "Dodaj Pole"}
          </Button>
        </DialogFooter>
      </form>
    </DialogContent>
  );
}

// Edit Field Modal Component
function EditFieldModal({ 
  field,
  onClose, 
  onSubmit, 
  isLoading 
}: { 
  field: FieldDefinition;
  onClose: () => void;
  onSubmit: (data: Partial<InsertFieldDefinition>) => void;
  isLoading: boolean;
}) {
  const [formData, setFormData] = useState<Partial<InsertFieldDefinition>>({
    fieldLabel: field.fieldLabel,
    fieldType: field.fieldType,
    isRequired: field.isRequired,
    displayOrder: field.displayOrder,
    isActive: field.isActive,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.fieldLabel?.trim()) {
      return;
    }

    onSubmit({
      ...formData,
      fieldLabel: formData.fieldLabel?.trim(),
    });
  };

  return (
    <DialogContent className="sm:max-w-md">
      <DialogHeader>
        <DialogTitle>Edytuj Pole</DialogTitle>
        <DialogDescription>
          Zmodyfikuj ustawienia pola "{field.fieldLabel}"
        </DialogDescription>
      </DialogHeader>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="editFieldKey">Klucz Pola</Label>
          <Input
            id="editFieldKey"
            value={field.fieldKey}
            disabled
            className="bg-muted"
            data-testid="input-edit-field-key"
          />
          <p className="text-xs text-muted-foreground">
            Klucza pola nie można zmieniać
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="editFieldLabel">Nazwa Wyświetlana</Label>
          <Input
            id="editFieldLabel"
            value={formData.fieldLabel || ''}
            onChange={(e) => setFormData(prev => ({ ...prev, fieldLabel: e.target.value }))}
            placeholder="np. Dodatkowe Informacje"
            data-testid="input-edit-field-label"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="editFieldType">Typ Pola</Label>
          <Select 
            value={formData.fieldType} 
            onValueChange={(value) => setFormData(prev => ({ ...prev, fieldType: value }))}
          >
            <SelectTrigger data-testid="select-edit-field-type">
              <SelectValue placeholder="Wybierz typ pola" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="text">Tekst</SelectItem>
              <SelectItem value="number">Liczba</SelectItem>
              <SelectItem value="email">Email</SelectItem>
              <SelectItem value="phone">Telefon</SelectItem>
              <SelectItem value="date">Data</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="editDisplayOrder">Kolejność Wyświetlania</Label>
          <Input
            id="editDisplayOrder"
            type="number"
            value={formData.displayOrder || 0}
            onChange={(e) => setFormData(prev => ({ ...prev, displayOrder: parseInt(e.target.value) || 0 }))}
            data-testid="input-edit-display-order"
          />
        </div>

        <div className="flex items-center space-x-2">
          <Switch
            id="editIsRequired"
            checked={formData.isRequired === 1}
            onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isRequired: checked ? 1 : 0 }))}
            disabled={field.isDefault === 1 && field.isRequired === 1}
            data-testid="switch-edit-required"
          />
          <Label htmlFor="editIsRequired">Pole wymagane</Label>
          {field.isDefault === 1 && field.isRequired === 1 && (
            <span className="text-xs text-muted-foreground">(nie można zmienić)</span>
          )}
        </div>

        <div className="flex items-center space-x-2">
          <Switch
            id="editIsActive"
            checked={formData.isActive === 1}
            onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked ? 1 : 0 }))}
            data-testid="switch-edit-active"
          />
          <Label htmlFor="editIsActive">Pole aktywne</Label>
        </div>

        <DialogFooter>
          <Button type="button" variant="outline" onClick={onClose}>
            Anuluj
          </Button>
          <Button 
            type="submit" 
            disabled={isLoading || !formData.fieldLabel?.trim()}
            data-testid="button-submit-edit-field"
          >
            {isLoading ? "Zapisuję..." : "Zapisz Zmiany"}
          </Button>
        </DialogFooter>
      </form>
    </DialogContent>
  );
}