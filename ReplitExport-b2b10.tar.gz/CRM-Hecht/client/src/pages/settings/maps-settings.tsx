import React, { useEffect, useMemo, useState } from "react";

type MapsSettings = { maps_streetview_mode: "embed" | "static"; maps_max_photos: number };

// TODO: integrate real auth (e.g., useAuth()) if available.
// Fallback keeps the build working.
function useCurrentUser() {
  // const { user } = useAuth(); return user;
  if (typeof window !== "undefined" && (window as any).__USER__) return (window as any).__USER__;
  return { role: "user" };
}

export default function MapsSettingsPage() {
  const user = useCurrentUser();
  const isAdmin = useMemo(() => !!user && (user.role === "admin" || user.isAdmin === true), [user]);

  const [cfg, setCfg] = useState<MapsSettings>({ maps_streetview_mode: "embed", maps_max_photos: 5 });
  const [orig, setOrig] = useState<MapsSettings>({ maps_streetview_mode: "embed", maps_max_photos: 5 });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    fetch("/api/settings/maps")
      .then(r => (r.ok ? r.json() : Promise.reject(new Error("GET /api/settings/maps failed"))))
      .then((data: MapsSettings) => { if (mounted) { setCfg(data); setOrig(data); } })
      .catch((e) => { if (mounted) setErr(e?.message || "Błąd odczytu"); })
      .finally(() => mounted && setLoading(false));
    return () => { mounted = false; };
  }, []);

  const dirty = cfg.maps_streetview_mode !== orig.maps_streetview_mode || cfg.maps_max_photos !== orig.maps_max_photos;

  async function onSave() {
    if (!isAdmin || !dirty) return;
    setSaving(true); setErr(null); setMsg(null);
    try {
      const r = await fetch("/api/settings/maps", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(cfg),
      });
      if (!r.ok) throw new Error(await r.text());
      const data: MapsSettings = await r.json();
      setCfg(data); setOrig(data);
      setMsg("Zapisano ustawienia.");
    } catch (e: any) {
      setErr(e?.message || "Błąd zapisu");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="p-4 space-y-4 max-w-3xl">
      <h1 className="text-xl font-semibold">Maps / Street View</h1>
      <p className="text-sm text-muted-foreground">Zarządzaj ustawieniami map i widoku ulicznego.</p>

      {loading ? (
        <div>Ładowanie…</div>
      ) : (
        <div className="space-y-5 border rounded-lg p-4 bg-white/5">
          {err && <div className="text-red-600 text-sm">{err}</div>}
          {msg && <div className="text-green-600 text-sm">{msg}</div>}

          <div className="grid gap-1">
            <label className="text-sm">Tryb Street View</label>
            <select
              value={cfg.maps_streetview_mode}
              onChange={(e) => setCfg(s => ({ ...s, maps_streetview_mode: e.target.value as "embed" | "static" }))}
              className="border rounded px-2 py-1 bg-background w-80"
            >
              <option value="embed">Interaktywny (Embed)</option>
              <option value="static">Statyczny (JPG)</option>
            </select>
            {!isAdmin && <span className="text-xs text-muted-foreground">Tylko administrator może zmieniać.</span>}
          </div>

          <div className="grid gap-1">
            <label className="text-sm">Maksymalna liczba zdjęć (1–10)</label>
            <input
              type="number" min={1} max={10}
              value={cfg.maps_max_photos}
              onChange={(e) => {
                const n = parseInt(e.target.value || "5", 10);
                const clamped = Math.max(1, Math.min(10, Number.isFinite(n) ? n : 5));
                setCfg(s => ({ ...s, maps_max_photos: clamped }));
              }}
              className="border rounded px-2 py-1 bg-background w-24"
              disabled={!isAdmin}
            />
            <span className="text-xs text-muted-foreground">Limit egzekwowany także w backendzie.</span>
          </div>

          <div className="pt-2">
            <button
              onClick={onSave}
              disabled={!isAdmin || !dirty || saving}
              className="inline-flex items-center px-3 py-2 rounded bg-blue-600 text-white disabled:opacity-60"
            >
              {saving ? "Zapisywanie…" : "Zapisz"}
            </button>
            {!isAdmin && <span className="ml-3 text-sm text-muted-foreground">Widok tylko do odczytu.</span>}
          </div>
        </div>
      )}
    </div>
  );
}