import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Reports() {
  return (
    <div className="flex flex-col h-full">
      <Header
        title="Raporty"
        subtitle="Przeglądaj analitykę i generuj raporty dla swojego biznesu."
      />
      
      <div className="flex-1 overflow-auto p-6">
        <div className="grid gap-6">
          <Card data-testid="reports-placeholder">
            <CardHeader>
              <CardTitle>Raporty Biznesowe</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <p className="text-muted-foreground mb-4" data-testid="text-coming-soon">
                  Zaawansowane funkcje raportowania już wkrótce
                </p>
                <p className="text-sm text-muted-foreground">
                  Ta sekcja będzie zawierać szczegółowe analizy, wykresy i eksportowalne raporty dla danych CRM.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
