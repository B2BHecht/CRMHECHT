import { useState } from "react";
import Header from "@/components/layout/header";
import TaskTable from "@/components/tasks/task-table";
import AddTaskModal from "@/components/modals/add-task-modal";
import { Button } from "@/components/ui/button";

export default function Tasks() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  return (
    <div className="flex flex-col h-full">
      <Header
        title="Zadania"
        subtitle="Zarządzaj zadaniami, follow-up'ami i rzeczami do zrobienia."
        actionButton={
          <Button 
            onClick={() => setIsAddModalOpen(true)}
            data-testid="button-add-task"
          >
            Dodaj Zadanie
          </Button>
        }
      />
      
      <div className="flex-1 overflow-auto p-6">
        <TaskTable />
      </div>

      <AddTaskModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
      />
    </div>
  );
}
