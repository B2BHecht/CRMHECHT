import { useState } from "react";
import Header from "@/components/layout/header";
import ProspectTable from "@/components/prospects/prospect-table";
import AddProspectModal from "@/components/modals/add-prospect-modal";
import { Button } from "@/components/ui/button";

export default function Prospects() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  return (
    <div className="flex flex-col h-full">
      <Header
        title="Potencjalni Klienci"
        subtitle="Zarządzaj potencjalnymi klientami i konwertuj ich na prawdziwych klientów."
        actionButton={
          <Button 
            onClick={() => setIsAddModalOpen(true)}
            data-testid="button-add-prospect"
            className="text-xs sm:text-sm px-3 py-2 sm:px-4 sm:py-2"
          >
            <span className="hidden sm:inline">Dodaj Potencjalnego Klienta</span>
            <span className="sm:hidden">+ Dodaj</span>
          </Button>
        }
      />
      
      <div className="flex-1 overflow-auto p-4 sm:p-6">
        <ProspectTable />
      </div>

      <AddProspectModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
      />
    </div>
  );
}