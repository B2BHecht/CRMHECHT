import { useState } from "react";
import Header from "@/components/layout/header";
import CustomerTable from "@/components/customers/customer-table";
import AddCustomerModal from "@/components/modals/add-customer-modal";
import { ImportExcelModal } from "@/components/modals/import-excel-modal";
import { Button } from "@/components/ui/button";
import { FileSpreadsheet } from "lucide-react";

export default function Customers() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  return (
    <div className="flex flex-col h-full">
      <Header
        title="Klienci"
        subtitle="Zarządzaj relacjami z klientami i informacjami kontaktowymi."
        actionButton={
          <div className="flex gap-2">
            <Button 
              variant="outline"
              onClick={() => setIsImportModalOpen(true)}
              data-testid="button-import-excel"
              className="flex items-center gap-2"
            >
              <FileSpreadsheet className="h-4 w-4" />
              Import z Excel
            </Button>
            <Button 
              onClick={() => setIsAddModalOpen(true)}
              data-testid="button-add-customer"
            >
              Dodaj Klienta
            </Button>
          </div>
        }
      />
      
      <div className="flex-1 overflow-auto p-6">
        <CustomerTable />
      </div>

      <AddCustomerModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
      />
      
      <ImportExcelModal
        open={isImportModalOpen}
        onOpenChange={setIsImportModalOpen}
      />
    </div>
  );
}
