import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Settings, Users, Database, Upload, Building, Columns } from "lucide-react";
import UserManagement from "@/components/settings/user-management.tsx";
import FieldManagement from "@/components/settings/field-management.tsx";
import ImportSection from "@/components/settings/import-section.tsx";
import GeneralSettings from "@/components/settings/general-settings.tsx";
import { ColumnPermissions } from "@/components/settings/column-permissions.tsx";
import MapsSettingsPage from "@/components/settings/maps-settings.tsx";

export default function SettingsPage() {
  const { user: currentUser } = useAuth();

  return (
    <div className="p-4 lg:p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold tracking-tight">Ustawienia Systemu</h1>
          <p className="text-muted-foreground mt-1">
            Zarządzaj użytkownikami, polami danych, importem i ustawieniami aplikacji
          </p>
        </div>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 lg:grid-cols-6 gap-2 lg:gap-0">
          <TabsTrigger value="general" className="flex items-center gap-2" data-testid="tab-general">
            <Settings className="h-4 w-4" />
            <span className="hidden sm:inline">Ogólne</span>
          </TabsTrigger>
          <TabsTrigger value="users" className="flex items-center gap-2" data-testid="tab-users">
            <Users className="h-4 w-4" />
            <span className="hidden sm:inline">Użytkownicy</span>
          </TabsTrigger>
          <TabsTrigger value="permissions" className="flex items-center gap-2" data-testid="tab-permissions">
            <Columns className="h-4 w-4" />
            <span className="hidden sm:inline">Kolumny</span>
          </TabsTrigger>
          <TabsTrigger value="fields" className="flex items-center gap-2" data-testid="tab-fields">
            <Database className="h-4 w-4" />
            <span className="hidden sm:inline">Pola</span>
          </TabsTrigger>
          <TabsTrigger value="import" className="flex items-center gap-2" data-testid="tab-import">
            <Upload className="h-4 w-4" />
            <span className="hidden sm:inline">Import</span>
          </TabsTrigger>
          <TabsTrigger value="company" className="flex items-center gap-2" data-testid="tab-company">
            <Building className="h-4 w-4" />
            <span className="hidden sm:inline">Firma</span>
          </TabsTrigger>
          <TabsTrigger value="maps" className="flex items-center gap-2" data-testid="tab-maps">
            <Settings className="h-4 w-4" />
            <span className="hidden sm:inline">Maps / Street View</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <GeneralSettings />
        </TabsContent>

        <TabsContent value="users" className="space-y-6">
          <UserManagement />
        </TabsContent>

        <TabsContent value="permissions" className="space-y-6">
          <ColumnPermissions />
        </TabsContent>

        <TabsContent value="fields" className="space-y-6">
          <FieldManagement />
        </TabsContent>

        <TabsContent value="import" className="space-y-6">
          <ImportSection />
        </TabsContent>

        <TabsContent value="company" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Ustawienia Firmy</CardTitle>
              <CardDescription>
                Skonfiguruj podstawowe informacje o Twojej firmie
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Ta sekcja będzie zawierała ustawienia firmy takie jak nazwa, logo, adres itp.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="maps" className="space-y-6">
          <MapsSettingsPage user={currentUser} />
        </TabsContent>
      </Tabs>
    </div>
  );
}