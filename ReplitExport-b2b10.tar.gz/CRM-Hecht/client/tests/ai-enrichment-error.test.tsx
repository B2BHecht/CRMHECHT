
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { CustomerAIEnrichmentModal } from '@/components/modals/customer-ai-enrichment-modal';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: false },
    mutations: { retry: false }
  }
});

describe('CustomerAIEnrichmentModal Error Handling', () => {
  it('wyświetla odpowiedni komunikat błędu dla błędu 500', async () => {
    const mockProps = {
      isOpen: true,
      onClose: vi.fn(),
      customerId: '123',
      customerName: 'Test Customer',
      currentNotes: ''
    };

    render(
      <QueryClientProvider client={queryClient}>
        <CustomerAIEnrichmentModal {...mockProps} />
      </QueryClientProvider>
    );

    const enrichButton = screen.getByTestId('button-enrich');
    fireEvent.click(enrichButton);

    await waitFor(() => {
      expect(screen.queryByText(/Błąd wzbogacania AI/)).toBeInTheDocument();
    });
  });
});
