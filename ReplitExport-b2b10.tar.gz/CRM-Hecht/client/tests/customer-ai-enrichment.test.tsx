
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { QueryClient, QueryProvider } from '@tanstack/react-query';
import { CustomerAIEnrichmentModal } from '@/components/modals/customer-ai-enrichment-modal';
import { vi } from 'vitest';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: false },
    mutations: { retry: false },
  },
});

const TestWrapper = ({ children }: { children: React.ReactNode }) => (
  <QueryProvider client={queryClient}>{children}</QueryProvider>
);

describe('CustomerAIEnrichmentModal', () => {
  const mockProps = {
    isOpen: true,
    onClose: vi.fn(),
    customerId: '123',
    customerName: 'TOMASZ BĘTKOWSKI',
    currentNotes: '{"hasGardenEquipment": true, "businessDescription": "Test firm"}',
  };

  it('renders modal with customer name', () => {
    render(
      <TestWrapper>
        <CustomerAIEnrichmentModal {...mockProps} />
      </TestWrapper>
    );
    
    expect(screen.getByText(/TOMASZ BĘTKOWSKI/)).toBeInTheDocument();
  });

  it('shows AI data badges when parsed correctly', () => {
    render(
      <TestWrapper>
        <CustomerAIEnrichmentModal {...mockProps} />
      </TestWrapper>
    );
    
    expect(screen.getByText(/🌿 Sprzęt ogrodniczy/)).toBeInTheDocument();
  });

  it('allows custom prompt input', () => {
    render(
      <TestWrapper>
        <CustomerAIEnrichmentModal {...mockProps} />
      </TestWrapper>
    );
    
    const textarea = screen.getByTestId('textarea-custom-prompt');
    fireEvent.change(textarea, { target: { value: 'Test prompt' } });
    expect(textarea.value).toBe('Test prompt');
  });
});
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import CustomerAIEnrichmentModal from '../src/components/modals/customer-ai-enrichment-modal';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: false },
    mutations: { retry: false }
  }
});

const mockCustomer = {
  id: 'a5b57314-98a5-4565-84b6-0c4b545cf126',
  contractorName: 'TOMASZ BĘTKOWSKI',
  city: 'Skawina',
  streetAddress: 'Mickiewicza 32b'
};

describe('CustomerAIEnrichmentModal', () => {
  it('renderuje modal z danymi klienta', () => {
    render(
      <QueryClientProvider client={queryClient}>
        <CustomerAIEnrichmentModal
          customer={mockCustomer}
          isOpen={true}
          onClose={() => {}}
        />
      </QueryClientProvider>
    );

    expect(screen.getByText('Wzbogacenie AI')).toBeInTheDocument();
    expect(screen.getByText('TOMASZ BĘTKOWSKI')).toBeInTheDocument();
  });
});
